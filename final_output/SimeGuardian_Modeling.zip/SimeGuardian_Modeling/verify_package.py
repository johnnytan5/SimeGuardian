"""Verify the originally delivered files using Python standard library only."""
import csv,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
with (root/'manifest.csv').open() as stream: records=list(csv.DictReader(stream))
for r in records:
 p=(root/r['path']).resolve()
 assert p.is_relative_to(root), 'Unsafe manifest path'
 assert p.is_file() and p.stat().st_size==int(r['bytes']), 'Missing/changed file: '+r['path']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'], 'Hash mismatch: '+r['path']
books=list(root.glob('*.ipynb'));assert len(books)==2
for path in books:
 book=json.loads(path.read_text());cells=[c for c in book['cells'] if c['cell_type']=='code']
 assert all(c['execution_count'] is not None for c in cells)
 assert not any(o.get('output_type')=='error' for c in cells for o in c.get('outputs',[]))
 assert any('image/png' in o.get('data',{}) for c in cells for o in c.get('outputs',[]))
with (root/'results/final_emergency_results.csv').open() as stream:
 pooled=next(r for r in csv.DictReader(stream) if r['seed']=='pooled')
assert [int(float(pooled[k])) for k in ['TP','FP','TN','FN','abstained_positive_intervals']]==[75,5,1225,9,1]
assert abs(float(pooled['recall_counting_abstentions_as_misses'])-75/85)<1e-12
assert not any(p.suffix in ['.json','.jsonl','.npz'] for p in (root/'datasets').rglob('*'))
print(f'PASS: {len(records)} file hashes, two executed notebooks, embedded figures, final counts and CSV dataset contract.')
