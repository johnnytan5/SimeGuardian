"""Portable notebook computations for the final handoff; paths are relative to setup()."""
from pathlib import Path
import time
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import MaxNLocator
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import log_loss
from threadpoolctl import threadpool_limits
from household import generate as g, forecast_finetune as fine, precision_study as old
from household.tuned_study import FEATURES
from household.illustrative_study import CONTEXT, ROLES
from household.two_stage import review_labels, confusion, source_inputs
from household.train import inputs, predict

SOURCES=['electricity','water','gate','app']
UNITS=dict(electricity='kWh',water='L',gate='verified events',app='verified events')
BLUE='#2364AA';ORANGE='#D47A26';OLIVE='#6A7F3E';INK='#233247';GREY='#687789'
EMERGENCY_FEATURES=FEATURES+CONTEXT
ROOT=None
_FORECAST=None


def setup(root):
    global ROOT
    ROOT=Path(root)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':13,'axes.labelsize':11,
        'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#C5CDD5','axes.labelcolor':INK,
        'text.color':INK,'timezone':'Asia/Kuala_Lumpur','xtick.color':GREY,'ytick.color':GREY,'figure.facecolor':'white',
        'axes.facecolor':'white','grid.color':'#E5E9EF','grid.linewidth':.7,'axes.axisbelow':True,'savefig.dpi':160})


def rows(path):return pd.read_csv(ROOT/path,keep_default_na=False).to_dict('records')


def save(fig,section,name):
    folder=ROOT/'figures'/section;folder.mkdir(parents=True,exist_ok=True)
    fig.savefig(folder/(name+'.png'),bbox_inches='tight')
    fig.savefig(folder/(name+'.pdf'),bbox_inches='tight')


def boxes(labels,title,section,name):
    fig,ax=plt.subplots(figsize=(13,3.5));ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
    width=.17;start=.015
    for i,label in enumerate(labels):
        x=start+i*.2
        ax.add_patch(FancyBboxPatch((x,.29),width,.42,boxstyle='round,pad=0.012',facecolor='#F3F7FB',edgecolor=BLUE,linewidth=1.2))
        ax.text(x+width/2,.5,label,ha='center',va='center',fontsize=10)
        if i<len(labels)-1:ax.annotate('',xy=(x+.197,.5),xytext=(x+width+.004,.5),arrowprops=dict(arrowstyle='->',color=INK))
    ax.set_title(title,loc='left',pad=10)
    fig.subplots_adjust(top=.84,bottom=.09,left=.02,right=.98);save(fig,section,name)


def forecast_architecture():
    boxes(['Own source\n336h + masks','LSTM\n32 units','Calendar + own\nseasonal context','Dense16 +\nresidual scalar','Seasonal baseline\n+ correction'],
        'Four independent forecasting paths · no cross-source LSTM inputs','forecasting','01_architecture')


def detection_architecture():
    boxes(['Four separate\nsource forecasts','Past residuals\n+ availability','Verified activity\n+ check-in context','Two independent\nboosted classifiers','Frozen thresholds\n+ separate labels'],
        'Phase2 · usage anomalies and assistance need are separate targets','detection','01_architecture')


def forecast_split_plot():
    fig,ax=plt.subplots(figsize=(12,3.5))
    for y,segments in [(2,[(0,336,GREY,'history'),(336,2544,BLUE,'source fitting'),(2880,720,ORANGE,'early stop')]),
                       (1,[(3600,3408,BLUE,'detector development')]),(0,[(7008,1752,ORANGE,'calibration / distinct test seeds')])]:
        for a,w,color,label in segments:
            ax.broken_barh([(a,w)],(y-.23,.46),facecolors=color)
            if label=='history':ax.text(a+w/2,y+.35,label,ha='center',va='bottom',color=GREY,fontsize=9)
            else:ax.text(a+w/2,y,label,ha='center',va='center',color='white',fontsize=9)
    ax.set(yticks=[0,1,2],yticklabels=['Calibration/test groups','Detector development','Source fitting'],xlabel='Hour since2026-01-01 · separate seed groups, local UTC+08',xlim=(0,8760))
    ax.set_ylim(-.5,2.85)
    ax.set_title('Training roles and chronology',loc='left');ax.grid(axis='x',alpha=.7)
    fig.subplots_adjust(left=.19,right=.98,top=.85,bottom=.22);save(fig,'forecasting','02_training_roles')


def forecast_models():
    global _FORECAST
    if _FORECAST is None:
        import torch
        torch.set_num_threads(4)
        models,pre,_=fine.load(ROOT/'models/forecast_seasonal','cpu')
        gate,gpre,_=fine.load(ROOT/'models/forecast_gate_mse','cpu');models.update(gate);pre.update(gpre)
        original,original_pre,_=old.load_forecasters(ROOT/'models/forecast_base','cpu')
        mixing={r['source']:float(r['fine_weight']) for r in rows('models/forecast_mixing.csv')}
        _FORECAST=models,pre,original,original_pre,mixing
    return _FORECAST


def forecast_training_summary():
    selected=pd.read_csv(ROOT/'models/forecast_seasonal/selection.csv');r=[]
    for source in SOURCES:
        table=pd.read_csv(ROOT/('models/forecast_gate_mse/training.csv' if source=='gate' else 'models/forecast_seasonal/training.csv'))
        if source!='gate':table=table[(table.source==source)&(table.loss==selected.set_index('source').loc[source,'loss'])]
        table=table.copy();table['source']=source;r.append(table)
    return pd.concat(r,ignore_index=True)[['source','training_seed','loss','epochs','best_epoch','parameters','training_seconds']]


def forecast_training_plot():
    summary=forecast_training_summary();fig,axes=plt.subplots(2,2,figsize=(12,7))
    colors=[BLUE,ORANGE,OLIVE]
    for ax,source in zip(axes.flat,SOURCES):
        for color,(_,r) in zip(colors,summary[summary.source==source].iterrows()):
            base=ROOT/('models/forecast_gate_mse' if source=='gate' else 'models/forecast_seasonal')
            df=pd.read_csv(base/source/r['loss']/str(r['training_seed'])/'epochs.csv')
            ax.plot(df.epoch,df.validation_mae,color=color,marker='o',ms=3,label='seed'+str(r['training_seed']))
            best=int(r.best_epoch);value=df.set_index('epoch').loc[best,'validation_mae']
            ax.scatter([best],[value],marker='D',s=35,edgecolor=INK,facecolor=color,zorder=4)
        ax.set(title=source.title(),xlabel='Fine-tuning epoch',ylabel='Early-stop MAE · '+UNITS[source]);ax.grid(axis='y');ax.xaxis.set_major_locator(MaxNLocator(integer=True));ax.legend(fontsize=9)
    fig.suptitle('Actual selected-model learning curves · diamonds mark saved best epochs',x=.08,ha='left',fontsize=15)
    fig.subplots_adjust(hspace=.43,wspace=.27,top=.87,bottom=.09,left=.08,right=.98);save(fig,'forecasting','03_learning_curves')


def forecast_metrics():
    output=[]
    for source in SOURCES:
        measured=[];predicted=[]
        for seed in ROLES['test']:
            target=pd.read_csv(ROOT/f'datasets/study/{seed}/targets_hourly.csv').set_index('hour')
            fc=pd.read_csv(ROOT/f'results/study/replays/{seed}/forecasts.csv')
            fc=fc[(fc.source==source)&(fc.model=='tuned')].set_index('hour')
            hours=np.arange(7008,8760);actual=pd.to_numeric(target.loc[hours,source]).to_numpy();known=np.isfinite(actual)
            measured.extend(actual[known]);predicted.extend(fc.loc[hours,'prediction'].to_numpy()[known])
        actual=np.array(measured);error=np.array(predicted)-actual
        output.append(dict(source=source,targets=len(actual),MAE=np.abs(error).mean(),RMSE=np.sqrt(np.mean(error**2)),
            MAE_percent_of_mean=100*np.abs(error).mean()/actual.mean(),RMSE_percent_of_mean=100*np.sqrt(np.mean(error**2))/actual.mean(),units=UNITS[source]))
    frame=pd.DataFrame(output);(ROOT/'results/notebook_metrics').mkdir(parents=True,exist_ok=True)
    frame.to_csv(ROOT/'results/notebook_metrics/forecast_metrics.csv',index=False)
    return frame


def forecast_error_plot(table):
    fig,axes=plt.subplots(2,2,figsize=(12,7))
    for ax,source in zip(axes.flat,SOURCES):
        r=table.set_index('source').loc[source];values=[float(r.MAE),float(r.RMSE)]
        ax.bar(['MAE','RMSE'],values,color=[BLUE,ORANGE],width=.6)
        for i,v in enumerate(values):ax.text(i,v*1.025,f'{v:.3f}',ha='center',va='bottom',fontsize=10)
        ax.set(title=source.title(),ylabel=UNITS[source],ylim=(0,max(values)*1.18));ax.grid(axis='y')
    fig.suptitle('Final forecasting performance · all three test replays',x=.08,ha='left',fontsize=15)
    fig.subplots_adjust(hspace=.4,wspace=.27,top=.88,bottom=.08,left=.08,right=.98);save(fig,'forecasting','04_test_errors')


def forecast_week(seed,start,hours):
    fc=pd.read_csv(ROOT/f'results/study/replays/{seed}/forecasts.csv')
    target=pd.read_csv(ROOT/f'datasets/study/{seed}/targets_hourly.csv').set_index('hour');times=np.arange(start,start+hours)
    dates=pd.to_datetime(target.loc[times,'start_time']);fig,axes=plt.subplots(4,1,figsize=(13,11),sharex=True)
    for ax,source in zip(axes,SOURCES):
        p=fc[(fc.source==source)&(fc.model=='tuned')].set_index('hour').loc[times,'prediction'].to_numpy()
        y=pd.to_numeric(target.loc[times,source]).to_numpy();ax.plot(dates,y,color=BLUE,lw=1.5,label='Measured synthetic')
        ax.plot(dates,p,color=ORANGE,lw=1.5,ls='--',label='Forecast');ax.set(ylabel=UNITS[source],title=source.title(),ylim=(0,None));ax.grid(axis='y')
        ax.legend(loc='upper right',ncol=2,fontsize=9)
    axes[-1].set_xlabel('Local time UTC+08 · gaps preserve missing measurements')
    fig.suptitle(f'Measured vs forecast · selected replay{seed} · one shared week',x=.09,ha='left',fontsize=15)
    fig.subplots_adjust(hspace=.45,top=.92,bottom=.08,left=.09,right=.98);save(fig,'forecasting','05_measured_vs_forecast')


def verify_forecast_inference(seed,hours):
    models,pre,original,op,mix=forecast_models();hourly=rows(f'datasets/study/{seed}/hourly.csv')
    fc=pd.read_csv(ROOT/f'results/study/replays/{seed}/forecasts.csv');result=[]
    for source in SOURCES:
        raw=source_inputs(hourly,source);parts=fine.prepared(raw,hours,pre[source]);value=np.mean([fine.estimate(m,parts,float(pre[source]['scale'][0]),'cpu') for m in models[source]],axis=0)
        old_parts=inputs(raw,hours,op[source]);prior=np.mean([predict('lstm',original[(source,s)],old_parts,raw,hours,op[source],'cpu') for s in [11,22,33]],axis=0)
        value=mix[source]*value+(1-mix[source])*prior
        expected=fc[(fc.source==source)&(fc.model=='tuned')].set_index('hour').loc[hours,'prediction'].to_numpy()
        result.append(dict(source=source,hours=len(hours),max_absolute_difference=float(np.max(np.abs(value-expected)))))
    return pd.DataFrame(result)


def detector_records(role,legacy=False):
    if legacy:
        plans=pd.read_csv(ROOT/'results/usage_detector/plan.csv');plans=plans[plans.role==role]
    else:plans=pd.DataFrame([dict(seed=s,role=role) for s in ROLES[role]])
    result=[]
    for p in plans.to_dict('records'):
        seed=int(p['seed']);folder=ROOT/('results/usage_detector' if legacy else 'results/study')/'replays'/str(seed)
        f=pd.read_csv(folder/'features.csv');x=f[FEATURES].to_numpy()
        if not legacy:
            c=pd.read_csv(folder/'checkin_context.csv');assert np.array_equal(c.end_hour,f.end_hour);x=np.column_stack((x,c[CONTEXT].to_numpy()))
        ends=f.end_hour.to_numpy();cutoff=(8760 if legacy else 7008) if role=='development' else 8832
        reviews=rows(f"datasets/{'training' if legacy else 'study'}/{seed}/app_reviews.csv")
        result.append(dict(seed=seed,role=role,x=x,ends=ends,eligible=f.eligible.to_numpy(dtype=bool),
            labels={t:review_labels(reviews,ends,t,cutoff) for t in ['emergency','usage_anomaly']}))
    return result


def label_summary(records):
    return pd.DataFrame([dict(seed=r['seed'],role=r['role'],known=int(np.isfinite(r['labels']['emergency']).sum()),positive=int(np.sum(r['labels']['emergency']==1)),unknown=int(np.isnan(r['labels']['emergency']).sum()),eligible_hours=int(r['eligible'].sum())) for r in records])


def load_emergency():return joblib.load(ROOT/'models/emergency_detector.joblib')


def refit_emergency(records):
    x=np.concatenate([r['x'] for r in records]);y=np.concatenate([r['labels']['emergency'] for r in records]);ok=np.concatenate([r['eligible'] for r in records]);use=np.isfinite(y)&ok
    model=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=7,min_samples_leaf=15,l2_regularization=5.,class_weight='balanced',early_stopping=False,random_state=44)
    t=time.monotonic()
    with threadpool_limits(limits=4):model.fit(x[use],y[use])
    frozen=load_emergency();np.testing.assert_allclose(old.scores(model,x[use][:300]),old.scores(frozen['classifier'],x[use][:300]),rtol=0,atol=1e-12)
    return model,pd.DataFrame([dict(target='emergency',training_rows=int(use.sum()),positives=int((y[use]==1).sum()),features=x.shape[1],boosting_iterations=model.n_iter_,notebook_refit_seconds=time.monotonic()-t)])


def scored_arrays(model,records,target='emergency',reviewed_only=False):
    y=[];s=[];ok=[]
    for r in records:
        keep=r['ends']%3==0 if reviewed_only else np.ones(len(r['ends']),bool)
        y.extend(r['labels'][target][keep]);s.extend(old.scores(model,r['x'])[keep]);ok.extend(r['eligible'][keep])
    return np.array(y),np.array(s),np.array(ok)


def boosting_progress(model,development,calibration):
    fig,ax=plt.subplots(figsize=(11,4.5))
    for records,label,color in [(development,'Development',BLUE),(calibration,'Calibration',ORANGE)]:
        x=np.concatenate([r['x'] for r in records]);y=np.concatenate([r['labels']['emergency'] for r in records]);ok=np.concatenate([r['eligible'] for r in records]);keep=np.isfinite(y)&ok
        with threadpool_limits(limits=4):loss=[log_loss(y[keep],prob,labels=[0,1]) for prob in model.staged_predict_proba(x[keep])]
        ax.plot(np.arange(1,len(loss)+1),loss,label=label,color=color)
    ax.set(title='Emergency booster progression · reconstructed staged log loss',xlabel='Boosting iteration',ylabel='Unweighted log loss');ax.grid(axis='y');ax.legend()
    fig.subplots_adjust(left=.1,right=.98,top=.88,bottom=.17);save(fig,'detection','02_training_progress')


def calibration_plot(candidates,threshold):
    frame=pd.DataFrame(candidates);selected=frame[np.isclose(frame.threshold,threshold,rtol=0,atol=1e-15)].iloc[0]
    fig,axes=plt.subplots(1,2,figsize=(12,4.5));recall=frame.recall_counting_abstentions_as_misses*100
    axes[0].plot(recall,frame.precision*100,color=BLUE,lw=1.7);axes[0].axvline(90,color=GREY,ls='--',label='Recall floor90%')
    axes[0].scatter([selected.recall_counting_abstentions_as_misses*100],[selected.precision*100],s=75,color=ORANGE,zorder=4,label='Frozen choice')
    axes[0].set(xlabel='Recall including positive abstentions (%)',ylabel='Confirmed-interval precision (%)',xlim=(0,101),ylim=(0,104),title='Validation operating trade-off');axes[0].legend(fontsize=9)
    axes[1].plot(frame.threshold,recall,color=BLUE,label='Recall');axes[1].plot(frame.threshold,frame.precision*100,color=ORANGE,ls='--',label='Precision')
    axes[1].axvline(threshold,color=INK,ls=':',label=f'Chosen{threshold:.4f}');axes[1].set(xlabel='Classifier score threshold',ylabel='Confirmed-interval metric (%)',ylim=(0,104),title='Validation threshold sensitivity');axes[1].legend(fontsize=9)
    for ax in axes:ax.grid(axis='y')
    fig.subplots_adjust(left=.07,right=.98,wspace=.26,bottom=.17,top=.87);save(fig,'detection','03_validation_tradeoff')


def metric_row(y,s,t,ok):
    m=confusion(y,s,t,ok);misses=m['FN']+m['abstained_positive_intervals']
    m['FN_including_positive_abstentions']=misses;m['F1_including_positive_abstentions']=2*m['TP']/(2*m['TP']+m['FP']+misses) if 2*m['TP']+m['FP']+misses else 0.
    return m


def emergency_metrics(model,threshold,records):
    result=[]
    for r in records:
        y,s,ok=scored_arrays(model,[r],reviewed_only=True);result.append(dict(seed=r['seed'],**metric_row(y,s,threshold,ok)))
    y,s,ok=scored_arrays(model,records,reviewed_only=True);m=metric_row(y,s,threshold,ok);result.append(dict(seed='pooled',**m))
    expected=pd.read_csv(ROOT/'results/study/confusion_matrices.csv');expected=expected[(expected.role=='test')&(expected.seed=='pooled')].iloc[0]
    for n in ['TP','FP','TN','FN','abstained_positive_intervals']:assert int(expected[n])==m[n]
    assert np.isclose(m['precision'],.9375) and np.isclose(m['recall_counting_abstentions_as_misses'],75/85)
    frame=pd.DataFrame(result);(ROOT/'results/notebook_metrics').mkdir(parents=True,exist_ok=True);frame.to_csv(ROOT/'results/notebook_metrics/emergency_metrics.csv',index=False)
    return frame[['seed','TP','FP','TN','FN','abstained_positive_intervals','precision','recall','recall_counting_abstentions_as_misses','f1','F1_including_positive_abstentions']]


def confusion_plot(row):
    matrix=np.array([[row['TN'],row['FP']],[row['FN'],row['TP']]],dtype=int);fig,ax=plt.subplots(figsize=(7,5))
    image=ax.imshow(matrix,cmap='Blues',vmin=0);names=[['TN','FP'],['FN','TP']]
    for i in range(2):
        for j in range(2):ax.text(j,i,f'{names[i][j]}\n{matrix[i,j]:,}',ha='center',va='center',fontsize=20,color='white' if matrix[i,j]>matrix.max()*.5 else INK)
    ax.set(xticks=[0,1],xticklabels=['No alert','Alert'],yticks=[0,1],yticklabels=['Confirmed normal','Confirmed emergency'],xlabel='Model decision',ylabel='Family ground truth',title='Fresh test · covered, confirmed3h intervals')
    fig.colorbar(image,ax=ax,label='Interval count',shrink=.75);fig.text(.1,.035,'Excluded from matrix:1 positive +7 negative abstentions;430 unknown labels.\nPrimary recall counts the positive abstention as an additional miss.',fontsize=9)
    fig.subplots_adjust(left=.25,right=.93,bottom=.2,top=.88);save(fig,'detection','04_confusion_matrix')


def episode_summary():
    a=pd.read_csv(ROOT/'results/study/oracle_episode_metrics.csv');a=a[a.role=='test'];e=pd.read_csv(ROOT/'results/study/oracle_episode_results.csv');e=e[e.role=='test'];delays=e.loc[e.detected==1,'delay_hours']
    return pd.DataFrame([dict(episodes=int(a.episodes.sum()),detected=int(a.detected_episodes.sum()),missed=int(a.episodes.sum()-a.detected_episodes.sum()),episode_recall=a.detected_episodes.sum()/a.episodes.sum(),alert_groups=int(a.alert_episodes.sum()),false_alert_groups=int(a.false_alerts.sum()),grouped_alert_precision=(a.alert_episodes.sum()-a.false_alerts.sum())/a.alert_episodes.sum(),false_groups_per30_household_days=a.false_alerts.sum()*30/219,median_delay_hours=delays.median(),p90_delay_hours=delays.quantile(.9))])


def episode_results_plot():
    a=pd.read_csv(ROOT/'results/study/oracle_episode_metrics.csv');a=a[a.role=='test'];fig,axes=plt.subplots(1,2,figsize=(12,4.5));x=np.arange(3)
    detected=a.detected_episodes.to_numpy();missed=(a.episodes-a.detected_episodes).to_numpy()
    axes[0].bar(x,detected,color=BLUE,label='Detected');axes[0].bar(x,missed,bottom=detected,color=ORANGE,label='Missed',hatch='//')
    for i,(d,m) in enumerate(zip(detected,missed)):axes[0].text(i,d/2,str(d),ha='center',va='center',color='white');axes[0].text(i,10.3,f'{d}/10',ha='center')
    axes[0].set(title='Every daytime emergency remains in the denominator',ylabel='Emergency episodes',ylim=(0,12));axes[0].legend(loc='upper right',fontsize=9)
    axes[1].bar(x,a.false_alerts,color=ORANGE)
    for i,v in enumerate(a.false_alerts):axes[1].text(i,v+.1,str(v),ha='center')
    axes[1].set(title='Alert burden · unmatched grouped hourly alarms',ylabel='False alert groups per73-day replay',ylim=(0,6))
    for ax in axes:ax.set_xticks(x,[str(v) for v in a.seed]);ax.grid(axis='y')
    fig.subplots_adjust(left=.07,right=.98,bottom=.15,top=.88,wspace=.26);save(fig,'detection','05_episode_outcomes')


def emergency_timeline(model,threshold,records,seed):
    r=next(v for v in records if v['seed']==seed);e=pd.read_csv(ROOT/f'datasets/study/{seed}/truth/assistance_episodes.csv');e=e[(e.start_slot/4>=7008)&(e.end_slot/4<=8760)].sort_values('start_slot').iloc[0]
    onset=e.start_slot/4;end=e.end_slot/4;take=(r['ends']>=onset-12)&(r['ends']<=end+12);h=r['ends'][take];score=old.scores(model,r['x'])[take]
    dates=pd.to_datetime([g.timestamp(v*4) for v in h+.5]);a=pd.Timestamp(g.timestamp(onset*4));b=pd.Timestamp(g.timestamp(end*4))
    fig,axes=plt.subplots(2,1,figsize=(13,6),sharex=True)
    axes[0].plot(dates,score,color=BLUE,marker='o',ms=3,label='Emergency score');axes[0].axhline(threshold,color=ORANGE,ls='--',label=f'Frozen threshold{threshold:.4f}')
    axes[0].set(ylabel='Classifier score',ylim=(0,1.05));axes[0].legend(loc='lower right',fontsize=9)
    ctx=r['x'][take,-len(CONTEXT):];axes[1].step(dates,ctx[:,3],where='mid',color=BLUE,label='Observed missed check-ins, past3h')
    axes[1].step(dates,ctx[:,4],where='mid',color=ORANGE,ls='--',label='Unknown opportunities, past3h');axes[1].set(ylabel='Response opportunities',xlabel='Decision time · local UTC+08');axes[1].legend(fontsize=9)
    for ax in axes:ax.axvspan(a,b,color=GREY,alpha=.16,label='Ground-truth assistance interval');ax.grid(axis='y')
    fig.suptitle(f'Worked example · replay{seed} · one daytime emergency episode',x=.08,ha='left',fontsize=14)
    fig.text(.08,.015,'Grey span is simulator truth used for evaluation only; the classifier never receives it.',fontsize=9)
    fig.subplots_adjust(left=.08,right=.98,bottom=.14,top=.88,hspace=.18);save(fig,'detection','06_selected_episode')


def refit_utility():
    records=detector_records('development',legacy=True);x=np.concatenate([r['x'] for r in records]);y=np.concatenate([r['labels']['usage_anomaly'] for r in records]);eligible=np.concatenate([r['eligible'] for r in records]);use=np.isfinite(y)&eligible
    model=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=31,min_samples_leaf=15,l2_regularization=2.,class_weight=None,early_stopping=False,random_state=44)
    with threadpool_limits(limits=4):model.fit(x[use],y[use])
    frozen=joblib.load(ROOT/'models/usage_anomaly_detector.joblib');np.testing.assert_allclose(old.scores(model,x[use][:300]),old.scores(frozen['classifier'],x[use][:300]),rtol=0,atol=1e-12)
    return model,pd.DataFrame([dict(target='usage_anomaly',training_rows=int(use.sum()),positives=int((y[use]==1).sum()),features=x.shape[1],boosting_iterations=model.n_iter_,threshold=frozen['threshold'])])


def utility_metrics(model,records):
    threshold=joblib.load(ROOT/'models/usage_anomaly_detector.joblib')['threshold'];output=[];yy=[];ss=[];ee=[]
    for r in records:
        take=r['ends']%3==0;y=r['labels']['usage_anomaly'][take];s=old.scores(model,r['x'][:,:len(FEATURES)])[take];ok=r['eligible'][take]
        yy.extend(y);ss.extend(s);ee.extend(ok);output.append(dict(seed=r['seed'],**metric_row(y,s,threshold,ok)))
    output.append(dict(seed='pooled',**metric_row(np.array(yy),np.array(ss),threshold,np.array(ee))));frame=pd.DataFrame(output)
    frame.to_csv(ROOT/'results/notebook_metrics/utility_anomaly_metrics.csv',index=False)
    return frame[['seed','TP','FP','TN','FN','abstained_positive_intervals','precision','recall','recall_counting_abstentions_as_misses','f1']]
