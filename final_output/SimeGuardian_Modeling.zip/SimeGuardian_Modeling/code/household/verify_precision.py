"""Verify the precision study's frozen inputs, calibration and saved decisions."""
import argparse
import hashlib
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g
    from .precision_study import ROLES,FEATURES
    from .revised_protocol import FEATURES as OLD_FEATURES
    from .multisource_dataset import LABELS,SOURCES
    from .validate import read
    from .train import hour_number
    from .evaluation_v2 import verify
    from .two_stage import model_scores
else:
    import generate as g
    from precision_study import ROLES,FEATURES
    from revised_protocol import FEATURES as OLD_FEATURES
    from multisource_dataset import LABELS,SOURCES
    from validate import read
    from train import hour_number
    from evaluation_v2 import verify
    from two_stage import model_scores


def run(data,base,out):
    checks=[]
    def check(name,condition,rows=''):
        if not condition:raise AssertionError(name)
        checks.append(dict(check=name,passed=1,rows=rows))
    for root in [data,base,out,Path('ml/household/multisource_data_v5'),Path('ml/household/multisource_data_v4'),Path('ml/household/runs/two-stage-v4')]:verify(root)
    cfg={r['parameter']:r['value'] for r in read(out/'config.csv')}
    for name,root in [('base',base),('data',data)]:
        check(name+' manifest matches frozen configuration',cfg[name+'_manifest']==hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest())
    plan=read(data/'plan.csv')
    check('fixed disjoint seed roles; every planned seed retained',len({r['seed'] for r in plan})==9 and
        {(r['role'],int(r['seed'])) for r in plan}=={(role,s) for role,seeds in ROLES.items() for s in seeds})
    reviews={};targets={}
    for r in plan:
        seed=int(r['seed']);root=data/str(seed);verify(root)
        config={v['parameter']:v['value'] for v in read(root/'config.csv')}
        assert config['version']=='multisource-two-stage-v5' and int(config['seed'])==seed
        reviews[seed]={int(x['end_hour_exclusive']):x for x in read(root/'app_reviews.csv')}
        targets[seed]=read(root/'targets_hourly.csv')
        assert {x['household_id'] for x in read(root/'hourly.csv')}=={'HH001'}
    check('unchanged v5 simulator and same one-family contract across all nine replays',True,9)
    for r in read(out/'detector_training_labels.csv'):
        seed,h=int(r['seed']),int(r['end_hour']);target=r['target'];review=reviews[seed][h]
        assert seed in ROLES['development'] and 3600<h<=7008
        assert review[target+'_label']==r['label'] and hour_number(review[target+'_available_at'])<=7008
    check('detector supervision uses only timely development family labels',True,len(read(out/'detector_training_labels.csv')))
    selections={r['target']:r for r in read(out/'selection.csv')}
    models={t:joblib.load(out/(t+'_detector.joblib')) for t in LABELS}
    old={t:joblib.load(base/(t+'_detector.joblib')) for t in LABELS}
    old_thresholds={r['target']:float(r['threshold']) for r in read(base/'thresholds.csv') if r['system']=='learned_detector'}
    x_by_seed={};f_by_seed={}
    for role,seeds in ROLES.items():
        for seed in seeds:
            folder=out/'replays'/str(seed);features=read(folder/'features.csv')
            x=np.array([[float(r[k]) for k in FEATURES] for r in features]);x_by_seed[seed]=x
            f_by_seed[seed]={int(r['end_hour']):r for r in features}
            forecast=defaultdict(list)
            for r in read(folder/'forecasts.csv'):
                assert r['role']==role and int(r['seed'])==seed and int(r['training_seed']) in [11,22,33]
                forecast[(r['source'],int(r['hour']))].append((int(r['training_seed']),float(r['prediction'])))
            for key,rows in forecast.items():assert sorted(s for s,v in rows)==[11,22,33]
            expected_count=3408 if role=='development' else 1752
            assert len(forecast)==4*expected_count
            for m in read(folder/'forecast_metrics.csv'):
                if m['model']!='ensemble':continue
                source=m['source'];error=[]
                for (s,h),rows in forecast.items():
                    if s==source and targets[seed][h][s]!='':error.append(np.mean([v for _,v in rows])-float(targets[seed][h][s]))
                assert len(error)==int(m['targets'])
                assert abs(np.abs(error).mean()-float(m['mae']))<1e-10
                assert abs(np.sqrt(np.square(error).mean())-float(m['rmse']))<1e-10
            for h,f in f_by_seed[seed].items():
                available=0.
                for source,w in zip(SOURCES,[.4,.3,.15,.15]):
                    tt=targets[seed][h-3:h]
                    valid=all(r[source]!='' and hour_number(r[source+'_available_at'])<=h+.5 for r in tt)
                    assert float(f[source+'_available'])==valid
                    if valid:
                        values=np.array([float(r[source]) for r in tt])
                        assert abs(float(f[source+'_observed_mean'])-values.mean())<1e-10
                        assert abs(float(f[source+'_observed_min'])-values.min())<1e-10
                        assert abs(float(f[source+'_observed_max'])-values.max())<1e-10
                        assert abs(float(f[source+'_observed_std'])-values.std())<1e-10
                        available+=w
                    else:assert float(f[source+'_observed_mean'])==0.
                assert int(f['eligible'])==(available>=.7-1e-12)
    check('all three frozen LSTM seeds contribute to every replay forecast; metrics reproduce',True,9)
    check('source statistics and availability use only timely completed observations',True,sum(map(len,f_by_seed.values())))
    for target,m in models.items():
        assert m['feature_names']==FEATURES and float(selections[target]['threshold'])==m['threshold']
    decisions=read(out/'decisions.csv');groups=defaultdict(list)
    for role,seeds in ROLES.items():
        if role=='development':continue
        for seed in seeds:
            x=x_by_seed[seed]
            for target,m in models.items():
                with threadpool_limits(limits=4):new=m['classifier'].predict_proba(x)[:,1]
                prior=model_scores(old[target],x[:,:len(OLD_FEATURES)])
                rr=[r for r in decisions if int(r['seed'])==seed and r['target']==target]
                for system,expected,threshold in [('precision_detector',new,m['threshold']),('v5_frozen_detector',prior,old_thresholds[target])]:
                    own=[r for r in rr if r['system']==system]
                    assert len(own)==len(expected)
                    for r,p in zip(own,expected):
                        h=int(r['end_hour']);review=reviews[seed].get(h)
                        label=review[target+'_label'] if review and hour_number(review[target+'_available_at'])<=8832 else ''
                        assert r['app_label']==label and abs(float(r['score'])-p)<1e-12
                        assert r['eligible']==f_by_seed[seed][h]['eligible']
                        assert int(r['alarm'])==(r['eligible']=='1' and p>threshold)
                        groups[(role,seed,target,system)].append(r)
    check('both new and original saved classifiers reproduce every score and decision',True,len(decisions))
    for m in read(out/'confusion_matrices.csv'):
        seeds=ROLES[m['role']] if m['seed']=='pooled' else [int(m['seed'])]
        rr=[r for seed in seeds for r in groups[(m['role'],seed,m['target'],m['system'])]]
        counts=dict(TP=0,FP=0,TN=0,FN=0);unknown=abstained=positive_abstained=0
        for r in rr:
            if r['app_label']=='':unknown+=1;continue
            if r['eligible']=='0':
                abstained+=1;positive_abstained+=r['app_label']=='1';continue
            key=('T' if r['app_label']==r['alarm'] else 'F')+('P' if r['alarm']=='1' else 'N');counts[key]+=1
        assert all(int(m[k])==v for k,v in counts.items())
        assert int(m['unlabelled_intervals'])==unknown and int(m['abstained_labelled_intervals'])==abstained
        assert int(m['abstained_positive_intervals'])==positive_abstained
        if counts['TP']+counts['FP']:assert abs(float(m['precision'])-counts['TP']/(counts['TP']+counts['FP']))<1e-12
    check('independent TP/FP/TN/FN, precision, unknown and abstention arithmetic',True,len(read(out/'confusion_matrices.csv')))
    for target,m in models.items():
        rr=[r for seed in ROLES['calibration'] for r in groups[('calibration',seed,target,'precision_detector')]
            if r['eligible']=='1' and r['app_label']!='']
        values=sorted(set(float(r['score']) for r in rr));pick=np.inf;best=(-1,-np.inf,-np.inf)
        for threshold in [np.nextafter(values[0],-np.inf)]+values:
            tp=sum(r['app_label']=='1' and float(r['score'])>threshold for r in rr)
            fp=sum(r['app_label']=='0' and float(r['score'])>threshold for r in rr)
            if tp+fp<20 or tp/(tp+fp)<float(cfg['calibration_precision']):continue
            key=(tp,-fp,threshold)
            if key>best:best=key;pick=threshold
        assert pick==m['threshold']
        candidates=[r for r in read(out/'candidate_metrics.csv') if r['target']==target and r['qualified']=='1']
        chosen=max(candidates,key=lambda r:(int(r['TP']),-int(r['FP'])))
        assert selections[target]['candidate']==chosen['candidate']
    check('model and threshold selection independently reproduce from calibration only',True,2)
    event_rows=read(out/'oracle_episode_results.csv')
    for m in read(out/'oracle_episode_metrics.csv'):
        key=(m['role'],int(m['seed']),m['target'],m['system']);rows=groups[key]
        events=[e for e in event_rows if (e['role'],int(e['seed']),e['target'],e['system'])==key]
        flags=[r['alarm']=='1' for r in rows];alert_groups=[]
        for i,flag in enumerate(flags):
            if flag:
                if i==0 or not flags[i-1]:alert_groups.append([])
                alert_groups[-1].append(i)
        matched=set();detected=0;delays=[];duplicates=0;during_any=set()
        for e in events:
            a,b=float(e['start_hour']),float(e['end_hour'])
            during={i for i,r in enumerate(rows) if int(r['end_hour'])>np.floor(a) and a<int(r['end_hour'])+.5<b}
            during_any|=during
            hits=[j for j,g in enumerate(alert_groups) if during.intersection(g)]
            matched.update(hits);detected+=bool(hits);duplicates+=max(0,len(hits)-1)
            assert int(e['detected'])==bool(hits)
            assert int(e['observable'])==any(rows[i]['eligible']=='1' for i in during)
            if hits:
                delay=min(int(rows[i]['end_hour'])+.5-a for i in during if flags[i]);delays.append(delay)
                assert abs(delay-float(e['delay_hours']))<1e-10
        assert int(m['detected_episodes'])==detected and int(m['alert_episodes'])==len(alert_groups)
        assert int(m['false_alerts'])==len(alert_groups)-len(matched)
        assert abs(float(m['false_alerts_per_30_days'])-(len(alert_groups)-len(matched))*30/73)<1e-10
        assert int(m['duplicate_alerts'])==duplicates
        assert int(m['false_flagged_decisions'])==sum(flag and i not in during_any for i,flag in enumerate(flags))
        if delays:
            assert float(m['median_delay_hours'])==np.median(delays)
            assert float(m['p90_delay_hours'])==np.percentile(delays,90)
    check('independent episode matches, alert groups, outage misses, delays and monthly denominators',True,len(read(out/'oracle_episode_metrics.csv')))
    check('no JSON/NPZ datasets introduced',not any(p.suffix in ['.json','.jsonl','.npz'] for root in [data,out] for p in root.rglob('*')))
    g.write_csv(out.with_name(out.name+'-verification.csv'),checks)
    print('\n'.join(r['check']+': PASS' for r in checks))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=Path('ml/household/precision_data_v6'))
    parser.add_argument('--base',type=Path,default=Path('ml/household/runs/two-stage-v5'))
    parser.add_argument('--run',type=Path,default=Path('ml/household/runs/precision-v6'))
    args=parser.parse_args();run(args.data,args.base,args.run)
