"""An explicitly easier synthetic daytime/check-in benchmark, not real-world evidence."""
import argparse
import hashlib
import shutil
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g, forecast_finetune as fine, precision_study as old, tuned_study as tuned
    from .multisource_dataset import build, SOURCES
    from .recall_study import recall_threshold
    from .two_stage import confusion, episode_audit
    from .train import hour_number
    from .validate import read
    from .evaluation_v2 import verify, fresh_output, manifest
else:
    import generate as g
    import forecast_finetune as fine
    import precision_study as old
    import tuned_study as tuned
    from multisource_dataset import build, SOURCES
    from recall_study import recall_threshold
    from two_stage import confusion, episode_audit
    from train import hour_number
    from validate import read
    from evaluation_v2 import verify, fresh_output, manifest

ROLES=dict(development=[20261101,20261102,20261103],calibration=[20261104,20261105,20261106],test=[20261107,20261108,20261109])
CONTEXT=['scheduled3h','known3h','responded3h','missed3h','unknown3h','known_fraction3h']


def context(ends,targets,events):
    """Known response opportunities and arrived self-actions, never family review labels."""
    output=[]
    for end in ends:
        end=int(end);cut=end+.5;scheduled=known=responded=0
        for h in range(end-3,end):
            if not 8<=h%24<22:continue
            scheduled+=1;r=targets[h]
            available=bool(r['app']) and hour_number(r['app_available_at'])<=cut
            if not available:continue
            known+=1
            responded+=any(e['source']=='app' and e['event_type']=='agreed_self_checkin' and e['claimed_resident_id']=='E1'
                and e['attribution']=='verified' and e['meaningful']=='1' and hour_number(e['received_at'])<=cut
                and h<=hour_number(e['event_time'])<h+1 for e in events.get(h,[]))
        output.append([scheduled,known,responded,known-responded,scheduled-known,known/scheduled if scheduled else 0.])
    return np.array(output,dtype=float)


def prepare(data):
    fresh_output(data);plans=[]
    for role,seeds in ROLES.items():
        for seed in seeds:
            root=data/str(seed);build(root,revised=True,seed=seed,illustrative_daytime=True)
            plans.append(dict(role=role,seed=seed,path=str(root),manifest_sha256=hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest(),end_hour=7008 if role=='development' else 8760,
                simulator='ILLUSTRATIVE DAYTIME v11; deliberately easier case mix and adherence'))
    g.write_csv(data/'plan.csv',plans);manifest(data)


def run(data,out,device):
    import torch
    verify(data);fresh_output(out,data)
    plans=read(data/'plan.csv');assert len(plans)==9
    for role,seeds in ROLES.items():assert {int(p['seed']) for p in plans if p['role']==role}==set(seeds)
    cfg=dict(benchmark='ILLUSTRATIVE ONLY; generator deliberately made easier; not comparable evidence of model improvement',
        changed='daytime-only6..9h cases capped21; hourly08..21 agreed checkins;99.5% healthy response; no forgotten-phone days',
        unchanged='family/activity sources; physical utility demand; independent feed outages/delays; family review generation',
        classifier='one fixed HGB:180iter,7leaves,L2=5,minleaf15,lr=.05,balanced,seed44',
        threshold='fewest FP subject to >=90% all-confirmed calibration recall; no test tuning',
        forecasting='reuse frozen separate source LSTMs/blending; not trained on these new test datasets',
        labels='delayed family confirmations only; never inputs; unknown excluded; positive abstentions counted as misses',device=device)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in cfg.items()]);g.write_csv(out/'plan.csv',plans)
    (out/'source').mkdir()
    for name in ['illustrative_study.py','revised_protocol.py','multisource_dataset.py','tuned_study.py','forecast_finetune.py','precision_study.py','recall_study.py','two_stage.py','train.py','generate.py','electricity_dataset.py','evaluation_v2.py','evaluation.py','validate.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    forecasters=Path('ml/household/runs/forecast-v7');gate=Path('ml/household/runs/forecast-v7-gate');base=Path('ml/household/runs/two-stage-v5');prior=Path('ml/household/runs/tuned-v8')
    for root in [forecasters,gate,base,prior]:verify(root)
    g.write_csv(out/'model_references.csv',[dict(path=str(root),manifest_sha256=hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()) for root in [forecasters,gate,base,prior]])
    models,pre,_=fine.load(forecasters,device);override,override_pre,_=fine.load(gate,device);models.update(override);pre.update(override_pre)
    old_models,old_pre,old_scales=old.load_forecasters(base,device)
    mixing_rows=read(prior/'forecast_mixing.csv');mixing={r['source']:float(r['fine_weight']) for r in mixing_rows}
    scales=np.array([float(next(r for r in mixing_rows if r['source']==s)['residual_scale']) for s in SOURCES])
    def replay(plan):
        r=tuned.replay(plan,models,pre,scales,old_models,old_pre,old_scales,mixing,out,device)
        events=defaultdict(list)
        for e in read(r['data']/'events.csv'):events[int(hour_number(e['event_time']))].append(e)
        c=context(r['ends'],read(r['data']/'targets_hourly.csv'),events);r['x']=np.column_stack((r['x'],c))
        g.write_csv(out/'replays'/str(r['seed'])/'checkin_context.csv',[dict(end_hour=int(h),**dict(zip(CONTEXT,v))) for h,v in zip(r['ends'],c)])
        return r
    development=[replay(p) for p in plans if p['role']=='development'];calibration=[replay(p) for p in plans if p['role']=='calibration']
    x=np.concatenate([r['x'] for r in development]);y=np.concatenate([r['labels']['emergency'] for r in development]);eligible=np.concatenate([r['eligible'] for r in development]);use=np.isfinite(y)&eligible
    clf=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=7,min_samples_leaf=15,l2_regularization=5.,class_weight='balanced',early_stopping=False,random_state=44)
    with threadpool_limits(limits=4):clf.fit(x[use],y[use])
    cy=np.concatenate([r['labels']['emergency'] for r in calibration]);ce=np.concatenate([r['eligible'] for r in calibration]);cs=np.concatenate([old.scores(clf,r['x']) for r in calibration])
    threshold,candidates=recall_threshold(cy,cs,ce)
    g.write_csv(out/'threshold_candidates.csv',candidates)
    joblib.dump(dict(classifier=clf,threshold=threshold,features=tuned.FEATURES+CONTEXT),out/'emergency_detector.joblib',compress=3)
    g.write_csv(out/'selection.csv',[dict(threshold=threshold,**confusion(cy,cs,threshold,ce))])
    g.write_csv(out/'training_labels.csv',[dict(seed=r['seed'],end_hour=int(h),label=int(v)) for r in development for h,v,ok in zip(r['ends'],r['labels']['emergency'],r['eligible']) if ok and np.isfinite(v)])
    for path in out.iterdir():
        if path.is_file():path.chmod(0o444)
    print('FROZEN classifier and validation threshold; scoring fresh test now',threshold,flush=True)
    tests=[replay(p) for p in plans if p['role']=='test'];metrics=[];decisions=[];audits=[];episodes_rows=[]
    for role,replays in [('calibration',calibration),('test',tests)]:
        yy=[];ss=[];ee=[]
        for r in replays:
            score=old.scores(clf,r['x']);label=r['labels']['emergency'];ok=r['eligible'];take=r['ends']%3==0
            yy.extend(label[take]);ss.extend(score[take]);ee.extend(ok[take])
            metrics.append(dict(role=role,seed=r['seed'],**confusion(label[take],score[take],threshold,ok[take])))
            decisions.extend(dict(role=role,seed=r['seed'],end_hour=int(h),score=float(v),eligible=int(e),alarm=int(e and v>threshold),app_label=int(y) if np.isfinite(y) else '',reviewed_endpoint=int(h%3==0)) for h,v,e,y in zip(r['ends'],score,ok,label))
            episodes=[dict(id=e['episode_id'],start=int(e['start_slot'])/4,end=int(e['end_slot'])/4,kind=e['kind']) for e in read(r['data']/'truth/assistance_episodes.csv') if int(e['start_slot'])/4>=r['start'] and int(e['end_slot'])/4<=r['end']]
            audit,events=episode_audit(r['ends'],np.where(ok,score,np.nan),threshold,episodes,r['start'],r['end'])
            audits.append(dict(role=role,seed=r['seed'],**audit));episodes_rows.extend(dict(role=role,seed=r['seed'],**e) for e in events)
        m=confusion(np.array(yy),np.array(ss),threshold,np.array(ee));metrics.append(dict(role=role,seed='pooled',**m));print(role,m,flush=True)
    for name,rows in [('confusion_matrices',metrics),('decisions',decisions),('oracle_episode_metrics',audits),('oracle_episode_results',episodes_rows)]:g.write_csv(out/(name+'.csv'),rows)
    manifest(out);verify(out);print('Frozen',out,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','run'])
    p.add_argument('--data',type=Path,default=Path('ml/household/illustrative_data_v11'));p.add_argument('--out',type=Path,default=Path('ml/household/runs/illustrative-v11'))
    p.add_argument('--device',choices=['cpu','mps'],default='cpu');a=p.parse_args()
    if a.action=='prepare':prepare(a.data)
    else:run(a.data,a.out,a.device)
