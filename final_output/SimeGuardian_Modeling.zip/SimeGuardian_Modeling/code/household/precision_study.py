"""Precision-first detector development with frozen source LSTMs and new replays."""
import argparse
import hashlib
import shutil
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g, revised_protocol as protocol
    from .multisource_dataset import build, validate, SOURCES, LABELS
    from .train import inputs, predict, small_lstm, hour_number
    from .two_stage import source_inputs, review_labels, confusion, episode_audit, model_scores
    from .validate import read
    from .evaluation_v2 import fresh_output, manifest, verify
else:
    import generate as g
    import revised_protocol as protocol
    from multisource_dataset import build, validate, SOURCES, LABELS
    from train import inputs, predict, small_lstm, hour_number
    from two_stage import source_inputs, review_labels, confusion, episode_audit, model_scores
    from validate import read
    from evaluation_v2 import fresh_output, manifest, verify

ROLES = dict(development=[20261029,20261030,20261031],
             calibration=[20261032,20261033,20261034],test=[20261035,20261036,20261037])
FEATURES = protocol.FEATURES + [s+'_'+k for s in SOURCES
    for k in ['observed_mean','forecast_mean','observed_min','observed_max','observed_std','shortfall_hours','excess_hours']]
FEATURES += ['hours_since_due','hours_since_self_checkin','personal_activity_3h','self_checkin_after_latest_due']
CANDIDATES = [dict(name=f'boost-leaves{leaves}-l2{l2}',kind='boost',leaves=leaves,l2=l2)
              for leaves in [3,7,15] for l2 in [1.,5.]]
CANDIDATES += [dict(name='forest-leaf4',kind='forest',leaves=4,l2=0.),
               dict(name='forest-leaf10',kind='forest',leaves=10,l2=0.)]


def precision_threshold(labels,scores,eligible,precision=.92,min_alerts=20):
    """Maximise recall subject to measured precision and a nontrivial alert count."""
    if not 0<precision<=1 or min_alerts<1:raise ValueError('Invalid precision operating constraint')
    labels=np.asarray(labels);scores=np.asarray(scores);eligible=np.asarray(eligible,bool)
    valid=np.isfinite(labels)&np.isfinite(scores)&eligible
    if not valid.any():return np.inf
    best=(-1,-np.inf,-np.inf);selected=np.inf
    unique=np.unique(scores[valid])
    for threshold in np.r_[np.nextafter(unique[0],-np.inf),unique]:
        m=confusion(labels,scores,threshold,eligible)
        if m['TP']+m['FP']<min_alerts or m['precision']<precision:continue
        key=(m['TP'],-m['FP'],float(threshold))
        if key>best:best=key;selected=float(threshold)
    return selected


def features(ends,forecast,y,arrival,events,scales):
    base,eligible,weighted=protocol.detector_features(ends,forecast,y,arrival,events,scales)
    extra=[]
    for end in ends:
        end=int(end);a=end-3;cut=end+.5;row=[]
        for j,source in enumerate(SOURCES):
            observed=y[a:end,j];expected=forecast[a:end,j]
            known=np.isfinite(observed).all() and (arrival[a:end,j]<=cut).all()
            row.extend([float(observed.mean()),float(expected.mean()),float(observed.min()),float(observed.max()),
                float(observed.std()),float(np.sum(expected-observed>scales[j])),
                float(np.sum(observed-expected>scales[j]))] if known else [0.]*7)
        due=[d*24+h for d in range(max(0,(end-24)//24),end//24+1) for h in protocol.CHECKIN_HOURS
             if end-24<=d*24+h and d*24+h+1<=end]
        personal=[e for h in range(max(0,end-48),end) for e in events.get(h,[]) if e['source'] in ['app','gate']
                  and e['resident']=='E1' and e['verified'] and e['meaningful'] and e['arrival']<=cut and e['time']<end]
        checkins=[e['time'] for e in personal if e['kind']=='agreed_self_checkin']
        last=max(checkins,default=end-48)
        row.extend([float(end-due[-1]) if due else 24.,min(48.,end-last),
                    float(sum(e['time']>=end-3 for e in personal)),float(bool(due) and last>=due[-1])])
        extra.append(row)
    x=np.column_stack((base,extra))
    if not np.isfinite(x).all():raise ValueError('Non-finite detection features')
    return x,eligible,weighted


def prepare(root):
    fresh_output(root)
    g.write_csv(root/'plan.csv',[dict(role=role,seed=seed,simulator='unchanged v5',
        fitting_hours='3600..7008' if role=='development' else '7008..8760',
        purpose='independent stochastic realisations of the same family archetype, not distinct households')
        for role,seeds in ROLES.items() for seed in seeds])
    (root/'plan.csv').chmod(0o444)
    for role,seeds in ROLES.items():
        for seed in seeds:build(root/str(seed),revised=True,seed=seed)
    manifest(root)


def load_forecasters(root,device):
    import torch
    verify(root)
    models={};pre={}
    for source in SOURCES:
        pre[source]=joblib.load(root/'forecasters'/source/'preprocessing.joblib')
        for seed in [11,22,33]:
            saved=torch.load(root/'forecasters'/source/str(seed)/'model.pt',map_location='cpu',weights_only=True)
            model=small_lstm(saved['channels']).to(device);model.load_state_dict(saved['state_dict'])
            models[(source,seed)]=dict(model=model,target_mean=saved['target_mean'],target_scale=saved['target_scale'])
    scales=np.array([float(next(r for r in read(root/'expected_weights.csv') if r['source']==s)['residual_scale']) for s in SOURCES])
    return models,pre,scales


def replay(root,seed,role,models,pre,scales,out,device):
    data=root/str(seed);validate(data)
    rows,targets,reviews=read(data/'hourly.csv'),read(data/'targets_hourly.csv'),read(data/'app_reviews.csv')
    y=np.array([[float(r[s]) if r[s] else np.nan for s in SOURCES] for r in targets])
    arrival=np.array([[hour_number(r[s+'_available_at']) for s in SOURCES] for r in targets])
    events=defaultdict(list)
    for r in read(data/'events.csv'):
        time=hour_number(r['event_time'])
        events[int(time)].append(dict(source=r['source'],time=time,arrival=hour_number(r['received_at']),
            resident=r['claimed_resident_id'],verified=r['attribution']=='verified',meaningful=r['meaningful']=='1',kind=r['event_type']))
    a,b=(3600,7008) if role=='development' else (7008,8760)
    times=np.arange(a,b);forecast=np.full((8760,4),np.nan);predictions=[];forecast_metrics=[]
    for j,source in enumerate(SOURCES):
        raw=source_inputs(rows,source);prepared=inputs(raw,times,pre[source]);all_predictions=[]
        for training_seed in [11,22,33]:
            pred=predict('lstm',models[(source,training_seed)],prepared,raw,times,pre[source],device)
            all_predictions.append(pred)
            predictions.extend(dict(seed=seed,role=role,source=source,training_seed=training_seed,hour=int(h),prediction=float(p))
                               for h,p in zip(times,pred))
        forecast[times,j]=np.mean(all_predictions,axis=0)
        for name,p in [('ensemble',forecast[times,j]),('seasonal_naive',np.where(np.isfinite(raw[times-168,0]),raw[times-168,0],pre[source]['median'][0]))]:
            ok=np.isfinite(y[times,j]);error=p[ok]-y[times[ok],j]
            forecast_metrics.append(dict(seed=seed,role=role,source=source,model=name,targets=int(ok.sum()),
                mae=float(np.abs(error).mean()),rmse=float(np.sqrt(np.mean(error**2)))))
    ends=np.arange(a+3,b+1,3);x,eligible,weighted=features(ends,forecast,y,arrival,events,scales)
    labels={t:review_labels(reviews,ends,t,7008 if role=='development' else 8832) for t in LABELS}
    folder=out/'replays'/str(seed)
    g.write_csv(folder/'forecasts.csv',predictions)
    g.write_csv(folder/'forecast_metrics.csv',forecast_metrics)
    g.write_csv(folder/'features.csv',[dict(seed=seed,role=role,end_hour=int(h),eligible=int(ok),
        **dict(zip(FEATURES,map(float,row)))) for h,row,ok in zip(ends,x,eligible)])
    print(f'Replayed {role} seed {seed}: {len(ends)} decisions',flush=True)
    return dict(seed=seed,role=role,x=x,eligible=eligible,weighted=weighted,labels=labels,ends=ends,start=a,end=b,data=data)


def classifier(spec,x,y):
    if spec['kind']=='boost':
        model=HistGradientBoostingClassifier(max_iter=150,learning_rate=.05,max_leaf_nodes=spec['leaves'],
            min_samples_leaf=15,l2_regularization=spec['l2'],class_weight='balanced',early_stopping=False,random_state=44)
    else:model=RandomForestClassifier(n_estimators=300,max_depth=10,min_samples_leaf=spec['leaves'],
            class_weight='balanced_subsample',max_features=.8,n_jobs=4,random_state=44)
    with threadpool_limits(limits=4):model.fit(x,y)
    return model


def scores(model,x):
    with threadpool_limits(limits=4):return model.predict_proba(x)[:,1]


def run(data,base,out,device='cpu',validation_only=False):
    import torch
    verify(data);fresh_output(out,data,base)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in dict(
        study='precision-v6',target_precision=.85,calibration_precision=.92,min_calibration_alerts=20,
        minimum_calibration_recall=.30,threshold='max TP subject to calibration constraints; fewer FP then higher threshold',
        selection='development fit then calibration selection; no test-driven seed or model selection',
        family='one archetype; independent simulator realisations, not independent households',
        simulator='unchanged v5 including benign forgotten-phone days, night emergencies and outages',
        forecasters='reuse all12 frozen v5 source LSTMs; no forecaster retuning',
        base_manifest=hashlib.sha256((base/'manifest.csv').read_bytes()).hexdigest(),
        data_manifest=hashlib.sha256((data/'manifest.csv').read_bytes()).hexdigest(),
        labels='delayed adjudicated family labels only; unknown excluded and abstentions reported',
        validation_only=validation_only,device=device,sklearn=sklearn.__version__,torch=torch.__version__).items()])
    (out/'config.csv').chmod(0o444);shutil.copy(data/'plan.csv',out/'plan.csv')
    g.write_csv(out/'candidate_grid.csv',CANDIDATES)
    (out/'source').mkdir()
    for name in ['precision_study.py','revised_protocol.py','multisource_dataset.py','two_stage.py','train.py','generate.py',
                 'electricity_dataset.py','evaluation_v2.py','evaluation.py','validate.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    models,pre,scales=load_forecasters(base,device)
    replays={role:[replay(data,seed,role,models,pre,scales,out,device) for seed in ROLES[role]]
             for role in ['development','calibration']}
    fit=np.concatenate([r['x'] for r in replays['development']]);fit_ok=np.concatenate([r['eligible'] for r in replays['development']])
    val=np.concatenate([r['x'] for r in replays['calibration']]);val_ok=np.concatenate([r['eligible'] for r in replays['calibration']])
    selected={};thresholds={};candidates=[];selection=[];training_labels=[]
    for target in LABELS:
        fy=np.concatenate([r['labels'][target] for r in replays['development']]);vy=np.concatenate([r['labels'][target] for r in replays['calibration']])
        use=fit_ok&np.isfinite(fy);best=(-1,-np.inf);chosen=None
        for r in replays['development']:
            training_labels.extend(dict(seed=r['seed'],target=target,end_hour=int(h),label=int(y))
                for h,y,ok in zip(r['ends'],r['labels'][target],r['eligible']) if ok and np.isfinite(y))
        for spec in CANDIDATES:
            model=classifier(spec,fit[use],fy[use]);s=scores(model,val)
            threshold=precision_threshold(vy,s,val_ok)
            m=confusion(vy,s,threshold,val_ok)
            qualified=np.isfinite(threshold) and m['recall_counting_abstentions_as_misses']>=.30
            candidates.append(dict(target=target,candidate=spec['name'],threshold=threshold,qualified=int(qualified),**m))
            print(f"{target} {spec['name']}: precision={m['precision']} recall={m['recall']} qualified={qualified}",flush=True)
            key=(m['TP'],-m['FP'])
            if qualified and key>best:best=key;chosen=(model,threshold,spec['name'])
        if chosen is None:
            g.write_csv(out/'candidate_metrics.csv',candidates)
            raise RuntimeError(f'No meaningful calibration operating point for {target}; test remains unscored')
        selected[target],thresholds[target],name=chosen
        joblib.dump(dict(classifier=selected[target],threshold=thresholds[target],feature_names=FEATURES),out/(target+'_detector.joblib'),compress=3)
        selection.append(dict(target=target,candidate=name,threshold=thresholds[target],calibration_precision_floor=.92,
            minimum_alerts=20,minimum_recall=.30,fit_positive_intervals=int(np.sum(fy[use]==1)),fit_negative_intervals=int(np.sum(fy[use]==0))))
    g.write_csv(out/'candidate_metrics.csv',candidates);g.write_csv(out/'selection.csv',selection);(out/'selection.csv').chmod(0o444)
    g.write_csv(out/'detector_training_labels.csv',training_labels)
    print('Models and thresholds frozen; test is unscored.' if validation_only else 'Models and thresholds frozen; starting test.',flush=True)
    if not validation_only:replays['test']=[replay(data,seed,'test',models,pre,scales,out,device) for seed in ROLES['test']]
    results=[];decisions=[];audits=[];episode_rows=[]
    old_models={t:joblib.load(base/(t+'_detector.joblib')) for t in LABELS}
    old_thresholds={r['target']:float(r['threshold']) for r in read(base/'thresholds.csv') if r['system']=='learned_detector'}
    for role in ['calibration']+([] if validation_only else ['test']):
        for target in LABELS:
            for system in ['precision_detector','v5_frozen_detector']:
                pooled_labels=[];pooled_scores=[];pooled_ok=[]
                threshold=thresholds[target] if system=='precision_detector' else old_thresholds[target]
                for r in replays[role]:
                    s=scores(selected[target],r['x']) if system=='precision_detector' else model_scores(old_models[target],r['x'][:,:len(protocol.FEATURES)])
                    y=r['labels'][target];ok=r['eligible'];m=confusion(y,s,threshold,ok)
                    results.append(dict(role=role,seed=r['seed'],target=target,system=system,**m))
                    pooled_labels.extend(y);pooled_scores.extend(s);pooled_ok.extend(ok)
                    decisions.extend(dict(role=role,seed=r['seed'],target=target,system=system,end_hour=int(h),score=float(v),
                        eligible=int(valid),alarm=int(valid and v>threshold),app_label=int(label) if np.isfinite(label) else '')
                        for h,v,valid,label in zip(r['ends'],s,ok,y))
                    name='usage_scenarios' if target=='usage_anomaly' else 'assistance_episodes'
                    episode=read(r['data']/'truth'/(name+'.csv'))
                    es=[dict(id=e.get('scenario_id',e.get('episode_id')),start=int(e['start_slot'])/4,end=int(e['end_slot'])/4,kind=e['kind'])
                        for e in episode if (target!='usage_anomaly' or e['unexpected_usage']=='1')
                        and int(e['start_slot'])/4>=r['start'] and int(e['end_slot'])/4<=r['end']]
                    metric,events=episode_audit(r['ends'],np.where(ok,s,np.nan),threshold,es,r['start'],r['end'])
                    audits.append(dict(role=role,seed=r['seed'],target=target,system=system,**metric))
                    episode_rows.extend(dict(role=role,seed=r['seed'],target=target,system=system,kind=e['kind'],**event) for e,event in zip(es,events))
                results.append(dict(role=role,seed='pooled',target=target,system=system,
                    **confusion(np.array(pooled_labels),np.array(pooled_scores),threshold,np.array(pooled_ok))))
    for name,records in [('confusion_matrices',results),('decisions',decisions),('oracle_episode_metrics',audits),('oracle_episode_results',episode_rows)]:
        g.write_csv(out/(name+'.csv'),records)
    g.write_csv(out/'completed.csv',[dict(test_scored=int(not validation_only),forecaster_fits=0,reused_lstm_models=12,
        detector_candidates=len(CANDIDATES)*2,selected_detectors=2)])
    manifest(out)
    print(f'Completed {out}',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','run'])
    parser.add_argument('--data',type=Path,default=Path('ml/household/precision_data_v6'))
    parser.add_argument('--base',type=Path,default=Path('ml/household/runs/two-stage-v5'))
    parser.add_argument('--out',type=Path,default=Path('ml/household/runs/precision-v6'))
    parser.add_argument('--device',choices=['cpu','mps'],default='cpu')
    parser.add_argument('--validation-only',action='store_true')
    args=parser.parse_args()
    if args.action=='prepare':prepare(args.data)
    else:run(args.data,args.base,args.out,args.device,args.validation_only)
