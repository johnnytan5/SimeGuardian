"""Development-only separability probe; never tune against final replay outcomes."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits
from household.tuned_study import FEATURES
from household.two_stage import review_labels,confusion
from household.recall_study import recall_threshold
from household.precision_study import precision_threshold
from household.evaluation_v2 import fresh_output,manifest,verify
from household import electricity_dataset as electric
import hashlib
import shutil
from household.validate import read
from household import generate as g
ROOT=Path('ml/household/runs/tuned-v8')
SELECT=[FEATURES.index(n) for n in FEATURES if n.startswith(('electricity_','water_','gate_','app_')) or n in ['elder_age_hours','missed_checkins','consecutive_missed_checkins','hours_since_due','hours_since_self_checkin','personal_activity_3h','self_checkin_after_latest_due','checkin_context_available']]
LAGS=[1,3,6,12,24]
def temporal(x):
 parts=[x]
 for lag in LAGS:
  known=np.arange(len(x))>=lag;v=np.zeros((len(x),len(SELECT)));v[lag:]=x[:-lag,SELECT]
  parts.extend([v,known[:,None]])
 return np.column_stack(parts)
def identical_sleep_and_emergency(out):
 seed=20261050;states,visitor=electric.routines(seed);arrivals,_=electric.delivery(seed)
 a,b=300*96,300*96+24
 benign=states.copy();benign[0,a:b]='asleep'
 emergency=benign.copy();emergency[0,a:b]='unable'
 normal=g.observe(benign,visitor,arrivals,seed);concern=g.observe(emergency,visitor,arrivals,seed)
 ep=electric.physical_use(benign,visitor,[],seed)[0];eq=electric.physical_use(emergency,visitor,[],seed)[0]
 np.testing.assert_array_equal(ep,eq)
 np.testing.assert_array_equal(normal['values']['water'],concern['values']['water'])
 assert normal['events']==concern['events']
 # There are no scheduled check-ins in this midnight-to-06:00 window.
 assert not any(0<=h<6 for h in [9,14,20])
 normal['values']['electricity']=ep;concern['values']['electricity']=eq
 for data in [normal,concern]:g.index_events(data)
 rows=[]
 for case,data in [('ordinary_sleep',normal),('needs_assistance',concern)]:
  for hour in range(a//4-336,b//4):
   row=g.hour_row(data,hour,(hour+1)*4)
   rows.append(dict(case=case,**row))
 left=[{k:v for k,v in r.items() if k!='case'} for r in rows if r['case']=='ordinary_sleep']
 right=[{k:v for k,v in r.items() if k!='case'} for r in rows if r['case']=='needs_assistance']
 assert left==right
 g.write_csv(out/'counterexample/input_snapshots.csv',rows)
 g.write_csv(out/'counterexample/truth.csv',[dict(case=c,start_hour=a//4,end_hour=b//4,needs_assistance=y,label_basis='controlled latent-state intervention; not model input or a training example') for c,y in [('ordinary_sleep',0),('needs_assistance',1)]])
 g.write_csv(out/'counterexample/equality.csv',[dict(check=k,identical=1) for k in ['electricity including14day history','water including14day history','all gate and ordinary app events with arrival and attribution','source availability','calendar','no scheduled checkin inside case']])
 print('PASS: opposite underlying states have identical available four-source inputs',flush=True)

def run(out):
 verify(ROOT)
 roles={'development':[],'calibration':[]}
 for p in read(ROOT/'plan.csv'):
  if p['role'] not in roles:continue
  rr=read(ROOT/'replays'/p['seed']/'features.csv');x=np.array([[float(r[n]) for n in FEATURES] for r in rr]);ends=np.array([int(r['end_hour']) for r in rr]);eligible=np.array([r['eligible']=='1' for r in rr]);y=review_labels(read(Path(p['path'])/'app_reviews.csv'),ends,'emergency',8760 if p['role']=='development' else 8832)
  roles[p['role']].append((x,temporal(x),y,eligible))
 fx,ft,fy,fe=[np.concatenate([v[i] for v in roles['development']]) for i in range(4)];vx,vt,vy,ve=[np.concatenate([v[i] for v in roles['calibration']]) for i in range(4)];use=np.isfinite(fy)&fe
 fresh_output(out,ROOT);rows=[]
 g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in dict(prior=str(ROOT),prior_manifest_sha256=hashlib.sha256((ROOT/'manifest.csv').read_bytes()).hexdigest(),test_scored=0,selection='exploratory eight classifier comparisons; no promotion',lags=LAGS,seed=44).items()])
 for name,features_x,features_v in [('current',fx,vx),('temporal',ft,vt)]:
  for leaves in [7,15]:
   for balance in [None,'balanced']:
    m=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=leaves,min_samples_leaf=15,l2_regularization=10.,class_weight=balance,early_stopping=False,random_state=44)
    with threadpool_limits(limits=4):m.fit(features_x[use],fy[use]);s=m.predict_proba(features_v)[:,1]
    reviewed=np.arange(7011,8761)%3==0
    take=np.tile(reviewed,3)
    t,_=recall_threshold(vy[take],s[take],ve[take]);metric=confusion(vy[take],s[take],t,ve[take])
    precision_t=precision_threshold(vy[take],s[take],ve[take],precision=.85,min_alerts=20)
    high_precision=confusion(vy[take],s[take],precision_t,ve[take])
    rows.append(dict(features=name,leaves=leaves,balance=str(balance),threshold=t,recall_at_precision85=high_precision['recall_counting_abstentions_as_misses'],**metric));print(rows[-1],flush=True)
  g.write_csv(out/'validation.csv',rows)
 identical_sleep_and_emergency(out)
 shutil.copy(__file__,out/'source.py')
 manifest(out)


if __name__=='__main__':
 run(Path(sys.argv[1]) if len(sys.argv)>1 else Path('ml/household/runs/separability-v10'))
