"""Recompute raw aggregates, temporal eligibility and saved two-stage results."""
import sys,math,argparse
from pathlib import Path
from collections import defaultdict
import numpy as np
import joblib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from household import generate as g
from household.validate import read
from household.evaluation_v2 import verify
from household.train import hour_number
from household.multisource_dataset import SOURCES,WEIGHTS,source_value
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--data',type=Path,default=Path('ml/household/multisource_data_v5'))
parser.add_argument('--run',type=Path,default=Path('ml/household/runs/two-stage-v5'))
args=parser.parse_args();D,R=args.data,args.run
checks=[]
def check(name,ok,n=''):
 assert ok,name
 checks.append(dict(check=name,passed=1,rows=n))
for root in [D,R,Path('ml/household/data'),Path('ml/household/data_v2'),Path('ml/household/electricity_data_v3'),Path('ml/household/multisource_data_v4'),Path('ml/household/runs/two-stage-v4')]:verify(root)
check('new and earlier dataset/run hashes unchanged',True,7)
raw=read(D/'observations_15min.csv');targets=read(D/'targets_hourly.csv');hours=read(D/'hourly.csv')
events=defaultdict(list)
for e in read(D/'events.csv'):
 assert e['event_type'] not in ['family_review','feedback']
 events[int(hour_number(e['event_time']))].append(e)
for h in range(8760):
 quarter=raw[h*4:h*4+4]
 for s in SOURCES:
  feeds=[s,'elder_app'] if s=='app' else [s]
  arrivals=[hour_number(r[f+'_received_at']) for f in feeds for r in quarter]
  valid=all(math.isfinite(a) for a in arrivals)
  if s in ['electricity','water']:
   key=s+('_kwh' if s=='electricity' else '_litres')
   valid=valid and all(r[key]!='' for r in quarter)
   total=sum(float(r[key]) for r in quarter) if valid else math.nan
  else:
   total=sum(e['source']==s and e['meaningful']=='1' and e['attribution']=='verified' for e in events[h])
  assert (targets[h][s]!='')==valid
  if valid:
   assert abs(float(targets[h][s])-total)<3e-6,(h,s,targets[h][s],total)
   assert hour_number(targets[h][s+'_available_at'])==max(arrivals)
  v=source_value(hours[h],s)
  if v!='':assert valid and max(arrivals)<=h+1 and abs(float(v)-total)<3e-6
check('all four source targets independently match raw readings/events/arrivals',True,35040)
reviews=read(D/'app_reviews.csv');by_end={int(r['end_hour_exclusive']):r for r in reviews}
by_hour={h:r for r in reviews for h in range(int(r['start_hour']),int(r['end_hour_exclusive']))}
for r in read(R/'forecast_training_targets.csv'):
 h=int(r['hour']);a,b=(336,2880) if r['role']=='fit' else (2880,3600)
 assert a<=h<b
 label=by_hour[h]
 assert label['usage_anomaly_label']==label['emergency_label']=='0'
 assert all(hour_number(label[t+'_available_at'])<=b for t in ['usage_anomaly','emergency'])
 assert hour_number(targets[h][r['source']+'_available_at'])<=b
for s in SOURCES:
 pre=joblib.load(R/'forecasters'/s/'preprocessing.joblib')
 assert pre['feature_names']==[s,'source_availability'] and len(pre['median'])==2 and pre['history_hours']==336
check('each LSTM has only its own source/availability; timely confirmed-normal fit targets',True,12)
for r in read(R/'detector_training_labels.csv'):
 h=int(r['end_hour']);assert 3600<h<=5256
 review=by_end[h];assert review[r['target']+'_label']==r['label']
 assert hour_number(review[r['target']+'_available_at'])<=5256
check('detector supervision starts after forecaster fitting and early stopping',True,len(read(R/'detector_training_labels.csv')))
forecasts=read(R/'forecasts.csv');pred=defaultdict(dict)
for r in forecasts:
 key=(r['source'],r['seed']);h=int(r['target_hour'])
 assert h not in pred[key] and hour_number(r['issued_time'])==h
 pred[key][h]=float(r['forecast'])
for s in SOURCES:
 for h,v in pred[(s,'ensemble')].items():assert abs(v-sum(pred[(s,str(seed))][h] for seed in [11,22,33])/3)<1e-10
check('all three seeds retained and averaged; no best-test-seed selection',True,len(forecasts))
for m in read(R/'forecast_metrics.csv'):
 a,b=(5256,7008) if m['partition']=='validation' else (7008,8760)
 errors=[pred[(m['source'],m['seed'])][h]-float(targets[h][m['source']]) for h in range(a,b) if targets[h][m['source']]!='']
 assert abs(sum(abs(e) for e in errors)/len(errors)-float(m['mae']))<1e-10
 assert abs(math.sqrt(sum(e*e for e in errors)/len(errors))-float(m['rmse']))<1e-10
check('per-source, per-seed and baseline forecast metrics independently recomputed',True,len(read(R/'forecast_metrics.csv')))
threshold={(r['target'],r['system']):float(r['threshold']) for r in read(R/'thresholds.csv')}
features={(r['partition'],int(r['end_hour'])):r for r in read(R/'detector_features.csv')}
models={t:joblib.load(R/(t+'_detector.joblib')) for t in ['usage_anomaly','emergency']}
ablations={t:joblib.load(R/(t+'_without_checkin.joblib')) for t in models if (R/(t+'_without_checkin.joblib')).exists()}
decisions=read(R/'decisions.csv');groups=defaultdict(list)
for r in decisions:
 key=(r['partition'],r['target'],r['system']);groups[key].append(r)
 h=int(r['end_hour']);assert hour_number(r['decision_time'])==h+.5
 f=features[(r['partition'],h)];ok=r['eligible']=='1';assert int(f['eligible'])==ok
 if r['system']!='weighted_baseline':
  m=models[r['target']] if r['system']=='learned_detector' else ablations[r['target']]
  clf=m['classifier']
  if 'columns' in m:
   from threadpoolctl import threadpool_limits
   x=np.array([[float(f[k]) for k in m['feature_names']]])
   with threadpool_limits(limits=4):expected=clf.predict_proba(x[:,m['columns']])[0,1]
  else:
   z=sum(float(f[k])*float(c) for k,c in zip(m['feature_names'],clf.coef_[0]))+float(clf.intercept_[0])
   expected=1/(1+math.exp(-z))
  assert abs(expected-float(r['score']))<1e-12
 elif ok:assert abs(float(r['score'])-float(f['weighted_error']))<1e-12
 assert int(r['alarm'])==(ok and r['score']!='' and float(r['score'])>threshold[(r['target'],r['system'])])
 review=by_end.get(h);cut=7008 if r['partition']=='validation' else 8832
 expected=review[r['target']+'_label'] if review and hour_number(review[r['target']+'_available_at'])<=cut else ''
 assert r['app_label']==expected
for m in read(R/'confusion_matrices.csv'):
 selected=groups[(m['partition'],m['target'],m['system'])];counts=dict(TP=0,FP=0,TN=0,FN=0)
 unknown=abstained=0
 for r in selected:
  if r['app_label']=='':unknown+=1;continue
  if r['eligible']=='0':abstained+=1;continue
  key=('T' if r['app_label']==r['alarm'] else 'F')+('P' if r['alarm']=='1' else 'N')
  counts[key]+=1
 assert all(int(m[k])==v for k,v in counts.items())
 assert int(m['unlabelled_intervals'])==unknown and int(m['abstained_labelled_intervals'])==abstained
check('saved model scores reproduced; decisions and TP/FP/TN/FN independently recomputed',True,len(decisions))
weights={r['source']:float(r['expected_weight']) for r in read(R/'expected_weights.csv')}
scales={r['source']:float(r['residual_scale']) for r in read(R/'expected_weights.csv')}
for (part,h),f in features.items():
 total=available=0.
 for s in SOURCES:
  tt=targets[h-3:h]
  valid=all(t[s]!='' and hour_number(t[s+'_available_at'])<=h+.5 for t in tt)
  assert float(f[s+'_available'])==valid
  if valid:
   residual=sum(pred[(s,'ensemble')][j]-float(targets[j][s]) for j in range(h-3,h))/3/scales[s]
   short=min(8.,max(0.,residual));excess=min(8.,max(0.,-residual))
   assert abs(float(f[s+'_shortfall'])-weights[s]*short)<1e-10
   assert abs(float(f[s+'_excess'])-weights[s]*excess)<1e-10
   total+=weights[s]*(short+excess);available+=weights[s]
  else:assert float(f[s+'_shortfall'])==float(f[s+'_excess'])==0
 assert int(f['eligible'])==(available>=.7-1e-12)
 assert abs(float(f['weighted_error'])-(total/available if available else 0))<1e-10
check('all residual features, priors and abstentions match decision-time observations',True,len(features))

# Independently rebuild expected-response windows from raw event records.
if ablations:
 for (part,h),f in features.items():
  due=[d*24+hour for d in range(max(0,(h-24)//24),h//24+1) for hour in [9,14,20] if h-24<=d*24+hour and d*24+hour+1<=h]
  missed=[]
  for t in due:
   known=targets[t]['app']!='' and hour_number(targets[t]['app_available_at'])<=h+.5
   responses=[e for e in events[t] if e['source']=='app' and e['event_type']=='agreed_self_checkin'
       and e['claimed_resident_id']=='E1' and e['attribution']=='verified' and e['meaningful']=='1'
       and hour_number(e['received_at'])<=h+.5]
   missed.append(None if not known else not bool(responses))
  consecutive=0
  for v in missed[::-1]:
   if v is not True:break
   consecutive+=1
  recent=[e for j in range(due[-1] if due else h,h) for e in events[j]
      if e['source'] in ['app','gate'] and e['claimed_resident_id']=='E1' and e['attribution']=='verified'
      and e['meaningful']=='1' and hour_number(e['received_at'])<=h+.5]
  assert float(f['missed_checkins'])==sum(v is True for v in missed)
  assert float(f['consecutive_missed_checkins'])==consecutive
  assert float(f['checkin_context_available'])==(bool(missed) and all(v is not None for v in missed))
  assert float(f['elder_activity_since_due'])==bool(recent)
 check('check-in deadlines independently rebuilt without truth or feedback',True,len(features))

# Re-select each threshold using only validation decisions; compare the frozen value.
for (target,system),chosen in threshold.items():
 rows=[r for r in groups[('validation',target,system)] if r['eligible']=='1' and r['app_label']!='' and r['score']!='']
 values=sorted(set(float(r['score']) for r in rows));best=(-1,-math.inf,-math.inf);pick=math.inf
 for t in [math.inf,np.nextafter(values[0],-math.inf)]+values:
  tp=sum(r['app_label']=='1' and float(r['score'])>t for r in rows)
  fp=sum(r['app_label']=='0' and float(r['score'])>t for r in rows)
  fn=sum(r['app_label']=='1' and float(r['score'])<=t for r in rows)
  key=(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,-fp,t)
  if key>best:best,pick=key,t
 assert chosen==pick
check('frozen thresholds independently reproduced from validation only',True,len(threshold))

check('no JSON or NPZ datasets introduced',not any(p.suffix in ['.json','.jsonl','.npz'] for root in [D,R] for p in root.rglob('*')))
g.write_csv(R.with_name(R.name+'-verification.csv'),checks)
print('\n'.join(r['check']+': PASS' for r in checks))
