"""Plot measured versus saved forecast values for one fixed held-out time window."""
import argparse
import shutil
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

if __package__:
    from . import generate as g
    from .validate import read
    from .evaluation_v2 import fresh_output, manifest, verify
else:
    import generate as g
    from validate import read
    from evaluation_v2 import fresh_output, manifest, verify

SOURCES = dict(electricity=('Electricity','kWh per hour'),water=('Water','litres per hour'),
               gate=('Gate activity','verified events per hour'),app=('App activity','verified actions per hour'))


def plot(data,run,out,seed=20261035,first=7008,hours=168):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.dates as mdates
    from matplotlib.ticker import MaxNLocator

    verify(data);verify(run)
    targets=read(data/'targets_hourly.csv')
    if hours<1 or first<7008 or first+hours>8760:raise ValueError('Choose a nonempty window inside the final test period')
    predictions=defaultdict(dict)
    for r in read(run/'replays'/str(seed)/'forecasts.csv'):
        h=int(r['hour'])
        if not first<=h<first+hours:continue
        if int(r['seed'])!=seed or r['role']!='test':raise ValueError('Forecast replay identity differs from selected test')
        key=(r['source'],h);training_seed=int(r['training_seed'])
        if training_seed in predictions[key]:raise ValueError('Duplicate forecast')
        predictions[key][training_seed]=float(r['prediction'])
    own=targets[first:first+hours]
    if [int(r['hour']) for r in own]!=list(range(first,first+hours)):raise ValueError('Target timestamps are not contiguous')
    dates=[datetime.fromisoformat(r['start_time']) for r in own]
    end=dates[-1]+timedelta(hours=1);tz=dates[0].tzinfo
    series={};export=[];metrics=[]
    for source,(_,unit) in SOURCES.items():
        measured=np.array([float(r[source]) if r[source]!='' else np.nan for r in own]);predicted=[]
        for h,r in zip(range(first,first+hours),own):
            members=predictions[(source,h)]
            if set(members)!={11,22,33}:raise ValueError('Every target requires all three training seeds')
            value=float(np.mean([members[s] for s in [11,22,33]]));predicted.append(value)
            export.append(dict(replay_seed=seed,source=source,hour=h,start_time=r['start_time'],
                measured=r[source],prediction=value,prediction_seed11=members[11],prediction_seed22=members[22],
                prediction_seed33=members[33],observed=int(r[source]!=''),measured_available_at=r[source+'_available_at']))
        predicted=np.array(predicted);known=np.isfinite(measured)
        if not np.isfinite(predicted).all():raise ValueError('Non-finite forecast')
        error=predicted[known]-measured[known]
        metrics.append(dict(source=source,start_time=dates[0].isoformat(),end_time_exclusive=end.isoformat(),
            total_hours=hours,observed_hours=int(known.sum()),missing_hours=int((~known).sum()),
            mae=float(np.abs(error).mean()) if len(error) else '',rmse=float(np.sqrt(np.mean(error**2))) if len(error) else '',unit=unit))
        series[source]=(measured,predicted)
    fresh_output(out,data,run)
    g.write_csv(out/'measured_and_predicted.csv',export);g.write_csv(out/'window_metrics.csv',metrics)
    g.write_csv(out/'selection.csv',[dict(replay_seed=seed,first_hour=first,hours=hours,
        start_time=dates[0].isoformat(),end_time_exclusive=end.isoformat(),
        selection='first seven test days by default; no selection by forecast error',
        prediction='mean of saved LSTM seeds11/22/33; no smoothing or refitting',
        measurement='synthetic eventual hourly total; blanks remain missing',timezone='UTC+08:00')])
    shutil.copy(Path(__file__),out/'plot_forecasts.py')
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':13,'axes.labelsize':11,
                         'axes.edgecolor':'#cbd5e1','text.color':'#172033','axes.labelcolor':'#334155',
                         'xtick.color':'#475569','ytick.color':'#475569','savefig.facecolor':'white'})
    subtitle=f"{dates[0]:%d %b} – {(end-timedelta(hours=1)):%d %b %Y} · UTC+08:00 · hourly · test replay {seed}"

    def draw(ax,source):
        measured,predicted=series[source];name,unit=SOURCES[source]
        counts=source in ['gate','app']
        method=ax.step if counts else ax.plot
        kwargs={'where':'post'} if counts else {}
        x=dates+[end] if counts else dates
        observed=np.r_[measured,measured[-1]] if counts else measured
        estimate=np.r_[predicted,predicted[-1]] if counts else predicted
        method(x,observed,color='#2563eb',lw=1.5,label='Measured (synthetic)',**kwargs)
        method(x,estimate,color='#d97706',lw=1.7,ls='--',label='LSTM prediction (3-seed mean)',**kwargs)
        missing=np.flatnonzero(~np.isfinite(measured))
        for j,index in enumerate(missing):
            ax.axvspan(dates[index],dates[index]+timedelta(hours=1),color='#64748b',alpha=.16,
                       lw=0,label='Missing measured reading' if j==0 else None)
        m=next(r for r in metrics if r['source']==source)
        ax.set_title(f"{name} | measured {m['observed_hours']}/{hours} hours",loc='left',fontweight='bold',pad=38)
        ax.set_ylabel(unit);ax.set_xlim(dates[0],end);ax.set_ylim(bottom=0)
        ax.xaxis.set_major_locator(mdates.DayLocator(tz=tz))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%a\n%d %b',tz=tz))
        ax.grid(axis='y',color='#e2e8f0',lw=.7);ax.set_axisbelow(True)
        ax.spines[['top','right']].set_visible(False)
        if source in ['gate','app']:ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,fontsize=9,ncol=3,borderaxespad=0)

    fig,axes=plt.subplots(4,1,figsize=(14,15))
    fig.subplots_adjust(left=.08,right=.96,bottom=.06,top=.88,hspace=.52)
    fig.suptitle('Measured vs next-hour LSTM forecast\n'+subtitle,fontsize=17,fontweight='bold',y=.98)
    for ax,source in zip(axes,SOURCES):draw(ax,source)
    axes[-1].set_xlabel('Target hour — local time')
    fig.savefig(out/'all_sources.png',dpi=170)
    fig.savefig(out/'all_sources.pdf')
    plt.close(fig)
    for source in SOURCES:
        fig,ax=plt.subplots(figsize=(14,5))
        fig.subplots_adjust(left=.08,right=.96,bottom=.20,top=.70)
        draw(ax,source);ax.set_xlabel('Target hour — local time')
        fig.suptitle(subtitle,fontsize=11,color='#475569',y=.97)
        fig.savefig(out/(source+'.png'),dpi=180);plt.close(fig)
    manifest(out)
    print(f'Created four source plots, combined PNG/PDF, and {len(export)} source-hour CSV rows in {out}',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed',type=int,default=20261035)
    parser.add_argument('--data',type=Path)
    parser.add_argument('--run',type=Path,default=Path('ml/household/runs/precision-v6'))
    parser.add_argument('--out',type=Path,default=Path('ml/household/runs/forecast-week-20261035'))
    parser.add_argument('--first-hour',type=int,default=7008)
    parser.add_argument('--hours',type=int,default=168)
    args=parser.parse_args()
    data=args.data or Path('ml/household/precision_data_v6')/str(args.seed)
    plot(data,args.run,args.out,args.seed,args.first_hour,args.hours)
