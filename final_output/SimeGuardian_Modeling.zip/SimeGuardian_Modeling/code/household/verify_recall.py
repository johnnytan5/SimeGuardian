"""Independently check frozen recall calibration, labels, scores and episode counts."""
import hashlib
import csv
from pathlib import Path
import joblib
import numpy as np

if __package__:
    from . import generate as g, precision_study as old
    from .validate import read
    from .evaluation_v2 import verify
    from .train import hour_number
    from .tuned_study import FEATURES, temporal_score
else:
    import generate as g
    import precision_study as old
    from validate import read
    from evaluation_v2 import verify
    from train import hour_number
    from tuned_study import FEATURES, temporal_score


def run():
    out=Path('ml/household/runs/recall-v9');prior=out.with_name('tuned-v8');data=Path('ml/household/recall_data_v9')
    checks=[]
    def passed(name,rows=''):checks.append(dict(check=name,passed=1,rows=rows))
    for path in [out,prior,data]:verify(path)
    cfg={r['parameter']:r['value'] for r in read(out/'config.csv')}
    assert cfg['prior_manifest_sha256']==hashlib.sha256((prior/'manifest.csv').read_bytes()).hexdigest()
    plans=read(out/'plan.csv');seen={p['seed'] for p in read(prior/'plan.csv')}
    assert {int(p['seed']) for p in plans if p['role']=='test'}=={20261044,20261045,20261046}
    for p in plans:
        root=Path(p['path']);verify(root)
        assert p['manifest_sha256']==hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()
        if p['role']=='test':assert p['seed'] not in seen
    for r in read(out/'model_references.csv'):
        root=Path(r['path']);verify(root);assert r['manifest_sha256']==hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()
    passed('immutable unchanged model/data references and disjoint fresh test seeds',len(plans))
    models={t:joblib.load(out/(t+'_detector.joblib')) for t in ['emergency','usage_anomaly']}
    for target,m in models.items():
        previous=joblib.load(prior/(target+'_detector.joblib'))
        assert joblib.hash(m['classifier'])==joblib.hash(previous['classifier']) and m['score_mode']==previous['score_mode'] and m['features']==previous['features']
        if target=='usage_anomaly':assert m['threshold']==previous['threshold']
    assert (out/'forecast_mixing.csv').read_bytes()==(prior/'forecast_mixing.csv').read_bytes()
    passed('threshold-only emergency change; utility classifier/threshold and source models unchanged',2)
    calibration=[r for r in read(prior/'decisions.csv') if r['role']=='calibration' and r['system']=='tuned' and r['target']=='emergency' and r['reviewed_endpoint']=='1']
    positives=sum(r['app_label']=='1' for r in calibration);known=[r for r in calibration if r['app_label']!='' and r['eligible']=='1']
    values=sorted(set(float(r['score']) for r in known));qualified=[]
    for t in [np.nextafter(values[0],-np.inf)]+values:
        tp=sum(r['app_label']=='1' and float(r['score'])>t for r in known)
        fp=sum(r['app_label']=='0' and float(r['score'])>t for r in known)
        if tp/positives>=.90:qualified.append((fp,-t,t))
    assert models['emergency']['threshold']==min(qualified)[2]
    passed('90% recall threshold selected only from calibration, minimum FP, positive abstentions retained',len(calibration))
    decisions=read(out/'decisions.csv')
    for p in plans:
        if p['role']!='test':continue
        seed=p['seed'];features=read(out/'replays'/seed/'features.csv');x=np.array([[float(r[n]) for n in FEATURES] for r in features])
        eligible=np.array([r['eligible']=='1' for r in features]);reviews={r['end_hour_exclusive']:r for r in read(Path(p['path'])/'app_reviews.csv')}
        for target,m in models.items():
            score=temporal_score(old.scores(m['classifier'],x),eligible,m['score_mode'])
            for r in [v for v in decisions if v['seed']==seed and v['target']==target]:
                i=int(r['end_hour'])-7011;assert abs(float(r['score'])-score[i])<1e-12
                assert int(r['eligible'])==eligible[i]
                threshold=m['threshold'] if r['system']!='precision_focused' else float(cfg['emergency_old_threshold'])
                assert int(r['alarm'])==(eligible[i] and score[i]>threshold)
                review=reviews.get(r['end_hour']);label=review[target+'_label'] if review and hour_number(review[target+'_available_at'])<=8832 else ''
                assert r['app_label']==label and int(r['reviewed_endpoint'])==(int(r['end_hour'])%3==0)
    passed('saved model scores reproduce every decision; app labels are timely and unknowns stay unknown',len(decisions))
    mixing={r['source']:float(r['fine_weight']) for r in read(out/'forecast_mixing.csv')}
    sources=['electricity','water','gate','app']
    for plan in [p for p in plans if p['role']=='test']:
        folder=out/'replays'/plan['seed'];targets=read(Path(plan['path'])/'targets_hourly.csv')
        forecasts={}
        with (folder/'forecasts.csv').open() as stream:
            for r in csv.DictReader(stream):forecasts[(r['source'],r['model'],int(r['hour']))]=float(r['prediction'])
        for source in sources:
            for h in range(6984,8760):
                fine=np.mean([forecasts[(source,'tuned_seed'+str(seed),h)] for seed in [11,22,33]])
                expected=mixing[source]*fine+(1-mixing[source])*forecasts[(source,'original',h)]
                assert abs(expected-forecasts[(source,'tuned',h)])<1e-12
        for m in read(folder/'forecast_metrics.csv'):
            if m['model'] not in ['tuned','original']:continue
            hours=[h for h in range(7008,8760) if targets[h][m['source']]!='']
            error=np.array([forecasts[(m['source'],m['model'],h)]-float(targets[h][m['source']]) for h in hours])
            assert len(hours)==int(m['targets'])
            assert abs(np.abs(error).mean()-float(m['mae']))<1e-12
            assert abs(np.sqrt(np.mean(error**2))-float(m['rmse']))<1e-12
    passed('all three forecast seeds retained; frozen blends and matching observed-target errors reproduced',24)
    for m in read(out/'confusion_matrices.csv'):
        rr=[r for r in decisions if r['target']==m['target'] and r['system']==m['system'] and r['reviewed_endpoint']=='1' and (m['seed']=='pooled' or r['seed']==m['seed'])]
        counts=dict(TP=0,FP=0,TN=0,FN=0);unknown=abstained=positive_abstained=0
        for r in rr:
            if r['app_label']=='':unknown+=1;continue
            if r['eligible']=='0':abstained+=1;positive_abstained+=r['app_label']=='1';continue
            counts[('T' if r['app_label']==r['alarm'] else 'F')+('P' if r['alarm']=='1' else 'N')]+=1
        assert all(int(m[k])==v for k,v in counts.items())
        assert int(m['unlabelled_intervals'])==unknown and int(m['abstained_labelled_intervals'])==abstained and int(m['abstained_positive_intervals'])==positive_abstained
        assert abs(float(m['recall_counting_abstentions_as_misses'])-counts['TP']/(counts['TP']+counts['FN']+positive_abstained))<1e-12
    passed('independent TP FP TN FN, unknown labels, abstentions and recall denominator',12)
    events=read(out/'oracle_episode_results.csv')
    for m in read(out/'oracle_episode_metrics.csv'):
        rr=[r for r in decisions if all(r[k]==m[k] for k in ['seed','target','system'])]
        es=[e for e in events if all(e[k]==m[k] for k in ['seed','target','system'])]
        flags=[r['alarm']=='1' for r in rr];groups=[]
        for i,flag in enumerate(flags):
            if flag:
                if i==0 or not flags[i-1]:groups.append([])
                groups[-1].append(i)
        matched=set();detected=duplicates=0;delays=[]
        for e in es:
            a,b=float(e['start_hour']),float(e['end_hour']);during={i for i,r in enumerate(rr) if int(r['end_hour'])>np.floor(a) and a<int(r['end_hour'])+.5<b}
            hits=[j for j,indices in enumerate(groups) if during.intersection(indices)];matched.update(hits);detected+=bool(hits);duplicates+=max(0,len(hits)-1)
            assert int(e['detected'])==bool(hits) and int(e['observable'])==any(rr[i]['eligible']=='1' for i in during)
            if hits:
                delay=min(int(rr[i]['end_hour'])+.5-a for i in during if flags[i]);delays.append(delay);assert delay==float(e['delay_hours'])
        assert int(m['detected_episodes'])==detected and int(m['alert_episodes'])==len(groups)
        assert int(m['false_alerts'])==len(groups)-len(matched) and int(m['duplicate_alerts'])==duplicates
        assert abs(float(m['false_alerts_per_30_days'])-(len(groups)-len(matched))*30/73)<1e-10
        if delays:assert float(m['median_delay_hours'])==np.median(delays) and float(m['p90_delay_hours'])==np.percentile(delays,90)
    passed('independent episode matches, missed episodes, delays, repeated and false alert groups',len(events))
    assert not any(p.suffix in ['.json','.jsonl','.npz'] for root in [data,out] for p in root.rglob('*'))
    passed('data and results remain CSV, no JSON or NPZ')
    g.write_csv(out.with_name(out.name+'-verification.csv'),checks)
    print('\n'.join(r['check']+': PASS' for r in checks))


if __name__=='__main__':run()
