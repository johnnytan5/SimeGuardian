"""Audit the deliberately easier benchmark without changing its frozen results."""
import hashlib
from collections import defaultdict
from pathlib import Path
import joblib
import numpy as np

if __package__:
    from . import generate as g, precision_study as old
    from .illustrative_study import CONTEXT, ROLES
    from .tuned_study import FEATURES
    from .validate import read
    from .train import hour_number
    from .evaluation_v2 import verify
else:
    import generate as g
    import precision_study as old
    from illustrative_study import CONTEXT, ROLES
    from tuned_study import FEATURES
    from validate import read
    from train import hour_number
    from evaluation_v2 import verify


def run():
    data=Path('ml/household/illustrative_data_v11');out=Path('ml/household/runs/illustrative-v11');checks=[]
    def passed(name,rows=''):checks.append(dict(check=name,passed=1,rows=rows))
    for root in [data,out,Path('ml/household/runs/recall-v9'),Path('ml/household/runs/tuned-v8')]:verify(root)
    plan=read(out/'plan.csv');assert len(plan)==9
    for role,seeds in ROLES.items():assert {int(p['seed']) for p in plan if p['role']==role}==set(seeds)
    for r in read(out/'model_references.csv'):
        root=Path(r['path']);verify(root);assert r['manifest_sha256']==hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()
    passed('all previous model/results manifests unchanged; three disjoint fixed seed groups',9)
    models=joblib.load(out/'emergency_detector.joblib');assert models['features']==FEATURES+CONTEXT
    all_labels={};all_scores={};all_eligible={};all_ends={};all_roles={}
    for p in plan:
        seed=p['seed'];root=Path(p['path']);verify(root)
        assert p['manifest_sha256']==hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()
        cfg={r['parameter']:r['value'] for r in read(root/'config.csv')}
        assert cfg['version']=='illustrative-daytime-v11' and 'ARTIFICIALLY EASIER' in cfg['benchmark']
        for e in read(root/'truth/assistance_episodes.csv'):
            a,b=int(e['start_slot'])/4,int(e['end_slot'])/4
            assert a%24 in [8,11,14] and 6<=b-a<=9 and a//24==b//24 and b%24<=21
        targets=read(root/'targets_hourly.csv');events=defaultdict(list)
        for e in read(root/'events.csv'):events[int(hour_number(e['event_time']))].append(e)
        rows=read(out/'replays'/seed/'features.csv');ctx=read(out/'replays'/seed/'checkin_context.csv');assert len(rows)==len(ctx)
        x=[]
        for row,c in zip(rows,ctx):
            end=int(row['end_hour']);assert end==int(c['end_hour']);scheduled=known=responses=0
            for h in range(end-3,end):
                if not 8<=h%24<22:continue
                scheduled+=1
                if not targets[h]['app'] or hour_number(targets[h]['app_available_at'])>end+.5:continue
                known+=1
                responses+=any(e['event_type']=='agreed_self_checkin' and e['source']=='app' and e['attribution']=='verified'
                    and e['claimed_resident_id']=='E1' and e['meaningful']=='1' and hour_number(e['received_at'])<=end+.5
                    and h<=hour_number(e['event_time'])<h+1 for e in events[h])
            v=[scheduled,known,responses,known-responses,scheduled-known,known/scheduled if scheduled else 0.]
            np.testing.assert_allclose([float(c[n]) for n in CONTEXT],v,rtol=0,atol=1e-12)
            x.append([float(row[n]) for n in FEATURES]+v)
        all_scores[seed]=old.scores(models['classifier'],np.array(x));all_ends[seed]=[int(r['end_hour']) for r in rows]
        all_eligible[seed]=[r['eligible']=='1' for r in rows];all_roles[seed]=p['role']
        cutoff=int(p['end_hour']) if p['role']=='development' else 8832
        reviews={r['end_hour_exclusive']:r for r in read(root/'app_reviews.csv')}
        all_labels[seed]=[reviews[str(h)]['emergency_label'] if str(h) in reviews and hour_number(reviews[str(h)]['emergency_available_at'])<=cutoff else '' for h in all_ends[seed]]
    passed('profile assumptions explicit; daytime case scope verified; all new context rebuilt from timely verified self-actions',9)
    training={(r['seed'],int(r['end_hour']),r['label']) for r in read(out/'training_labels.csv')}
    expected={(s,h,y) for s in all_roles if all_roles[s]=='development' for h,y,ok in zip(all_ends[s],all_labels[s],all_eligible[s]) if ok and y!=''}
    assert training==expected
    passed('all and only eligible development family labels available by cutoff train the classifier',len(training))
    decisions=read(out/'decisions.csv');groups=defaultdict(list)
    for r in decisions:
        seed=r['seed'];a=7011;i=int(r['end_hour'])-a;assert all_roles[seed]==r['role']
        assert abs(float(r['score'])-all_scores[seed][i])<1e-12
        assert (r['eligible']=='1')==all_eligible[seed][i] and r['app_label']==all_labels[seed][i]
        assert int(r['alarm'])==(all_eligible[seed][i] and all_scores[seed][i]>models['threshold'])
        groups[(r['role'],seed)].append(r)
    passed('saved classifier reproduces every calibration/test score, alarm and independent delayed label',len(decisions))
    for m in read(out/'confusion_matrices.csv'):
        rr=[r for r in decisions if r['role']==m['role'] and (m['seed']=='pooled' or r['seed']==m['seed']) and r['reviewed_endpoint']=='1']
        counts=dict(TP=0,FP=0,TN=0,FN=0);unknown=abstained=positive_abstained=0
        for r in rr:
            if r['app_label']=='':unknown+=1;continue
            if r['eligible']=='0':abstained+=1;positive_abstained+=r['app_label']=='1';continue
            counts[('T' if r['app_label']==r['alarm'] else 'F')+('P' if r['alarm']=='1' else 'N')]+=1
        assert all(int(m[k])==v for k,v in counts.items())
        assert int(m['unlabelled_intervals'])==unknown and int(m['abstained_labelled_intervals'])==abstained and int(m['abstained_positive_intervals'])==positive_abstained
    passed('independently recomputed TP FP TN FN, unknown labels and positive abstentions',8)
    rr=[r for r in decisions if r['role']=='calibration' and r['reviewed_endpoint']=='1'];positive=sum(r['app_label']=='1' for r in rr)
    known=[r for r in rr if r['app_label']!='' and r['eligible']=='1'];values=sorted(set(float(r['score']) for r in known));qualified=[]
    for t in [np.nextafter(values[0],-np.inf)]+values:
        tp=sum(r['app_label']=='1' and float(r['score'])>t for r in known);fp=sum(r['app_label']=='0' and float(r['score'])>t for r in known)
        if tp/positive>=.90:qualified.append((fp,-t,t))
    assert models['threshold']==min(qualified)[2]
    passed('recall-first threshold independently reproduces using calibration only; positive abstentions count as misses',len(rr))
    episodes=read(out/'oracle_episode_results.csv')
    for m in read(out/'oracle_episode_metrics.csv'):
        rr=groups[(m['role'],m['seed'])];es=[e for e in episodes if e['role']==m['role'] and e['seed']==m['seed']]
        flags=[r['alarm']=='1' for r in rr];alerts=[]
        for i,flag in enumerate(flags):
            if flag:
                if i==0 or not flags[i-1]:alerts.append([])
                alerts[-1].append(i)
        matched=set();detected=duplicates=0;delays=[]
        for e in es:
            a,b=float(e['start_hour']),float(e['end_hour']);during={i for i,r in enumerate(rr) if int(r['end_hour'])>np.floor(a) and a<int(r['end_hour'])+.5<b}
            hits=[j for j,indices in enumerate(alerts) if during.intersection(indices)];matched.update(hits);detected+=bool(hits);duplicates+=max(0,len(hits)-1)
            assert int(e['detected'])==bool(hits) and int(e['observable'])==any(rr[i]['eligible']=='1' for i in during)
            if hits:
                d=min(int(rr[i]['end_hour'])+.5-a for i in during if flags[i]);delays.append(d);assert d==float(e['delay_hours'])
        assert int(m['detected_episodes'])==detected and int(m['alert_episodes'])==len(alerts)
        assert int(m['false_alerts'])==len(alerts)-len(matched) and int(m['duplicate_alerts'])==duplicates
        assert abs(float(m['false_alerts_per_30_days'])-(len(alerts)-len(matched))*30/73)<1e-10
        if delays:assert float(m['median_delay_hours'])==np.median(delays) and float(m['p90_delay_hours'])==np.percentile(delays,90)
    passed('independent onset/end matching, missed episodes, delays, duplicate groups and false-alert rates',len(episodes))
    assert not any(p.suffix in ['.json','.jsonl','.npz'] for root in [data,out] for p in root.rglob('*'))
    passed('reviewable CSV datasets/results, with no JSON or NPZ')
    g.write_csv(out.with_name(out.name+'-verification.csv'),checks);print('\n'.join(r['check']+': PASS' for r in checks))


if __name__=='__main__':run()
