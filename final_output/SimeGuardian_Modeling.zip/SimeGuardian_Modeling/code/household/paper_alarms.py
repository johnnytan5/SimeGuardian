"""Replay Section 4 of Hernández et al. (2024) on frozen household forecasts."""
import argparse
import hashlib
import platform
import shutil
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path

import numpy as np

if __package__:
    from .generate import ORIGIN, write_csv
    from .validate import read, validate_dataset
    from .evaluation import detection
else:
    from generate import ORIGIN, write_csv
    from validate import read, validate_dataset
    from evaluation import detection

PAPER = 'https://doi.org/10.3390/s24020515'
WINDOWS = [('sleep', 0, 6, -1, 1.), ('breakfast', 8, 11, 1, 3.), ('lunch', 13, 16, 1, 3.)]


def stamp(hour):
    return (ORIGIN + timedelta(hours=float(hour))).isoformat()


def schedule(start, end):
    for day in range(start//24, (end+23)//24):
        for activity, a, b, direction, multiplier in WINDOWS:
            a, b = day*24+a, day*24+b
            if a >= start and b <= end:
                yield dict(activity=activity, start_hour=a, end_hour_exclusive=b,
                           direction=direction, multiplier=multiplier)


def window_alarm(predicted, observed, direction, multiplier):
    predicted, observed = np.asarray(predicted, dtype=float), np.asarray(observed, dtype=float)
    if predicted.shape != observed.shape or predicted.ndim != 1 or len(predicted) < 2:
        raise ValueError('An activity window needs matching hourly vectors of length >= 2')
    if not np.isfinite(predicted).all() or direction not in (-1, 1) or multiplier <= 0:
        raise ValueError('Invalid forecast or alarm rule')
    valid = np.isfinite(observed)
    row = dict(expected_hours=len(predicted), observed_hours=int(valid.sum()), eligible=int(valid.all()),
        abstain_reason='' if valid.all() else 'incomplete timely electricity observations',
        mean_predicted_kwh=float(predicted.mean()), mean_observed_kwh='', mean_signed_error_kwh='',
        sigma_error_kwh='', threshold_kwh='', margin_kwh='', alarm='')
    if valid.all():
        error = predicted-observed
        sigma = float(np.std(error, ddof=0))
        margin = float(direction*error.mean()-multiplier*sigma)
        row.update(mean_observed_kwh=float(observed.mean()), mean_signed_error_kwh=float(error.mean()),
                   sigma_error_kwh=sigma, threshold_kwh=multiplier*sigma, margin_kwh=margin,
                   alarm=int(margin > 0))
    return row


def verify_run(root, data):
    listed = read(root/'manifest.csv')
    files = {str(p.relative_to(root)) for p in root.rglob('*')
             if p.is_file() and p.name != 'manifest.csv' and '__pycache__' not in p.parts}
    if files != {r['file'] for r in listed} or len(files) != len(listed):
        raise ValueError('Forecast run file inventory differs from its manifest')
    for row in listed:
        path = (root/row['file']).resolve()
        if root.resolve() not in path.parents or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError(f'Forecast run hash mismatch: {row["file"]}')
    if (root/'dataset_manifest.csv').read_bytes() != (data/'manifest.csv').read_bytes():
        raise ValueError('Forecasts were produced from a different dataset')
    if read(root/'completed.csv')[0]['smoke'] != 'False':
        raise ValueError('Use a completed full forecasting run, not a smoke run')


def context(rows):
    states = np.array([[r[name+'_state'] for name in ['E1', 'A1', 'A2', 'C1', 'C2']] for r in rows])
    active = ~np.isin(states, ['away', 'asleep', 'nap', 'unable', 'quiet'])
    return dict(household_routine_anomaly_label='',
        any_resident_eating_or_cooking_minutes=int(np.isin(states, ['eating', 'cooking']).any(axis=1).sum()*15),
        any_resident_active_minutes=int(active.any(axis=1).sum()*15),
        elder_active_minutes=int(active[:, 0].sum()*15),
        elder_concern_minutes=int((states[:, 0] == 'unable').sum()*15),
        other_residents_active_person_minutes=int(active[:, 1:].sum()*15),
        whole_household_away_minutes=int((states == 'away').all(axis=1).sum()*15),
        visitor_minutes=sum(int(r['visitor_present'])*15 for r in rows))


def elder_metrics(windows, start, end, episodes):
    decisions = np.arange(start+1, end+1)
    scores = np.full(len(decisions), np.nan)
    for row in windows:
        if row['eligible']:
            scores[row['end_hour_exclusive']-start-1] = row['alarm']
    included = [e for e in episodes if e['start'] >= start and e['end'] <= end]
    # A window ending exactly at onset contains no measurements from the concern.
    summary, events, _ = detection(decisions, scores, .5, included, include_onset=False)
    scheduled = len(windows)
    eligible = sum(r['eligible'] for r in windows)
    return dict(days=(end-start)/24, scheduled_windows=scheduled, eligible_windows=eligible,
        scheduled_coverage=eligible/scheduled if scheduled else None,
        alarms=sum(r['alarm'] == 1 for r in windows), elder_episodes=len(included),
        excluded_boundary_episodes=sum(e['start'] < end and e['end'] > start and e not in included for e in episodes),
        detected_elder_episodes=summary['detected_episodes'], elder_recall=summary['recall'],
        observable_elder_episodes=summary['observable_episodes'], observable_elder_recall=summary['observable_recall'],
        elder_precision=summary['alert_precision'], elder_f1=summary['episode_alert_f1'],
        median_delay_hours=summary['median_delay_hours'], p90_delay_hours=summary['p90_delay_hours'],
        duplicate_alerts=summary['duplicate_alerts'],
        alarms_without_elder_concern=summary['false_alerts'],
        unmatched_elder_alarms_per_30_days=summary['false_alerts_per_30_days']), events


def run(data, forecasts, out):
    if out.exists():
        raise FileExistsError(f'Refusing to overwrite {out}')
    if any(root.resolve() in [out.resolve(), *out.resolve().parents] for root in [data, forecasts]):
        raise ValueError('Output must be outside the frozen dataset and forecasting run')
    validate_dataset(data, write_result=False)
    verify_run(forecasts, data)
    cases = {r['case_id']: r for r in read(data/'challenge'/'truth'/'cases.csv')}
    observations, truth = defaultdict(dict), defaultdict(dict)
    for prefix in [data, data/'challenge']:
        for r in read(prefix/'hourly.csv'):
            observations[r['case_id']][int(r['hour'])] = float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan
        for r in read(prefix/'truth'/'resident_activity_15min.csv'):
            truth[r['case_id']][int(r['slot'])] = r
    # The frozen split file defines dates; do not infer boundaries from forecast coverage.
    partitions = {r['partition']: tuple(int((datetime.fromisoformat(r[k])-ORIGIN).total_seconds()/3600)
                  for k in ['start_time', 'end_time_exclusive']) for r in read(data/'splits.csv')}
    periods = {('main', part): partitions[part] for part in ['validation', 'test']}
    periods.update({(key, c['partition']): (int(c['replay_start_slot'])//4, int(c['replay_end_slot'])//4)
                    for key, c in cases.items()})
    episodes = [dict(id=r['episode_id'], start=int(r['start_slot'])/4, end=int(r['end_slot'])/4)
                for r in read(data/'truth'/'episodes.csv') if r['concern_label'] == '1']
    groups = defaultdict(dict)
    for r in read(forecasts/'predictions.csv'):
        key = (r['model'], r['seed'], r['case_id'], r['partition'])
        hour = int(r['target_hour'])
        if hour in groups[key]:
            raise ValueError('Duplicate prediction timestamp')
        if r['issued_time'] != stamp(hour):
            raise ValueError('Forecast must be issued at the start of its target hour')
        groups[key][hour] = float(r['prediction_kwh'])
    systems = sorted({(model, seed) for model, seed, _, _ in groups})
    expected = {(m, s, c, p) for m, s in systems for c, p in periods}
    if not systems or set(groups) != expected:
        raise ValueError('Every system must cover the same main and challenge partitions')
    for (model, seed, case, part), values in groups.items():
        a, b = periods[(case, part)]
        if set(values) != set(range(a, b)) or not np.isfinite(list(values.values())).all():
            raise ValueError(f'Incomplete predictions: {model}, {seed}, {case}, {part}')

    cfg = dict(paper=PAPER, method='Section 4 activity-window alarm replay; existing forecasters unchanged',
        windows='sleep [00:00,06:00); breakfast [08:00,11:00); lunch [13:00,16:00); UTC+08',
        meal_rule='mean(predicted-observed) > 3*std(predicted-observed)',
        sleep_rule='mean(observed-predicted) > std(predicted-observed)',
        sigma='population standard deviation of signed hourly errors within the same completed activity window',
        sigma_ddof=0, hour_boundaries='start inclusive, end exclusive; alarm issued at window end',
        sleep_interpretation='paper prints 12 p.m. to 6 a.m.; interpreted as midnight to 06:00 based on nighttime wording',
        availability='all hourly electricity snapshots must be complete at their original hour close; no backfill',
        threshold_tuning='none; fixed multipliers 3/3/1; no false-alert budget',
        household_labels='not available; resident-state context is review evidence, not an anomaly label',
        elder_matching='alarm decision > true onset and < true end; window must include post-onset observations; all in-boundary concerns in recall',
        forecasters='saved multivariate models, not a reproduction of the paper neural architectures or input channels',
        challenge='separate alternatives; no concatenation; one alarm/no-alarm result per labelled interval',
        python=platform.python_version(), numpy=np.__version__,
        forecasts=str(forecasts.resolve()), dataset=str(data.resolve()),
        forecast_manifest_sha256=hashlib.sha256((forecasts/'manifest.csv').read_bytes()).hexdigest(),
        dataset_manifest_sha256=hashlib.sha256((data/'manifest.csv').read_bytes()).hexdigest())
    out.mkdir(parents=True)
    write_csv(out/'config.csv', [dict(parameter=k, value=v) for k, v in cfg.items()])
    (out/'config.csv').chmod(0o444)
    (out/'source').mkdir()
    for name in ['paper_alarms.py', 'evaluation.py', 'generate.py', 'validate.py']:
        shutil.copy(Path(__file__).with_name(name), out/'source'/name)
    shutil.copy(data/'manifest.csv', out/'dataset_manifest.csv')
    shutil.copy(forecasts/'manifest.csv', out/'forecast_manifest.csv')
    planned, contexts = {}, []
    for (case, part), (a, b) in periods.items():
        planned[(case, part)] = []
        for window in schedule(a, b):
            info = dict(case_id=case, partition=part, **window,
                window_start_time=stamp(window['start_hour']), decision_time=stamp(window['end_hour_exclusive']))
            planned[(case, part)].append(info)
            states = [truth[case][s] for s in range(window['start_hour']*4, window['end_hour_exclusive']*4)]
            contexts.append(dict(**info, **context(states)))
    windows, main_metrics, event_results, case_results, activity_metrics = [], [], [], [], []
    for (model, seed, case, part), predictions in sorted(groups.items()):
        own = []
        for window in planned[(case, part)]:
            hours = range(window['start_hour'], window['end_hour_exclusive'])
            row = dict(model=model, seed=seed, **window, **window_alarm(
                [predictions[h] for h in hours], [observations[case][h] for h in hours],
                window['direction'], window['multiplier']))
            own.append(row)
        windows.extend(own)
        a, b = periods[(case, part)]
        if case == 'main':
            summary, events = elder_metrics(own, a, b, episodes)
            main_metrics.append(dict(model=model, seed=seed, partition=part, **summary))
            event_results.extend(dict(model=model, seed=seed, partition=part, **r) for r in events)
            for activity, *_ in WINDOWS:
                selected = [r for r in own if r['activity'] == activity]
                activity_metrics.append(dict(model=model, seed=seed, partition=part, activity=activity,
                    scheduled_windows=len(selected), eligible_windows=sum(r['eligible'] for r in selected),
                    alarms=sum(r['alarm'] == 1 for r in selected)))
        else:
            c = cases[case]
            during = [r for r in own if int(c['start_slot'])/4 < r['end_hour_exclusive'] < int(c['end_slot'])/4]
            case_results.append(dict(model=model, seed=seed, case_id=case, pair_id=c['pair_id'],
                partition=part, scenario=c['scenario'], concern=int(c['concern']),
                scheduled_decisions_in_labelled_interval=len(during),
                observable=int(any(r['eligible'] for r in during)),
                alarm_in_labelled_interval=int(any(r['alarm'] == 1 for r in during)),
                alarms_in_whole_replay=sum(r['alarm'] == 1 for r in own)))
    for name, rows in [('activity_windows', windows), ('window_context', contexts), ('activity_metrics', activity_metrics),
                       ('elder_metrics', main_metrics), ('elder_episode_results', event_results), ('challenge_results', case_results)]:
        write_csv(out/f'{name}.csv', rows)
    report(out, main_metrics, case_results, activity_metrics)
    write_csv(out/'completed.csv', [dict(systems=len(systems), model_fits=0, activity_decisions=len(windows))])
    write_csv(out/'manifest.csv', [dict(file=str(p.relative_to(out)), sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in sorted(out.rglob('*')) if p.is_file()])
    for p in out.rglob('*'):
        if p.is_file(): p.chmod(0o444)
    print(f'Completed {out}: {len(systems)} systems, {len(windows)} activity decisions; no model retraining.')


def report(out, metrics, cases, activities):
    comparison = []
    for model in sorted({r['model'] for r in metrics}):
        own = [r for r in metrics if r['model'] == model and r['partition'] == 'test']
        challenge = [r for r in cases if r['model'] == model and r['partition'] == 'test']
        per_seed = []
        for seed in sorted({r['seed'] for r in challenge}):
            selected = [r for r in challenge if r['seed'] == seed]
            tp = sum(r['concern'] and r['alarm_in_labelled_interval'] for r in selected)
            fp = sum(not r['concern'] and r['alarm_in_labelled_interval'] for r in selected)
            fn = sum(r['concern'] and not r['alarm_in_labelled_interval'] for r in selected)
            per_seed.append((tp/(tp+fn), 2*tp/(2*tp+fp+fn)))
        row = dict(model=model, runs=len(own), mean_household_alarms=np.mean([r['alarms'] for r in own]),
            scheduled_coverage=np.mean([r['scheduled_coverage'] for r in own]),
            elder_recall=np.mean([r['elder_recall'] for r in own]),
            unmatched_elder_alarms_per_30_days=np.mean([r['unmatched_elder_alarms_per_30_days'] for r in own]),
            challenge_elder_recall=np.mean([r[0] for r in per_seed]), challenge_elder_f1=np.mean([r[1] for r in per_seed]))
        for activity, *_ in WINDOWS:
            row[activity+'_alarms'] = np.mean([r['alarms'] for r in activities
                if r['model'] == model and r['partition'] == 'test' and r['activity'] == activity])
        comparison.append(row)
    write_csv(out/'comparison.csv', comparison)
    lines = ['# Paper activity alarms on the frozen family forecasts', '',
        f'Implements the alarm equations in [Section 4 of Hernández et al. (2024)]({PAPER}). This is an alarm-stage adaptation, not an exact paper reproduction. No models were retrained; all saved seeds are retained.', '',
        'Breakfast [08:00,11:00) and lunch [13:00,16:00): mean predicted minus observed electricity must exceed 3σ. Sleep [00:00,06:00): mean observed minus predicted electricity must exceed σ. All times are local UTC+08. σ is the population standard deviation (ddof=0) of signed hourly errors in that same completed window. The paper does not specify ddof or exact hour inclusion; its nighttime 12 p.m. wording is interpreted as midnight. These choices are frozen in config.csv.', '',
        'No false-alert-budget threshold is applied. Every hour must have a valid timely electricity snapshot; otherwise the entire activity window abstains. No delayed backfill or label influences an alarm. Using kWh rather than normalized energy does not alter these inequalities.', '',
        '## Household routine alarms', '',
        'The main test contains 73 days and 219 scheduled activity windows per run. There are no independently annotated household breakfast/lunch/sleep anomaly labels in this dataset. Therefore household anomaly precision, recall and F1 cannot be estimated. window_context.csv supplies simulator activity evidence for review; it is not an invented anomaly label.', '',
        '| Forecaster | Runs | Breakfast alarms | Lunch alarms | Sleep alarms | Scheduled coverage |',
        '|---|---:|---:|---:|---:|---:|']
    for r in comparison:
        lines.append(f'| {r["model"]} | {r["runs"]} | {r["breakfast_alarms"]:.1f} | {r["lunch_alarms"]:.1f} | {r["sleep_alarms"]:.1f} | {r["scheduled_coverage"]:.1%} |')
    lines += ['', 'Counts are means across seeds, not a selection of the best seed. Existing forecasters use water/gate/app inputs as well as electricity and have different architectures from the paper. Reusing them isolates the alarm-stage change. Spanish activity times are applied literally to the simulated family; they are not tuned to its meals.', '',
        '## Separate elder-concern assessment', '',
        '| Forecaster | Main elder recall | Alarms without elder concern / 30 days | Challenge elder recall | Challenge elder F1 |',
        '|---|---:|---:|---:|---:|']
    for r in comparison:
        lines.append(f'| {r["model"]} | {r["elder_recall"]:.1%} | {r["unmatched_elder_alarms_per_30_days"]:.2f} | {r["challenge_elder_recall"]:.1%} | {r["challenge_elder_f1"]:.3f} |')
    lines += ['', 'These columns assess use as an elder-concern alarm; an unmatched alarm could still represent a genuine household routine change. They are not the paper household-activity metrics. An alarm is issued only at 06:00, 11:00 or 16:00 and detects a concern only strictly after onset and before its end. An alarm exactly at onset uses entirely pre-concern observations and receives no detection credit. Both main test concerns remain in recall, including concerns outside the schedule or during missing observations. Detection delay begins at simulated onset.', '',
        'Each challenge is a separate replay; its result asks whether any issued alarm falls within the labelled interval. There are 12 positive and 12 benign test alternatives, paired by scenario. This enriched F1 cannot estimate production precision. The main test has only two concerns. No result establishes medical validity or generalisation to other families.', '',
        '## Review and reproduce', '',
        'activity_windows.csv contains every per-window mean, σ, threshold, margin, decision time and abstention. activity_metrics.csv, elder_metrics.csv, elder_episode_results.csv and challenge_results.csv retain every seed. config.csv, source/, dataset_manifest.csv and forecast_manifest.csv record the method and input identities. The original dataset and forecasting results are unchanged.']
    (out/'report.md').write_text('\n'.join(lines)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, default=Path(__file__).with_name('data'))
    parser.add_argument('--run', type=Path, required=True, help='Completed frozen forecasting run')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    run(args.data, args.run, args.out)
