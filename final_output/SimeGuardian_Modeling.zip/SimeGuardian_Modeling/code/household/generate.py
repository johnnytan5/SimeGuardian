"""One family's synthetic year: behaviour -> physical use -> imperfect observations.

No clinical, population or country calibration is claimed. See README.md.
"""
import argparse
import csv
import hashlib
import platform
import shutil
from importlib.metadata import version
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

VERSION = 'family-elder-v1'
SEED = 20261023
SLOTS = 365 * 96
ORIGIN = datetime(2026, 1, 1, tzinfo=timezone(timedelta(hours=8)))
RESIDENTS = [('E1', 'older_adult', 72), ('A1', 'adult', 43), ('A2', 'adult', 41),
             ('C1', 'child', 12), ('C2', 'child', 9)]
PARTITIONS = [('history', 0, 14), ('train', 14, 219),
              ('validation', 219, 292), ('test', 292, 365)]
SOURCES = ['electricity', 'water', 'gate', 'app', 'elder_app']
FEATURE_COLUMNS = (['hour_of_day', 'day_of_week']
    + [f'{source}{suffix}' for source,unit in [('electricity','kwh'),('water','litres')]
       for suffix in [f'_{unit}', f'_partial_{unit}', '_observed_fraction']]
    + [f'{source}_observed_fraction' for source in ['gate','app','elder_app']]
    + [f'{source}_{kind}_count' for source in ['gate','app']
       for kind in ['elder_verified','other_verified','unverified']]
    + ['app_background_count'])


def timestamp(slot):
    return (ORIGIN + timedelta(minutes=float(slot) * 15)).isoformat() if np.isfinite(slot) else ''


def partition(slot):
    return next(name for name, a, b in PARTITIONS if a * 96 <= slot < b * 96)


def write_csv(path, rows, fields=None):
    rows = list(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def number(value):
    return round(float(value), 6) if np.isfinite(value) else ''


def routine(seed=SEED):
    """States are evaluation truth, never sensor features."""
    rng = np.random.default_rng(seed)
    states = np.full((5, SLOTS), 'asleep', dtype='<U16')
    visitor = np.zeros(SLOTS, bool)
    scenarios = []
    for day in range(365):
        a = day * 96
        weekday = (ORIGIN + timedelta(days=day)).weekday() < 5
        school_break = 75 <= day < 87 or 155 <= day < 181 or 330 <= day < 345
        for r in range(5):
            shift = 3 if r == 0 and day >= 310 else 0  # Later routine in the held-out period.
            wake = int(np.clip(rng.normal(26 if r < 3 else 25, 2), 20, 36)) + shift
            bed = int(np.clip(rng.normal(88 if r == 0 else 91 if r < 3 else 85, 2), 78, 95))
            states[r, a+wake:a+bed] = 'leisure'
            if r in (1, 2) and weekday and rng.random() > (.12 if r == 1 else .25):
                leave, back = int(rng.integers(29, 34)), int(rng.integers(68, 78))
                states[r, a+leave:a+back] = 'away'
            elif r >= 3 and weekday and not school_break:
                states[r, a+27:a+int(rng.integers(57, 65))] = 'away'
            elif r == 0 and rng.random() < .32:
                leave = int(rng.integers(34, 55))
                states[r, a+leave:a+leave+int(rng.integers(4, 17))] = 'away'
            elif not weekday and rng.random() < .45:
                leave = int(rng.integers(36, 53))
                states[r, a+leave:a+leave+int(rng.integers(8, 25))] = 'away'
            # Schedule activities only while the person is actually at home and awake.
            for center, activity, length in [(wake+1, 'personal_care', 1), (30+shift, 'eating', 2),
                                            (51+shift, 'eating', 3), (76, 'eating', 3),
                                            (83, 'personal_care', 1)]:
                start = int(np.clip(center + rng.integers(-2, 3), wake, bed-1))
                ids = np.arange(a+start, min(a+start+length, a+bed))
                states[r, ids[states[r, ids] == 'leisure']] = activity
            if r == 0:
                start = a + int(rng.integers(53, 63))
                if rng.random() < .5 and (states[r, start:start+8] != 'away').all():
                    states[r, start:start+int(rng.integers(2, 9))] = 'nap'
                if rng.random() < .18:
                    ids = np.arange(a+wake, a+bed)
                    states[r, ids[states[r, ids] == 'leisure']] = 'quiet'
            if r < 3:
                for center in (49, 73):
                    start = a + center + int(rng.integers(-3, 4))
                    ids = np.arange(start, start+3)
                    states[r, ids[states[r, ids] == 'leisure']] = 'cooking'
                start = a + int(rng.integers(35, 70))
                if rng.random() < .4 and (states[r, start:start+4] == 'leisure').all():
                    states[r, start:start+4] = 'chores'
        if rng.random() < .13:
            start = a + int(rng.integers(43, 77))
            visitor[start:min(start+int(rng.integers(4, 17)), a+94)] = True
    states[:, 100*96:104*96] = 'away'
    states[1:, 304*96:308*96] = 'away'
    for a, b, kind in [(100, 104, 'whole_family_trip'), (304, 308, 'family_trip_elder_stays'),
                        (310, 365, 'elder_routine_shifts_later')]:
        scenarios.append(dict(kind=kind, start=a*96, end=b*96, concern=0))
    # Six explicitly enriched cases, not an estimate of the frequency of emergencies.
    for day, hour in [(62, 10), (160, 18), (234, 11), (278, 18), (315, 11), (351, 18)]:
        duration = int(rng.integers(12, 29))
        for offset in range(12):
            start = (day+offset)*96 + hour*4
            if (states[0, start-2:start+duration] != 'away').all():
                break
        else:
            raise ValueError('Could not schedule an at-home concern')
        states[0, start:start+duration] = 'unable'
        scenarios.append(dict(kind='elder_unable_to_initiate_usual_activity', start=start,
                              end=start+duration, concern=1))
    changes = np.r_[0, np.flatnonzero(states[0,1:] != states[0,:-1])+1, SLOTS]
    for start,end in zip(changes[:-1],changes[1:]):
        if states[0,start] in ['nap','quiet','away']:
            scenarios.append(dict(kind='benign_elder_'+str(states[0,start]),
                                  start=int(start), end=int(end), concern=0))
    return states, visitor, scenarios


def delivery(seed):
    rng = np.random.default_rng(seed+1)
    arrivals, faults = {}, []
    for source, count, max_hours, late_rate in [('electricity', 6, 18, .015), ('water', 8, 24, .025),
            ('gate', 10, 18, .02), ('app', 6, 12, .02), ('elder_app', 28, 48, .03)]:
        arr = np.arange(1, SLOTS+1, dtype=float)
        delayed = rng.random(SLOTS) < late_rate
        arr[delayed] += rng.choice([1, 4, 16, 96], delayed.sum(), p=[.6, .25, .1, .05])
        for _ in range(count):
            start = int(rng.integers(96, SLOTS-max_hours*4))
            end = start + int(rng.integers(4, max_hours*4+1))
            arr[start:end] = np.inf
            faults.append(dict(source=source, kind='offline_or_lost', start=start, end=end))
        arr[rng.random(SLOTS) < .001] = np.inf
        arrivals[source] = arr
    for day in [83, 255, 337]:
        start, end = day*96+36, day*96+60
        for source in SOURCES:
            ids = np.arange(start, end)
            online = np.isfinite(arrivals[source][ids])
            arrivals[source][ids[online]] = end+4  # Buffered shared-network outage.
            faults.append(dict(source=source, kind='buffered_network_delay', start=start, end=end))
    arrivals['elder_app'] = np.maximum(arrivals['elder_app'], arrivals['app'])
    return arrivals, faults


def signals(states, visitor, seed, extra_running=None):
    """Household demand is an aggregate of people plus autonomous equipment."""
    rng = np.random.default_rng(seed+2)
    n = states.shape[1]
    hour = np.arange(n) % 96 / 4
    active = ~np.isin(states, ['away', 'asleep', 'nap', 'unable', 'quiet'])
    home = states != 'away'
    resident_draw = rng.random(states.shape)
    standby = np.full(n, .018)  # 72 W household standby, expressed as kWh per 15 min.
    fridge = np.where((np.arange(n)+seed % 9) % 8 < 3, .033, .001)
    lights_fans = (.012*home.sum(0) + .009*active.sum(0)*(hour > 17))
    heat = np.clip(.55 + .2*np.sin(2*np.pi*(np.arange(n)/96-20)/365) + rng.normal(0, .1, n), .1, .95)
    cooling = .22*((hour >= 20) | (hour < 6)) * home.any(0) * (rng.random(n) < heat)
    cooking = np.any(states == 'cooking', axis=0)*rng.uniform(.08, .38, n)
    bathing = (states == 'personal_care').sum(0)*rng.uniform(.04, .22, n)
    entertainment = np.any(np.isin(states, ['leisure', 'eating']), axis=0)*rng.uniform(.012, .045, n)
    automatic = np.zeros(n)
    starts = np.flatnonzero(np.any(states == 'chores', axis=0) & (rng.random(n) < .13))
    for start in starts:
        automatic[start:min(start+8, n)] += np.array([.12, .04, .03, .05, .04, .03, .04, .08])[:min(8,n-start)]
    guests = visitor*rng.uniform(.015, .07, n)
    running = np.zeros(n) if extra_running is None else extra_running
    components = dict(standby_kwh=standby, fridge_kwh=fridge, fans_lights_kwh=lights_fans,
                      cooling_kwh=cooling, cooking_kwh=cooking, hot_water_kwh=bathing,
                      entertainment_kwh=entertainment, automatic_cycles_kwh=automatic,
                      visitors_kwh=guests, extra_running_kwh=running)
    electricity = sum(components.values())
    water = ((states == 'personal_care').sum(0)*rng.uniform(25, 55, n)
             + np.any(states == 'cooking', axis=0)*rng.uniform(2, 8, n)
             + ((resident_draw < .09) & active).sum(0)*rng.uniform(3, 7, n)
             + ((states == 'chores') & (resident_draw < .3)).sum(0)*rng.uniform(8, 20, n)
             + visitor*(rng.random(n) < .2)*rng.uniform(2, 7, n))
    water[157*96:160*96] += 1.5  # Physical small leak, independent of resident activity.
    for day in [45, 250, 333]:
        ids = slice(day*96+40, day*96+48)
        electricity[ids] = 0
        for component in components.values():
            component[ids] = 0
    return electricity, water, components


def observe(states, visitor, arrivals, seed, extra_running=None):
    electricity, water, components = signals(states, visitor, seed, extra_running)
    rng = np.random.default_rng(seed+3)
    values = {'electricity': np.maximum(0, electricity*(1+rng.normal(0, .012, SLOTS))).round(6),
              'water': np.maximum(0, water*(1+rng.normal(0, .025, SLOTS))).round(3)}
    for name in values:
        values[name][~np.isfinite(arrivals[name])] = np.nan
    events = []
    def append(source, slot, person, kind, verified):
        event_rng = np.random.default_rng(np.random.SeedSequence([seed, slot, person,
            ['exit','entry','foreground_action','background_sync','visitor_entry'].index(kind)]))
        feed = 'elder_app' if source == 'app' and person == 0 else source
        arrival = arrivals[feed][slot]
        if not np.isfinite(arrival):
            return
        event_time = slot + event_rng.uniform(.05, .85)
        shared = not verified and event_rng.random() < .45
        events.append(dict(source=source, event_slot=event_time,
            received_slot=event_time+max(0, arrival-slot-1)+.01,
            event_type=kind, claimed_resident_id='E1' if shared else RESIDENTS[person][0],
            attribution='verified' if verified else 'shared_or_unverified',
            meaningful=int(kind != 'background_sync')))
    for r in range(5):
        draws = np.random.default_rng(seed+300+r).random((5,SLOTS))
        # Gate observations are imperfect records of transitions, not occupancy truth.
        crossings = np.flatnonzero((states[r, 1:] == 'away') != (states[r, :-1] == 'away'))+1
        for slot in crossings:
            if draws[0,slot] > .22:
                append('gate', slot, r, 'exit' if states[r, slot] == 'away' else 'entry', draws[1,slot] < (.72 if r<3 else .15))
        eligible = ~np.isin(states[r], ['asleep', 'nap', 'unable'])
        probability = .009 if r == 0 else .045 if r < 3 else .015
        for slot in np.flatnonzero((draws[2] < probability) & eligible):
            append('app', slot, r, 'foreground_action', r<3 and draws[3,slot] < .88)
        # Automatic traffic is never proof of human activity, including during concerns.
        for slot in np.flatnonzero(draws[4] < .025):
            append('app', slot, r, 'background_sync', False)
    for slot in np.flatnonzero(visitor & ~np.roll(visitor, 1)):
        append('gate', slot, 1, 'visitor_entry', False)
    events.sort(key=lambda row: row['event_slot'])
    return dict(values=values, arrivals=arrivals, events=events, components=components)


def hour_row(data, hour, issued_slot):
    ids = np.arange(hour*4, hour*4+4)
    if issued_slot < ids[-1]+1:
        raise ValueError('An unfinished hour cannot be an input')
    row = dict(household_id='HH001', hour=hour, start_time=timestamp(ids[0]),
               end_time=timestamp(ids[-1]+1), issued_time=timestamp(issued_slot),
               partition=partition(ids[0]), hour_of_day=hour % 24,
               day_of_week=(ORIGIN+timedelta(hours=hour)).weekday())
    for name, unit in [('electricity', 'kwh'), ('water', 'litres')]:
        known = np.isfinite(data['values'][name][ids]) & (data['arrivals'][name][ids] <= issued_slot)
        observed = data['values'][name][ids][known]
        row[f'{name}_{unit}'] = number(observed.sum()) if known.all() else ''
        row[f'{name}_partial_{unit}'] = number(observed.sum()) if known.any() else ''
        row[f'{name}_observed_fraction'] = float(known.mean())
    for name in ['gate', 'app', 'elder_app']:
        row[f'{name}_observed_fraction'] = float((data['arrivals'][name][ids] <= issued_slot).mean())
    events = [e for e in data['events_by_hour'].get(hour, []) if e['received_slot'] <= issued_slot]
    for source in ['gate', 'app']:
        own = [e for e in events if e['source'] == source and e['meaningful']]
        for label, selected in [('elder_verified', [e for e in own if e['attribution']=='verified' and e['claimed_resident_id']=='E1']),
                ('other_verified', [e for e in own if e['attribution']=='verified' and e['claimed_resident_id']!='E1']),
                ('unverified', [e for e in own if e['attribution']!='verified'])]:
            coverage = 'elder_app' if source=='app' and label=='elder_verified' else source
            row[f'{source}_{label}_count'] = len(selected) if row[f'{coverage}_observed_fraction']==1 else ''
    row['app_background_count'] = (sum(e['source']=='app' and not e['meaningful'] for e in events)
                                   if row['app_observed_fraction']==1 else '')
    return row


def index_events(data):
    data['events_by_hour'] = {}
    for event in data['events']:
        data['events_by_hour'].setdefault(int(event['event_slot']//4), []).append(event)


def rows_for(data, states, visitor, start, end, case_id='main'):
    index_events(data)
    raw, hours, targets, labels, truth, event_rows = [], [], [], [], [], []
    for slot in range(start, end):
        row = dict(case_id=case_id, household_id='HH001', slot=slot,
                   start_time=timestamp(slot), end_time=timestamp(slot+1))
        for name, unit in [('electricity', 'kwh'), ('water', 'litres')]:
            row[f'{name}_{unit}'] = number(data['values'][name][slot])
        for name in SOURCES:
            row[f'{name}_received_at'] = timestamp(data['arrivals'][name][slot])
        raw.append(row)
        truth.append(dict(case_id=case_id, slot=slot, start_time=timestamp(slot),
            **{resident[0]+'_state': str(states[r,slot]) for r,resident in enumerate(RESIDENTS)},
            visitor_present=int(visitor[slot])))
    for hour in range(start//4, end//4):
        ids = np.arange(hour*4, hour*4+4)
        hours.append(dict(case_id=case_id, **hour_row(data, hour, (hour+1)*4)))
        value = data['values']['electricity'][ids]
        valid = np.isfinite(value).all()
        targets.append(dict(case_id=case_id, hour=hour, start_time=timestamp(hour*4),
            electricity_kwh=number(value.sum()) if valid else '', observed=int(valid),
            target_available_at=timestamp(data['arrivals']['electricity'][ids].max()) if valid else ''))
        labels.append(dict(case_id=case_id, hour=hour, start_time=timestamp(hour*4), partition=partition(hour*4),
            elder_concern_minutes=int(np.sum(states[0,ids]=='unable')*15),
            elder_home_minutes=int(np.sum(states[0,ids]!='away')*15),
            elder_quiet_minutes=int(np.sum(np.isin(states[0,ids], ['quiet','nap','asleep']))*15),
            other_residents_home_minutes=int(np.sum(states[1:,ids]!='away')*15),
            other_residents_active_minutes=int(np.sum(~np.isin(states[1:,ids], ['away','asleep','nap','quiet','unable']))*15),
            visitor_minutes=int(visitor[ids].sum()*15)))
    for i, event in enumerate(data['events']):
        if start <= event['event_slot'] < end:
            event_rows.append(dict(case_id=case_id, event_id=f'{case_id}-{i:06}', household_id='HH001',
                source=event['source'], event_time=timestamp(event['event_slot']), received_at=timestamp(event['received_slot']),
                event_type=event['event_type'], claimed_resident_id=event['claimed_resident_id'],
                attribution=event['attribution'], meaningful=event['meaningful']))
    return dict(observations_15min=raw, hourly=hours, targets_hourly=targets,
                labels_hourly=labels, resident_activity_15min=truth, events=event_rows)


def challenge_cases(states, visitor, arrivals, seed):
    """Paired alternative replays of one home, never 48 independent households."""
    kinds = ['elder_alone', 'family_active', 'appliances_running', 'weak_feeds',
             'elder_away_or_unable', 'visitors_and_shared_activity']
    rng = np.random.default_rng(seed+4)
    for name, first, last in [('validation',219,292), ('test',292,365)]:
        for pair in range(12):
            day = first+2+pair*5
            a, b = day*96, (day+2)*96
            while np.any(states[0,a:b]=='unable'):
                day += 2
                a,b = day*96, (day+2)*96
            if day+2 > last:
                raise ValueError('Challenge crosses a partition boundary')
            start = a+96+40
            end = start+int(rng.integers(12,29))
            kind = kinds[pair%6]
            rest_breaks = rng.choice(np.arange(start+4,end-1), int(rng.integers(0,3)), replace=False)
            for concern in [False, True]:
                s, v = states.copy(), visitor.copy()
                delivery_copy = {k:x.copy() for k,x in arrivals.items()}
                extra = np.zeros(SLOTS)
                if kind=='elder_alone':
                    s[1:,start-8:end+8] = 'away'
                else:
                    s[1:,start-8:end+8] = 'leisure'
                    s[1,start+2:start+5] = 'cooking'
                    s[2,start+8:start+9] = 'personal_care'
                s[0,start-4:start] = 'quiet'
                s[0,start:end] = 'unable' if concern else 'quiet'
                if kind=='elder_away_or_unable' and not concern:
                    s[0,start:end] = 'away'
                if kind=='appliances_running':
                    extra[start:end] = .18
                    if not concern:
                        s[0,start:min(start+8,end)] = 'nap'
                if not concern and kind!='elder_away_or_unable':
                    s[0,rest_breaks] = 'eating'
                if kind=='weak_feeds':
                    for source in ['water','elder_app']:
                        delivery_copy[source][start-4:end+4] = np.inf
                if kind=='visitors_and_shared_activity':
                    v[start-4:end+4] = True
                yield dict(case_id=f'{name}-{pair+1:02}-{int(concern)}', pair_id=f'{name}-{pair+1:02}',
                    partition=name, scenario=kind, concern=int(concern), start_slot=start, end_slot=end,
                    replay_start_slot=a, replay_end_slot=b, target_resident_id='E1'), s, v, delivery_copy, extra


def build(root, seed=SEED):
    if root.exists():
        raise FileExistsError(f'Refusing to overwrite {root}; choose a new output path')
    root.mkdir(parents=True)
    states, visitor, scenarios = routine(seed)
    arrivals, faults = delivery(seed)
    data = observe(states, visitor, arrivals, seed)
    tables = rows_for(data, states, visitor, 0, SLOTS)
    for name, rows in tables.items():
        folder = root/'truth' if name in ['labels_hourly','resident_activity_15min'] else root
        write_csv(folder/f'{name}.csv', rows)
    write_csv(root/'truth'/'appliance_energy_15min.csv', (
        dict(slot=i, start_time=timestamp(i), **{k:number(v[i]) for k,v in data['components'].items()}) for i in range(SLOTS)))
    write_csv(root/'truth'/'episodes.csv', (dict(episode_id=f'episode-{i+1:02}', target_resident_id='E1',
        episode_type=x['kind'], start_time=timestamp(x['start']), end_time=timestamp(x['end']),
        start_slot=x['start'], end_slot=x['end'], concern_label=x['concern'], partition=partition(x['start']),
        label_basis='simulator resident state; not a clinical diagnosis') for i,x in enumerate(scenarios)))
    write_csv(root/'truth'/'sensor_incidents.csv', (dict(source=x['source'], kind=x['kind'],
        start_time=timestamp(x['start']), end_time=timestamp(x['end'])) for x in faults))
    write_csv(root/'truth'/'physical_incidents.csv', [
        *[dict(kind='mains_power_cut',start_time=timestamp(d*96+40),end_time=timestamp(d*96+48)) for d in [45,250,333]],
        dict(kind='water_leak',start_time=timestamp(157*96),end_time=timestamp(160*96))])
    write_csv(root/'residents.csv', (dict(resident_id=r, role=role, assumed_age=age,
        monitoring_target=int(r=='E1')) for r,role,age in RESIDENTS))
    write_csv(root/'splits.csv', (dict(partition=name, start_time=timestamp(a*96),
        end_time_exclusive=timestamp(b*96), days=b-a, target_hours=(b-a)*24,
        permitted_use='initial history only' if name=='history' else 'fit preprocessing and weights' if name=='train' else 'select thresholds' if name=='validation' else 'final evaluation only')
        for name,a,b in PARTITIONS))
    config = dict(version=VERSION, seed=seed, days=365, household_count=1, residents=5,
        python_version=platform.python_version(), numpy_version=np.__version__, matplotlib_version=version('matplotlib'),
        target_resident='E1', timezone='UTC+08:00', history_days=14,
        concern_episodes=6, concern_rate_interpretation='deliberately enriched; not population prevalence',
        challenge_pairs=24, challenge_interpretation='balanced counterfactual cases, not chronological prevalence',
        data_origin='synthetic assumptions, no real household measurements', units='kWh per interval; litres per interval',
        real_world_calibration='none', models_trained=0)
    write_csv(root/'config.csv', (dict(parameter=k,value=v) for k,v in config.items()))
    write_csv(root/'feature_allowlist.csv', (dict(column=k, table='hourly.csv',
        purpose='input; use only completed hours before the prediction target') for k in FEATURE_COLUMNS))
    combined = {k:[] for k in tables}
    cases = []
    for i,(case, s, v, ar, extra) in enumerate(challenge_cases(states, visitor, arrivals, seed)):
        observed = observe(s,v,ar,seed,extra)
        rows = rows_for(observed,s,v,case['replay_start_slot'],case['replay_end_slot'],case['case_id'])
        for k in combined:
            combined[k].extend(rows[k])
        case.update(start_time=timestamp(case['start_slot']), end_time=timestamp(case['end_slot']),
                    replay_start_time=timestamp(case['replay_start_slot']),
                    history_reference='main observations before replay_start_slot; then this case only')
        cases.append(case)
        if (i+1)%8==0:
            print(f'Generated {i+1}/48 challenge replays',flush=True)
    for name, rows in combined.items():
        folder = root/'challenge'/'truth' if name in ['labels_hourly','resident_activity_15min'] else root/'challenge'
        write_csv(folder/f'{name}.csv', rows)
    write_csv(root/'challenge'/'truth'/'cases.csv', cases)
    shutil.copy(Path(__file__), root/'generator.py')
    shutil.copy(Path(__file__).with_name('README.md'), root/'README.md')
    for filename in ['validate.py','review.py']:
        shutil.copy(Path(__file__).with_name(filename),root/filename)
    validate(root)
    review(root)
    write_csv(root/'manifest.csv', (dict(file=str(p.relative_to(root)),bytes=p.stat().st_size,
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()))
    for path in root.rglob('*'):
        if path.is_file():
            path.chmod(0o444)
    print(f'Created and checked {root}: one family, 365 days, 48 paired challenge replays. No model trained.')


def validate(root):
    from validate import validate_dataset
    validate_dataset(root)


def review(root):
    from review import create_review
    create_review(root)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path(__file__).with_name('data'))
    parser.add_argument('--seed', type=int, default=SEED)
    args = parser.parse_args()
    build(args.out, args.seed)
