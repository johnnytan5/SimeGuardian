"""Readable CSV summaries and a static scientific figure; never trains a model."""
import csv
from collections import defaultdict

import numpy as np


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def save(path,rows):
    with path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def create_review(root):
    hours=read(root/'hourly.csv')
    raw=read(root/'observations_15min.csv')
    truth=read(root/'truth'/'resident_activity_15min.csv')
    rows=[]
    for name in ['history','train','validation','test']:
        own=[r for r in hours if r['partition']==name]
        for source in ['electricity','water','gate','app','elder_app']:
            coverage=[float(r[source+'_observed_fraction']) for r in own]
            rows.append(dict(partition=name,source=source,hours=len(own),
                complete_hours=sum(x==1 for x in coverage),
                complete_hour_fraction=round(sum(x==1 for x in coverage)/len(own),6),
                mean_observed_fraction=round(float(np.mean(coverage)),6)))
    save(root/'quality_summary.csv',rows)
    daily=[]
    for day in range(365):
        own=raw[day*96:(day+1)*96]
        result=dict(day=day+1,date=own[0]['start_time'][:10])
        for source,unit in [('electricity','kwh'),('water','litres')]:
            measured=[float(r[source+'_'+unit]) for r in own if r[source+'_'+unit]]
            result[source+'_observed_slots']=len(measured)
            result[source+'_measured_'+unit]=round(sum(measured),6)
            result[source+'_complete_day_'+unit]=round(sum(measured),6) if len(measured)==96 else ''
        daily.append(result)
    save(root/'daily_summary.csv',daily)
    concern_slots=[r for r in truth if r['E1_state']=='unable']
    masked=sum(any(r[p+'_state'] not in ['away','asleep','nap','quiet','unable'] for p in ['A1','A2','C1','C2']) for r in concern_slots)
    source_zeros={s:sum(r[f'{s}_{u}']!='' and float(r[f'{s}_{u}'])==0 for r in raw)
                  for s,u in [('electricity','kwh'),('water','litres')]}
    case_rows=read(root/'challenge'/'truth'/'cases.csv')
    case_raw=defaultdict(dict)
    for r in read(root/'challenge'/'observations_15min.csv'):
        case_raw[r['case_id']][int(r['slot'])]=(r['electricity_kwh'],r['water_litres'])
    indistinguishable=0
    for case in [r for r in case_rows if r['concern']=='1']:
        negative=next(r for r in case_rows if r['pair_id']==case['pair_id'] and r['concern']=='0')
        slots=range(int(case['start_slot']),int(case['end_slot']))
        indistinguishable+=all(case_raw[case['case_id']][i]==case_raw[negative['case_id']][i] for i in slots)
    lines=['# Dataset review — one family, older adult at home','',
        'Status: generated and validated; no model has been trained. This dataset replaces the deleted research experiments. All results below describe the simulator, not real people.','',
        '- One household, five residents, 365 days; 35,040 quarter-hour records and 8,760 hourly snapshots.',
        '- Resident E1 is the older adult. Two other adults and two children have independent daily routines.',
        f'- Six deliberately scheduled concern episodes, totalling {len(concern_slots)/4:.2f} hours ({len(concern_slots)/35040:.3%} of the simulated year); two per training/validation/test period. This is enriched scenario coverage, not an emergency-rate estimate.',
        f'- Other family members remain active during {masked/len(concern_slots):.1%} of concern intervals. Household activity therefore cannot be assigned automatically to E1.',
        f'- {source_zeros["electricity"]} genuine zero-electricity intervals and {source_zeros["water"]} zero-water intervals coexist with blank readings caused by unavailable feeds.',
        '- The challenge set has 48 alternative replays in 24 pairs: 12 pairs in validation and 12 in test. Do not concatenate them into a family history or treat them as independent households.',
        f'- In {indistinguishable} of the 24 challenge pairs, recorded electricity and water are exactly the same during the labelled interval despite different E1 labels. This is a constructed illustration of ambiguity, not a measured real-world frequency. Person-linked observations may help in some cases; they can also be absent.', '',
        '## Available information at the hourly decision time','',
        '| Partition | Electricity complete | Water complete | Gate complete | App server complete | E1 app complete |',
        '|---|---:|---:|---:|---:|---:|']
    for name in ['train','validation','test']:
        own=[r for r in rows if r['partition']==name]
        lines.append('| '+name+' | '+' | '.join(f'{r["complete_hour_fraction"]:.1%}' for r in own)+' |')
    lines+=['','Completeness means all four intervals were available at issue time. Event counts may still miss tailgating, unlogged activity or unverified identities. `quality_summary.csv` contains exact counts. Delayed targets remain in `targets_hourly.csv` with their arrival times.','',
        '## Consumption sanity checks','']
    for source,unit in [('electricity','kwh'),('water','litres')]:
        values=[float(r[f'{source}_complete_day_{unit}']) for r in daily if r[f'{source}_complete_day_{unit}']!='']
        lines.append(f'- {source.title()}: mean {np.mean(values):.2f} {unit}/day across {len(values)} completely observed days; 5th–95th percentile {np.percentile(values,5):.2f}–{np.percentile(values,95):.2f}. Missing days are not filled with zeros.')
    lines+=['','These checks establish internal consistency only. Consumption distributions have not been matched to a real family, meter or utility provider. All numerical settings remain assumptions.','',
        '## Files to review first','',
        '- `hourly.csv`: completed-hour inputs, availability and separate E1/other/unverified activity counts.',
        '- `truth/episodes.csv`: labelled concern and benign episodes; never model inputs.',
        '- `challenge/truth/cases.csv`: scenario pairs, onset/end, partition and history boundary.',
        '- `data_dictionary.csv`: file/column meanings and feature/truth distinction.',
        '- `validation_results.csv`: independent CSV checks; `manifest.csv`: frozen file hashes.',
        '- `overview.png`: one year of electricity, then one fixed week of energy, water and occupancy.', '',
        '## What this does and does not establish','',
        'The new dataset supports chronological forecasting and scenario-level detection experiments with attributable signals, overlapping benign/concerning patterns and explicit missingness. It does not establish model accuracy, acceptable alert thresholds, clinical validity or real-world transfer. There are only two primary test concerns and twelve positive test challenge cases, so future detection results must remain preliminary. Obtain real, consented household observations and independently documented activities before making deployment claims.','']
    (root/'review.md').write_text('\n'.join(lines))
    dictionary=[]
    descriptions={
        'case_id':'Join key only; main or an alternative replay; forbidden as model input',
        'household_id':'HH001, the only household; join key only',
        'slot':'15-minute index from 2026-01-01 00:00 UTC+08',
        'hour':'Hourly index from the same origin; join key only',
        'start_time':'Inclusive interval start; ISO8601 with UTC+08 offset',
        'end_time':'Exclusive interval end; ISO8601 with UTC+08 offset',
        'issued_time':'Hourly observation cutoff; all used records arrived by this time',
        'partition':'Frozen chronological assignment; not a model input',
        'hour_of_day':'Calendar hour 0–23 of the completed interval',
        'day_of_week':'Monday=0 through Sunday=6 of the completed interval',
        'event_time':'Physical event time; not the upload time',
        'received_at':'Time this event became available',
        'event_id':'Unique join key; never a model input',
        'source':'Gate or resident app',
        'claimed_resident_id':'Claimed account/card identity; interpret with attribution',
        'attribution':'verified or shared_or_unverified; a claim alone is not proof',
        'meaningful':'1 for a person action; 0 for automatic background traffic',
        'event_type':'Foreground action, background sync, gate entry/exit or visitor entry',
        'observed':'1 when all four electricity measurements eventually exist',
        'target_available_at':'Latest constituent arrival; never use as a predictor',
    }
    for path in [root/'hourly.csv',root/'observations_15min.csv',root/'events.csv',root/'targets_hourly.csv',
                 root/'truth'/'labels_hourly.csv',root/'truth'/'resident_activity_15min.csv']:
        first=read(path)[0]
        for column in first:
            meaning=descriptions.get(column)
            if meaning is None:
                if column.endswith('_received_at'): meaning='Interval record/coverage arrival; blank when unavailable'
                elif column.endswith('_observed_fraction'): meaning='Share of four interval records available by issue time; 0–1'
                elif column.endswith('_state'): meaning='Hidden resident state: asleep, away, leisure, eating, personal_care, cooking, chores, nap, quiet, unable'
                elif column.endswith('_minutes'): meaning='Evaluation truth, minutes within the hour; other-resident totals can exceed 60'
                elif column.endswith('_count'): meaning='Timely events in this hour; E1/other/shared attribution separated; blank if coverage incomplete'
                elif 'kwh' in column: meaning='Interval electricity consumption in kWh; partial fields sum available readings only; blank means missing'
                elif 'litres' in column: meaning='Interval water volume in litres; partial fields sum available readings only; blank means missing'
                elif column=='visitor_present': meaning='Hidden visitor presence, 0 or 1'
                else: raise ValueError('Missing dictionary entry: '+column)
            dictionary.append(dict(file=str(path.relative_to(root)),column=column,description=meaning,
                use='evaluation truth only' if 'truth' in path.parts else 'target only' if path.name=='targets_hourly.csv' else 'observation or join metadata'))
    save(root/'data_dictionary.csv',dictionary)
    plot(root,hours,truth)


def plot(root,hours,truth):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    targets=read(root/'targets_hourly.csv')
    energy=np.array([float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan for r in targets])
    water=np.array([float(r['water_litres']) if r['water_litres'] else np.nan for r in hours])
    first,last=4*24,11*24  # Fixed 5–11 January, never selected for appearance.
    x=np.arange(first,last)/24-4
    family=np.array([sum(r[p+'_state']!='away' for p in ['A1','A2','C1','C2']) for r in truth]).reshape(-1,4).mean(1)
    elder=np.array([r['E1_state']!='away' for r in truth]).reshape(-1,4).mean(1)
    fig,axes=plt.subplots(4,1,figsize=(12,12),layout='constrained')
    axes[0].plot(np.arange(len(energy))/24,energy*1000,color='#ba3f4b',lw=.35)
    axes[0].set(title='Full synthetic year · eventual observed electricity',xlabel='Day from 1 January 2026',ylabel='Wh per hour')
    axes[1].plot(x,energy[first:last]*1000,color='#ba3f4b',lw=1)
    axes[1].set(title='Fixed week · 5–11 January',ylabel='Wh per hour')
    axes[2].plot(x,water[first:last],color='#247eaf',lw=1)
    axes[2].set(title='Water available at each hourly cutoff · gaps stay missing',ylabel='Litres per hour')
    axes[3].step(x,family[first:last],where='post',color='#4c7780',label='Other family members at home')
    axes[3].step(x,elder[first:last],where='post',color='#a76834',label='Older adult at home')
    axes[3].set(title='Hidden occupancy truth · evaluation only',ylabel='Residents (hourly average)',xlabel='Day from 5 January',ylim=(-.1,4.4))
    axes[3].legend(loc='upper right',fontsize=9)
    for ax in axes:
        ax.grid(alpha=.15);ax.spines[['top','right']].set_visible(False)
    fig.suptitle('One family with an older adult · synthetic assumptions, not measured household data',fontsize=14)
    fig.savefig(root/'overview.png',dpi=150)
    plt.close(fig)
