"""Independent source LSTMs followed by app-supervised anomaly/emergency detectors."""
import argparse
import shutil
from collections import defaultdict
from pathlib import Path

import joblib
import sklearn
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g
    from .multisource_dataset import SOURCES, WEIGHTS, LABELS, source_value, confirmed_hours, validate
    from .validate import read
    from .train import fit_preprocessing, inputs, fit_model, predict, config, hour_number
    from .evaluation_v2 import fresh_output, manifest, decision_episodes
    from .evaluation import detection
else:
    import generate as g
    from multisource_dataset import SOURCES, WEIGHTS, LABELS, source_value, confirmed_hours, validate
    from validate import read
    from train import fit_preprocessing, inputs, fit_model, predict, config, hour_number
    from evaluation_v2 import fresh_output, manifest, decision_episodes
    from evaluation import detection

FEATURES = [s+'_'+kind for s in SOURCES for kind in ['shortfall','excess','available']]
FEATURES += ['gate_elder_age','gate_age_missing','app_elder_age','app_age_missing',
             'weighted_error','hour_sin','hour_cos','weekday_sin','weekday_cos']


def source_inputs(rows, source):
    values=[]
    for r in rows:
        v=source_value(r,source)
        coverage=float(r[source+'_observed_fraction'])
        if source=='app':coverage=min(coverage,float(r['elder_app_observed_fraction']))
        values.append([float(v) if v!='' else np.nan,coverage])
    return np.array(values,dtype=np.float32)


def detector_features(ends, forecast, observed, arrivals, events, scales):
    """Only completed measurements/events received by end+30min; no feedback input."""
    output=[];eligible=[];weighted=[]
    for end in ends:
        a,b=int(end)-3,int(end);cut=end+.5;x=[];total=0.;available=0.
        for j,source in enumerate(SOURCES):
            ok=np.isfinite(observed[a:b,j]).all() and (arrivals[a:b,j]<=cut).all()
            if ok:
                residual=float(np.mean(forecast[a:b,j]-observed[a:b,j]))/scales[j]
                shortfall=min(8.,max(0.,residual));excess=min(8.,max(0.,-residual))
                total+=WEIGHTS[source]*(shortfall+excess);available+=WEIGHTS[source]
                x.extend([WEIGHTS[source]*shortfall,WEIGHTS[source]*excess,1.])
            else:x.extend([0.,0.,0.])  # Explicit availability flags distinguish missing from no residual.
        for source in ['gate','app']:
            j=SOURCES.index(source);past=slice(max(0,b-24),b)
            covered=np.mean(np.isfinite(observed[past,j]) & (arrivals[past,j]<=cut))>=.9
            own=[e for h in range(max(0,b-24),b) for e in events.get(h,[]) if e['source']==source
                 and e['resident']=='E1' and e['verified'] and e['meaningful'] and e['arrival']<=cut]
            age=min([b-e['time'] for e in own],default=24.)/24
            x.extend([WEIGHTS[source]*age if covered else 0.,float(not covered)])
        score=total/available if available else np.nan
        hour=b%24;day=(b//24+g.ORIGIN.weekday())%7
        x.extend([score if np.isfinite(score) else 0.,np.sin(hour*np.pi/12),np.cos(hour*np.pi/12),
                  np.sin(day*2*np.pi/7),np.cos(day*2*np.pi/7)])
        ok=available>=.7-1e-12
        output.append(x);eligible.append(ok);weighted.append(score if ok else np.nan)
    return np.array(output),np.array(eligible),np.array(weighted)


def review_labels(reviews, ends, target, cutoff):
    by_end={int(r['end_hour_exclusive']):r for r in reviews}
    result=np.full(len(ends),np.nan)
    for i,end in enumerate(ends):
        r=by_end.get(int(end))
        if r and r[target+'_label']!='' and hour_number(r[target+'_available_at'])<=cutoff:
            result[i]=int(r[target+'_label'])
    return result


def confusion(labels, scores, threshold, eligible):
    labels=np.asarray(labels);scores=np.asarray(scores);eligible=np.asarray(eligible)
    known=np.isfinite(labels);covered=known & eligible & np.isfinite(scores)
    positive=scores>threshold
    tp=int(np.sum(covered & (labels==1) & positive));fp=int(np.sum(covered & (labels==0) & positive))
    tn=int(np.sum(covered & (labels==0) & ~positive));fn=int(np.sum(covered & (labels==1) & ~positive))
    total=tp+fp+tn+fn;abstained_positive=int(np.sum(known & ~covered & (labels==1)))
    return dict(TP=tp,FP=fp,TN=tn,FN=fn,accuracy=(tp+tn)/total if total else None,
        precision=tp/(tp+fp) if tp+fp else None,recall=tp/(tp+fn) if tp+fn else None,
        f1=2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.,
        reviewed_intervals=int(known.sum()),unlabelled_intervals=int((~known).sum()),
        abstained_labelled_intervals=int(np.sum(known & ~covered)),abstained_positive_intervals=abstained_positive,
        recall_counting_abstentions_as_misses=tp/(tp+fn+abstained_positive) if tp+fn+abstained_positive else None,
        decision_coverage=float(np.mean(eligible)),labelled_coverage=float(covered.sum()/known.sum()) if known.any() else None)


def threshold_on_validation(labels,scores,eligible):
    valid=np.isfinite(labels) & np.isfinite(scores) & eligible
    if not np.any(valid & (labels==1)):return np.inf
    unique=np.unique(scores[valid]);best=np.inf;key=(-1,-np.inf,-np.inf)
    for threshold in np.r_[np.inf,np.nextafter(unique[0],-np.inf),unique]:
        metric=confusion(labels,scores,threshold,eligible)
        candidate=(metric['f1'],-metric['FP'],float(threshold))
        if candidate>key:key=candidate;best=float(threshold)
    return best


def model_scores(model,x):
    if 'constant' in model:return np.full(len(x),model['constant'])
    classifier=model['classifier']
    if 'columns' in model:
        with threadpool_limits(limits=4):return classifier.predict_proba(x[:,model['columns']])[:,1]
    # Avoid the local BLAS matmul warning while preserving sklearn's binary logistic equation.
    result=expit(np.einsum('ij,j->i',x,classifier.coef_[0])+classifier.intercept_[0])
    if not np.isfinite(result).all():raise ValueError('Non-finite detector output')
    return result


def episode_audit(ends,scores,threshold,episodes,start,end):
    adjusted=decision_episodes(episodes,.5)
    summary,events,_=detection(ends+.5,scores,threshold,adjusted,include_onset=False)
    for row,original in zip(events,episodes):
        if row['delay_hours'] is not None:row['delay_hours']+=row['start_hour']-original['start']
        row['start_hour']=original['start']
    delay=[r['delay_hours'] for r in events if r['detected']]
    summary.update(false_alerts_per_30_days=summary['false_alerts']*30/((end-start)/24),
        median_delay_hours=float(np.median(delay)) if delay else None,
        p90_delay_hours=float(np.percentile(delay,90)) if delay else None)
    summary['flagged_decisions']=summary.pop('flagged_hours')
    summary['false_flagged_decisions']=summary.pop('false_flagged_hours')
    return summary,events


def run(data,out,device='cpu',smoke=False,validation_only=False):
    import torch
    validate(data);fresh_output(out,data)
    dataset_config={r['parameter']:r['value'] for r in read(data/'config.csv')}
    if dataset_config['version']=='illustrative-daytime-v11':
        raise ValueError('Use illustrative_study.py: this profile has a different check-in agreement')
    revised=dataset_config['version']=='multisource-two-stage-v5'
    make_features=detector_features;feature_names=FEATURES
    if revised:
        if __package__:from . import revised_protocol as protocol
        else:import revised_protocol as protocol
        make_features=protocol.detector_features;feature_names=protocol.FEATURES
    test_scored=not (smoke or validation_only)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    cfg=config(smoke=smoke)
    seeds=[11] if smoke else [11,22,33]
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in dict(
        pipeline='four independent LSTMs, then independent binary detectors; no shared cross-source forecast input',
        dataset_version=dataset_config['version'],validation_only=validation_only,
        forecast_history=336,forecast_fit_end=2880,forecast_early_stop_end=3600,detector_fit_end=5256,
        validation_end=7008,test_end=8760,seeds=','.join(map(str,seeds)),ensemble='mean of all forecast seeds, never best test seed',
        forecast_training='app-confirmed usage0 AND emergency0 targets; both labels/targets available by fit cutoff; past histories may contain anomalies',
        residual_scale='source-specific residual std on confirmed-normal internal forecast validation; no test data',
        detector=('HistGradientBoosting max_iter100 learning_rate0.05 max_leaf_nodes7 min_samples_leaf10 l2=5 balanced; no calendar' if revised else 'LogisticRegression C1 liblinear balanced'),
        weights='electricity0.40 water0.30 gate0.15 app0.15; fixed baseline only; classifier can learn different effective contributions',
        labels='independent family usage/emergency confirmations; no unknown-as-normal conversion',
        threshold='maximum validation F1; ties fewer FP then higher threshold; frozen before test forecasts/scoring',
        unit='nonoverlapping3h intervals; decision end+30min; unknown excluded from confusion, abstentions reported',
        emergency_score='classification score, not a calibrated real-world emergency probability',
        smoke=smoke,device=device,numpy=np.__version__,sklearn=sklearn.__version__,torch=torch.__version__).items()])
    (out/'config.csv').chmod(0o444)
    shutil.copy(data/'manifest.csv',out/'dataset_manifest.csv')
    (out/'source').mkdir()
    for name in ['revised_protocol.py','two_stage.py','multisource_dataset.py','train.py','generate.py','evaluation_v2.py',
                 'electricity_dataset.py','evaluation.py','validate.py','paper_alarms.py','verify_two_stage.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    rows,targets,reviews=read(data/'hourly.csv'),read(data/'targets_hourly.csv'),read(data/'app_reviews.csv')
    y=np.array([[float(r[s]) if r[s]!='' else np.nan for s in SOURCES] for r in targets])
    arrival=np.array([[hour_number(r[s+'_available_at']) for s in SOURCES] for r in targets])
    events=defaultdict(list)
    for r in read(data/'events.csv'):
        time=hour_number(r['event_time'])
        events[int(time)].append(dict(source=r['source'],time=time,arrival=hour_number(r['received_at']),
            resident=r['claimed_resident_id'],verified=r['attribution']=='verified',meaningful=r['meaningful']=='1',kind=r['event_type']))
    train_labels=confirmed_hours(reviews,2880);stop_labels=confirmed_hours(reviews,3600)
    normal_train=(train_labels['usage_anomaly']==0)&(train_labels['emergency']==0)
    normal_stop=(stop_labels['usage_anomaly']==0)&(stop_labels['emergency']==0)
    models={};raws={};preprocessors={};forecast=np.full((8760,4),np.nan);scales=np.zeros(4)
    predicted_rows=[];training=[];training_targets=[];forecast_metrics=[]
    def record_prediction(source,seed,times,pred):
        if not np.isfinite(pred).all():raise ValueError('Non-finite source forecast')
        j=SOURCES.index(source)
        predicted_rows.extend(dict(source=source,seed=seed,target_hour=int(h),issued_time=g.timestamp(h*4),
            forecast=float(v),observed=g.number(y[h,j])) for h,v in zip(times,pred))
        for part,a,b in [('validation',5256,7008),('test',7008,8760)]:
            use=(times>=a)&(times<b)&np.isfinite(y[times,j])
            if use.any():
                error=pred[use]-y[times[use],j]
                forecast_metrics.append(dict(source=source,seed=seed,partition=part,targets=int(use.sum()),
                    mae=float(np.abs(error).mean()),rmse=float(np.sqrt(np.mean(error**2))),
                    unit='kWh' if source=='electricity' else 'litres' if source=='water' else 'event_count'))
    for j,source in enumerate(SOURCES):
        raw=source_inputs(rows,source);raws[source]=raw
        train=np.arange(336,2880);train=train[normal_train[train]&np.isfinite(y[train,j])&(arrival[train,j]<=2880)]
        stop=np.arange(2880,3600);stop=stop[normal_stop[stop]&np.isfinite(y[stop,j])&(arrival[stop,j]<=3600)]
        if len(train)<50 or len(stop)<20:raise ValueError(f'Too few app-confirmed normal targets for {source}')
        if smoke:train=train[:128];stop=stop[:64]
        pre=fit_preprocessing(raw,train);pre['feature_names']=[source,'source_availability'];preprocessors[source]=pre
        folder=out/'forecasters'/source;folder.mkdir(parents=True)
        joblib.dump(pre,folder/'preprocessing.joblib')
        prepared=inputs(raw,train,pre);validation=inputs(raw,stop,pre)
        times=np.arange(2880,7008);future=inputs(raw,times,pre);predictions=[];stop_predictions=[]
        for seed in seeds:
            own=folder/str(seed);own.mkdir()
            fitted,summary=fit_model('lstm',seed,prepared,validation,y[train,j],y[stop,j],cfg,own,device)
            models[(source,seed)]=fitted
            pred=predict('lstm',fitted,future,raw,times,pre,device);predictions.append(pred)
            stop_predictions.append(predict('lstm',fitted,validation,raw,stop,pre,device))
            training.append(dict(source=source,seed=seed,training_targets=len(train),early_stop_targets=len(stop),**summary))
            record_prediction(source,seed,times,pred)
        forecast[times,j]=np.mean(predictions,axis=0)
        scales[j]=max(float(np.std(np.mean(stop_predictions,axis=0)-y[stop,j])),{'electricity':.02,'water':1.,'gate':.1,'app':.1}[source])
        training_targets.extend(dict(source=source,role=role,hour=int(h)) for role,hh in [('fit',train),('early_stop',stop)] for h in hh)
        naive=raw[times-168,0];naive=np.where(np.isfinite(naive),naive,pre['median'][0])
        record_prediction(source,'seasonal_naive',times,naive)
        record_prediction(source,'ensemble',times,forecast[times,j])
        print(f'Completed {source} LSTMs; detector residual scale={scales[j]:.4f}',flush=True)
    g.write_csv(out/'forecast_training.csv',training)
    g.write_csv(out/'forecast_training_targets.csv',training_targets)
    g.write_csv(out/'expected_weights.csv',[dict(source=s,expected_weight=WEIGHTS[s],residual_scale=scales[j],
        interpretation='heuristic prior and weighted baseline; learned classifier coefficients may change influence') for j,s in enumerate(SOURCES)])
    fit_ends=np.arange(3603,5257,3);val_ends=np.arange(5259,7009,3)
    fx,fe,fw=make_features(fit_ends,forecast,y,arrival,events,scales)
    vx,ve,vw=make_features(val_ends,forecast,y,arrival,events,scales)
    classifiers={};ablations={};thresholds={};threshold_rows=[];coefficients=[];fit_records=[]
    for target in LABELS:
        labels=review_labels(reviews,fit_ends,target,5256);use=np.isfinite(labels)&fe
        if not use.any():raise ValueError(f'No confirmed eligible detector labels for {target}')
        if revised and len(np.unique(labels[use]))==2:
            for system,columns in [('learned_detector',list(range(len(feature_names)))),('without_checkin_context',list(range(17)))]:
                classifier=HistGradientBoostingClassifier(max_iter=100,learning_rate=.05,max_leaf_nodes=7,
                    min_samples_leaf=10,l2_regularization=5.,class_weight='balanced',early_stopping=False,random_state=44)
                with threadpool_limits(limits=4):classifier.fit(fx[use][:,columns],labels[use])
                result=dict(classifier=classifier,columns=columns)
                if system=='learned_detector':fitted=result
                else:
                    ablations[target]=result
                    joblib.dump(dict(**result,feature_names=feature_names,scales=scales),out/(target+'_without_checkin.joblib'),compress=3)
        elif len(np.unique(labels[use]))==2:
            classifier=LogisticRegression(C=1.,class_weight='balanced',solver='liblinear',max_iter=2000,random_state=44)
            classifier.fit(fx[use],labels[use]);fitted=dict(classifier=classifier)
            coefficients.extend(dict(target=target,feature=name,coefficient=float(value))
                                for name,value in zip(['intercept']+FEATURES,np.r_[classifier.intercept_,classifier.coef_[0]]))
        else:fitted=dict(constant=float(labels[use].mean()))
        classifiers[target]=fitted
        joblib.dump(dict(**fitted,feature_names=feature_names,scales=scales),out/(target+'_detector.joblib'),compress=3)
        fit_records.extend(dict(target=target,end_hour=int(h),label=int(label)) for h,label in zip(fit_ends[use],labels[use]))
        val_labels=review_labels(reviews,val_ends,target,7008)
        systems=[('learned_detector',model_scores(fitted,vx)),('weighted_baseline',vw)]
        if target in ablations:systems.append(('without_checkin_context',model_scores(ablations[target],vx)))
        for system,score in systems:
            threshold=threshold_on_validation(val_labels,score,ve);thresholds[(target,system)]=threshold
            threshold_rows.append(dict(target=target,system=system,threshold=threshold,
                fit_positive_intervals=int(np.sum(labels[use]==1)),fit_negative_intervals=int(np.sum(labels[use]==0)),
                classifier_status='learned' if 'classifier' in fitted else 'single_class_constant',
                calibration='validation only; fixed before test'))
    g.write_csv(out/'thresholds.csv',threshold_rows);(out/'thresholds.csv').chmod(0o444)
    g.write_csv(out/'detector_training_labels.csv',fit_records)
    g.write_csv(out/'feature_coefficients.csv',coefficients,fields=['target','feature','coefficient'])
    print('Detector thresholds frozen. Starting final test replay.' if test_scored else 'Validation only; test remains unscored.',flush=True)
    if test_scored:
        times=np.arange(7008,8760)
        for j,source in enumerate(SOURCES):
            raw,pre=raws[source],preprocessors[source];prepared=inputs(raw,times,pre);preds=[]
            for seed in seeds:
                pred=predict('lstm',models[(source,seed)],prepared,raw,times,pre,device);preds.append(pred)
                record_prediction(source,seed,times,pred)
            forecast[times,j]=np.mean(preds,axis=0);record_prediction(source,'ensemble',times,forecast[times,j])
            naive=raw[times-168,0];naive=np.where(np.isfinite(naive),naive,pre['median'][0]);record_prediction(source,'seasonal_naive',times,naive)
    confusion_rows=[];decisions=[];feature_rows=[];oracle_metrics=[];oracle_events=[]
    episodes={
        'usage_anomaly':[dict(id=r['scenario_id'],start=int(r['start_slot'])/4,end=int(r['end_slot'])/4,kind=r['kind'])
                         for r in read(data/'truth/usage_scenarios.csv') if r['unexpected_usage']=='1'],
        'emergency':[dict(id=r['episode_id'],start=int(r['start_slot'])/4,end=int(r['end_slot'])/4,kind=r['kind'])
                     for r in read(data/'truth/assistance_episodes.csv')]}
    for part,a,b,cutoff in [('validation',5256,7008,7008)]+([('test',7008,8760,8832)] if test_scored else []):
        ends=np.arange(a+3,b+1,3);x,eligible,weighted=make_features(ends,forecast,y,arrival,events,scales)
        feature_rows.extend(dict(partition=part,end_hour=int(h),decision_time=g.timestamp((h+.5)*4),eligible=int(ok),
            **dict(zip(feature_names,map(float,row)))) for h,row,ok in zip(ends,x,eligible))
        for target in LABELS:
            labels=review_labels(reviews,ends,target,cutoff)
            systems=[('learned_detector',model_scores(classifiers[target],x)),('weighted_baseline',weighted)]
            if target in ablations:systems.append(('without_checkin_context',model_scores(ablations[target],x)))
            for system,scores in systems:
                threshold=thresholds[(target,system)]
                metric=confusion(labels,scores,threshold,eligible)
                confusion_rows.append(dict(partition=part,target=target,system=system,**metric))
                decisions.extend(dict(partition=part,target=target,system=system,end_hour=int(h),
                    decision_time=g.timestamp((h+.5)*4),score=float(s) if np.isfinite(s) else '',eligible=int(ok),
                    alarm=int(ok and np.isfinite(s) and s>threshold),app_label=int(label) if np.isfinite(label) else '')
                    for h,s,ok,label in zip(ends,scores,eligible,labels))
                # Oracle is used only after all learned thresholds are frozen, as a separate audit.
                included=[e for e in episodes[target] if e['start']>=a and e['end']<=b]
                summary,event=episode_audit(ends,np.where(eligible,scores,np.nan),threshold,included,a,b)
                oracle_metrics.append(dict(partition=part,system=system,target=target,**summary))
                oracle_events.extend(dict(partition=part,system=system,target=target,kind=e['kind'],**r) for r,e in zip(event,included))
    for name,records in [('forecast_metrics',forecast_metrics),('forecasts',predicted_rows),('confusion_matrices',confusion_rows),
        ('decisions',decisions),('detector_features',feature_rows),('oracle_episode_metrics',oracle_metrics),('oracle_episode_results',oracle_events)]:
        g.write_csv(out/(name+'.csv'),records)
    strata=defaultdict(list)
    for r in oracle_events:strata[(r['partition'],r['system'],r['target'],r['kind'])].append(r)
    g.write_csv(out/'oracle_scenario_metrics.csv',[dict(partition=p,system=s,target=t,kind=k,episodes=len(rows),
        detected=sum(r['detected'] for r in rows),recall=np.mean([r['detected'] for r in rows]),
        observable=sum(r['observable'] for r in rows)) for (p,s,t,k),rows in strata.items()])
    report(out,confusion_rows,forecast_metrics,threshold_rows,not test_scored,revised)
    g.write_csv(out/'completed.csv',[dict(smoke=smoke,lstm_fits=len(models),detector_outputs=len(classifiers),test_scored=int(test_scored))])
    manifest(out)
    print(f'Completed {out}',flush=True)


def report(out,confusions,forecasts,thresholds,smoke,revised=False):
    part='validation' if smoke else 'test'
    lines=['# Independent forecasts and two detection targets', '',
        'Validation only; see config.csv for reduced-smoke versus full fits.' if smoke else 'Final test replay. Thresholds were selected on validation and frozen before test prediction.', '',
        'Part 1 uses four independent LSTMs. Each sees only its own source values/availability and calendar; each predicts its own next-hour value. All three seeds are averaged for the second stage, with each seed also reported separately.', '',
        '| Source | Ensemble MAE | Weekly-baseline MAE | Unit |', '|---|---:|---:|---|']
    for source in SOURCES:
        ensemble=next(r for r in forecasts if r['source']==source and r['seed']=='ensemble' and r['partition']==part)
        naive=next(r for r in forecasts if r['source']==source and r['seed']=='seasonal_naive' and r['partition']==part)
        lines.append(f"| {source} | {ensemble['mae']:.4f} | {naive['mae']:.4f} | {ensemble['unit']} |")
    lines+=['', 'Part 2 combines normalized forecast deviations with source availability, resident-linked gate/app recency and calendar. Separate logistic classifiers learn unusual-usage and emergency labels from delayed family confirmations. Detector training predictions occur after all forecaster fitting/early stopping; no in-sample residuals train the detector.', '',
        '| Target | System | TP | FP | TN | FN | Unlabelled | Labelled abstentions |', '|---|---|---:|---:|---:|---:|---:|---:|']
    for r in confusions:
        if r['partition']==part:
            lines.append(f"| {r['target']} | {r['system']} | {r['TP']} | {r['FP']} | {r['TN']} | {r['FN']} | {r['unlabelled_intervals']} | {r['abstained_labelled_intervals']} |")
    lines+=['', 'TP/FP/TN/FN use one nonoverlapping three-hour reviewed interval, not individual samples or alert episodes. Unknown/unconfirmed intervals are excluded, not counted as TN. Abstentions are outside the four cells and separately reported; confusion_matrices.csv also reports recall counting abstained positives as misses.', '',
        'The initial weights are electricity40%, water30%, gate15%, app15%. They are heuristic priors for the fixed weighted baseline, applied after source-specific residual scaling. The learned detectors can change the effective influence; feature_coefficients.csv exposes logistic coefficients where applicable. Neither the prior percentages nor balanced-class classifier outputs are calibrated emergency probabilities.', '',
        'Ordinary verified app activity and agreed self-check-ins are features. Family feedback responses, their timing, review-selection reasons and labels are never features. A usage anomaly is not automatically an emergency; the two family questions and classifiers are independent. Missing sources never create a zero reading or a confirmation.', '',
        'Thresholds maximise validation F1, with fewer FP then higher threshold breaking ties. This does not impose a one-alert-per-month operating budget. Reviews are selectively collected after deviations or family reports as well as random audits, so these confusion matrices do not estimate population-wide accuracy. Few confirmed positive episodes and correlated intervals limit the evidence.', '',
        'oracle_episode_metrics.csv separately audits all in-boundary simulated episodes, including unreviewed and outage-related misses, false alerts per30days, delays and duplicates. Oracle labels are excluded from fitting, scaling and threshold selection. All data, family reports and emergencies are synthetic; the assistance label is not a clinical diagnosis or proof of deployable safety.', '',
        'All original datasets/runs are preserved. See expected_weights.csv, source_contract.csv in the dataset, per-seed forecast_metrics.csv, threshold records and per-decision CSVs for review.', '']
    if revised:
        lines=[line.replace('Separate logistic classifiers','Separate gradient boosting classifiers').replace('and calendar. Separate','and check-in deadlines. Separate').replace('feature_coefficients.csv exposes their coefficients','the saved classifiers expose the fitted trees').replace('balanced-class classifier outputs','balanced-class classifier outputs') for line in lines]
        lines+=['V5 changes: more confirmed training cases; adjudicated family timelines instead of arbitrary high-confidence flips; known09/14/20 check-in deadlines with1h grace; no raw detector calendar inputs. The no-check-in ablation uses the identical data, labels, forecasters and boosting settings. Independent missing checks, forgotten-phone days, night/brief emergencies, family masking and outages remain.', '',
            'V4 and V5 use different simulated years and collection assumptions: their metrics are descriptive, not a controlled estimate of algorithm improvement. V5 events are deliberately enriched (68 usage events and44 assistance episodes/year); precision must not be extrapolated to real emergency prevalence. Tree splits are invariant to positive feature scaling, so40/30/15/15 applies to the fixed baseline and is not enforced learned importance. oracle_scenario_metrics.csv shows brief/night versus prolonged assistance and each utility mechanism.', '']
    (out/'report.md').write_text('\n'.join(lines))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=Path('ml/household/multisource_data_v4'))
    parser.add_argument('--out',type=Path,default=Path('ml/household/runs/two-stage-v4'))
    parser.add_argument('--device',choices=['cpu','mps'],default='cpu')
    parser.add_argument('--smoke',action='store_true')
    parser.add_argument('--validation-only',action='store_true')
    args=parser.parse_args();run(args.data,args.out,args.device,args.smoke,args.validation_only)
