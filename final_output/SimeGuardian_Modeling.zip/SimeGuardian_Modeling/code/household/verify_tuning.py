"""Independent checks of tuned forecast lineage, calibration and evaluation counts."""
import argparse
import csv
import hashlib
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g,precision_study as old
    from .tuned_study import FEATURES,temporal_score
    from .forecast_finetune import DEV_SEEDS
    from .two_stage import source_inputs
    from .multisource_dataset import SOURCES,LABELS
    from .train import hour_number
    from .validate import read
    from .evaluation_v2 import verify
else:
    import generate as g
    import precision_study as old
    from tuned_study import FEATURES,temporal_score
    from forecast_finetune import DEV_SEEDS
    from two_stage import source_inputs
    from multisource_dataset import SOURCES,LABELS
    from train import hour_number
    from validate import read
    from evaluation_v2 import verify


def run(data,forecasters,base,prior,out):
    checks=[]
    def check(name,ok,rows=''):
        if not ok:raise AssertionError(name)
        checks.append(dict(check=name,passed=1,rows=rows))
    for root in [data,forecasters,base,prior,out,Path('ml/household/runs/tuned-v7'),Path('ml/household/runs/precision-v6')]:verify(root)
    cfg={r['parameter']:r['value'] for r in read(out/'config.csv')}
    assert hashlib.sha256((forecasters/'manifest.csv').read_bytes()).hexdigest()==cfg['forecaster_manifest']
    plan=read(out/'plan.csv');by_seed={int(p['seed']):p for p in plan};roles=defaultdict(set)
    assert len(plan)==len(by_seed)==15
    for p in plan:
        seed=int(p['seed']);roles[p['role']].add(seed);root=Path(p['path']);verify(root)
        assert hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest()==p['manifest_sha256']
        assert {r['household_id'] for r in read(root/'hourly.csv')}=={'HH001'}
    assert roles['test']=={20261041,20261042,20261043}
    assert not roles['development']&roles['test'] and not roles['development']&roles['calibration'] and not roles['test']&roles['calibration']
    override=read(out/'gate_override.csv')[0];gate=Path(override['path']);verify(gate)
    assert hashlib.sha256((gate/'manifest.csv').read_bytes()).hexdigest()==override['manifest_sha256']
    check('frozen data, forecasters, gate override and earlier results unchanged',True,len(plan))
    check('previously reviewed development and fresh final test seeds are disjoint',True,len(plan))
    all_reviews={};all_targets={}
    for seed,p in by_seed.items():
        root=Path(p['path']);all_targets[seed]=read(root/'targets_hourly.csv')
        all_reviews[seed]={int(r['end_hour_exclusive']):r for r in read(root/'app_reviews.csv')}
    training=read(forecasters/'training_targets.csv');pre={s:joblib.load(forecasters/(s+'_preprocessing.joblib')) for s in SOURCES}
    for r in training:
        seed=int(r['data_seed']);h=int(r['hour']);cut=2880 if r['role']=='fit' else 3600
        assert seed in DEV_SEEDS and (336<=h<2880 if r['role']=='fit' else 2880<=h<3600)
        review=all_reviews[seed][(h//3+1)*3]
        for label in LABELS:assert review[label+'_label']=='0' and hour_number(review[label+'_available_at'])<=cut
        assert all_targets[seed][h][r['source']]!='' and hour_number(all_targets[seed][h][r['source']+'_available_at'])<=cut
    for source in SOURCES:
        used=[]
        assert pre[source]['feature_names']==[source,'source_availability'] and pre[source]['history_hours']==336
        for seed in DEV_SEEDS:
            raw=source_inputs(read(Path(by_seed[seed]['path'])/'hourly.csv'),source)
            times=np.array([int(r['hour']) for r in training if r['source']==source and int(r['data_seed'])==seed and r['role']=='fit'])
            indices=np.unique((times[:,None]-336+np.arange(336)).ravel());used.append(raw[indices])
        used=np.concatenate(used);median=np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in used.T],np.float32)
        scale=np.std(np.where(np.isfinite(used),used,median),axis=0);scale[scale<1e-6]=1.
        np.testing.assert_array_equal(median,pre[source]['median']);np.testing.assert_allclose(scale,pre[source]['scale'],rtol=1e-6)
    check('four separate source-only preprocessors fit eligible training histories; normal label timing',True,len(training))
    mixing={r['source']:float(r['fine_weight']) for r in read(out/'forecast_mixing.csv')}
    grid=read(out/'forecast_blend_candidates.csv')
    for s,alpha in mixing.items():
        candidates=[r for r in grid if r['source']==s and r['eligible']=='1']
        selected=min(candidates,key=lambda r:(float(r['mae']),float(r['rmse'])))
        assert float(selected['fine_weight'])==alpha
        assert float(selected['mae'])<=float(selected['original_mae'])+1e-12
        assert float(selected['rmse'])<=float(selected['original_rmse'])+1e-12
    check('source blend selection reduces both validation errors without test input',True,4)
    old_pre={s:joblib.load(base/'forecasters'/s/'preprocessing.joblib') for s in SOURCES}
    old_scales=np.array([float(next(r for r in read(base/'expected_weights.csv') if r['source']==s)['residual_scale']) for s in SOURCES])
    replay={};feature_count=0
    for seed,p in by_seed.items():
        role=p['role'];a=3600 if role=='development' else 7008;b=8760;folder=out/'replays'/str(seed)
        names=['tuned_seed11','tuned_seed22','tuned_seed33','tuned','original']
        predictions={name:np.full((8760,4),np.nan) for name in names}
        with (folder/'forecasts.csv').open() as stream:
            for r in csv.DictReader(stream):
                h=int(r['hour']);j=SOURCES.index(r['source']);name=r['model'];value=float(r['prediction'])
                assert r['role']==role and int(r['seed'])==seed and a-24<=h<b and np.isfinite(value)
                assert np.isnan(predictions[name][h,j]);predictions[name][h,j]=value
        for s in SOURCES:
            j=SOURCES.index(s);members=np.array([predictions['tuned_seed'+str(k)][a-24:b,j] for k in [11,22,33]])
            assert np.isfinite(members).all()
            expected=mixing[s]*members.mean(0)+(1-mixing[s])*predictions['original'][a-24:b,j]
            np.testing.assert_allclose(predictions['tuned'][a-24:b,j],expected,rtol=0,atol=1e-12)
        y=np.array([[float(r[s]) if r[s] else np.nan for s in SOURCES] for r in all_targets[seed]])
        arrival=np.array([[hour_number(r[s+'_available_at']) for s in SOURCES] for r in all_targets[seed]])
        hours=read(Path(p['path'])/'hourly.csv')
        for m in read(folder/'forecast_metrics.csv'):
            s=m['source'];j=SOURCES.index(s);times=np.arange(a,b);known=np.isfinite(y[times,j])
            if m['model'] in predictions:values=predictions[m['model']][times,j]
            elif m['model']=='zero':values=np.zeros(len(times))
            else:
                raw=source_inputs(hours,s);lag=raw[times-168,0];values=np.where(np.isfinite(lag),lag,old_pre[s]['median'][0])
            error=values[known]-y[times[known],j]
            assert int(m['targets'])==int(known.sum())
            assert abs(float(m['mae'])-np.abs(error).mean())<1e-10
            assert abs(float(m['rmse'])-np.sqrt(np.mean(error**2)))<1e-10
            assert abs(float(m['actual_sum'])-y[times[known],j].sum())<1e-8
        rows=read(folder/'features.csv');ends=np.array([int(r['end_hour']) for r in rows]);eligible=np.array([r['eligible']=='1' for r in rows])
        assert np.array_equal(ends,np.arange(a+3,b+1))
        x=np.array([[float(r[k]) for k in FEATURES] for r in rows]);assert np.isfinite(x).all();feature_count+=len(rows)
        for r in rows:
            h=int(r['end_hour']);available=0.
            for j,(s,w) in enumerate(zip(SOURCES,[.4,.3,.15,.15])):
                known=np.isfinite(y[h-3:h,j]).all() and (arrival[h-3:h,j]<=h+.5).all()
                assert float(r[s+'_available'])==known
                if known:
                    available+=w
                    assert abs(float(r[s+'_observed_mean'])-y[h-3:h,j].mean())<1e-10
            assert int(r['eligible'])==(available>=.7-1e-12)
        # The baseline is scored at its original cadence, using its own saved forecasts/scales.
        original_x=None
        if role!='development':
            events=defaultdict(list)
            for r in read(Path(p['path'])/'events.csv'):
                t=hour_number(r['event_time']);events[int(t)].append(dict(source=r['source'],time=t,arrival=hour_number(r['received_at']),
                    resident=r['claimed_resident_id'],verified=r['attribution']=='verified',meaningful=r['meaningful']=='1',kind=r['event_type']))
            original_x,_,_=old.features(ends[ends%3==0],predictions['original'],y,arrival,events,old_scales)
        replay[seed]=dict(x=x,ends=ends,eligible=eligible,original_x=original_x,role=role)
    check('every forecast includes all three training seeds and the frozen source blend',True,len(plan))
    check('all new/original/weekly/zero forecast errors reproduce on matching targets',True,len(plan)*16)
    check('hourly causal source availability and completed-hour means match measurements',True,feature_count)
    expected={};actual={}
    for seed in roles['development']:
        r=replay[seed]
        for h,ok in zip(r['ends'],r['eligible']):
            review=all_reviews[seed].get(int(h))
            if not review or not ok:continue
            for target in LABELS:
                if review[target+'_label']!='' and hour_number(review[target+'_available_at'])<=8760:expected[(target,seed,int(h))]=review[target+'_label']
    for r in read(out/'training_labels.csv'):
        key=(r['target'],int(r['seed']),int(r['end_hour']));assert key not in actual;actual[key]=r['label']
    assert actual==expected
    check('all and only eligible development family labels supervise detectors; test labels excluded',True,len(actual))
    models={t:joblib.load(out/(t+'_detector.joblib')) for t in LABELS};original={t:joblib.load(prior/(t+'_detector.joblib')) for t in LABELS}
    selections={r['target']:r for r in read(out/'selection.csv')};all_decisions=read(out/'decisions.csv');groups=defaultdict(list)
    for seed,r in replay.items():
        if r['role']=='development':continue
        for target,m in models.items():
            assert m['features']==FEATURES and m['threshold']==float(selections[target]['threshold'])
            with threadpool_limits(limits=4):raw=m['classifier'].predict_proba(r['x'])[:,1]
            new=temporal_score(raw,r['eligible'],m['score_mode'])
            with threadpool_limits(limits=4):old_score=original[target]['classifier'].predict_proba(r['original_x'])[:,1]
            for system,score,ends,eligible,threshold in [('tuned',new,r['ends'],r['eligible'],m['threshold']),
                ('v6_original',old_score,r['ends'][r['ends']%3==0],r['eligible'][r['ends']%3==0],original[target]['threshold'])]:
                own=[v for v in all_decisions if int(v['seed'])==seed and v['target']==target and v['system']==system]
                assert len(own)==len(score)
                for row,prediction,h,ok in zip(own,score,ends,eligible):
                    assert int(row['end_hour'])==h and abs(float(row['score'])-prediction)<1e-12
                    assert int(row['eligible'])==ok and int(row['alarm'])==(ok and prediction>threshold)
                    review=all_reviews[seed].get(int(h))
                    label=review[target+'_label'] if review and hour_number(review[target+'_available_at'])<=8832 else ''
                    assert row['app_label']==label
                    groups[(r['role'],seed,target,system)].append(row)
    check('saved new/original models reproduce every hourly or three-hourly decision',True,len(all_decisions))
    for m in read(out/'confusion_matrices.csv'):
        seeds=roles[m['role']] if m['seed']=='pooled' else [int(m['seed'])]
        rr=[r for seed in seeds for r in groups[(m['role'],seed,m['target'],m['system'])] if int(r['end_hour'])%3==0]
        counts=dict(TP=0,FP=0,TN=0,FN=0);unknown=abstained=positive_abstained=0
        for r in rr:
            if r['app_label']=='':unknown+=1;continue
            if r['eligible']=='0':abstained+=1;positive_abstained+=r['app_label']=='1';continue
            key=('T' if r['app_label']==r['alarm'] else 'F')+('P' if r['alarm']=='1' else 'N');counts[key]+=1
        assert all(int(m[k])==v for k,v in counts.items())
        assert int(m['unlabelled_intervals'])==unknown and int(m['abstained_labelled_intervals'])==abstained
        assert int(m['abstained_positive_intervals'])==positive_abstained
    check('independent paired confusion counts, unknown labels and positive abstentions',True,32)
    for target,m in models.items():
        rr=[r for seed in roles['calibration'] for r in groups[('calibration',seed,target,'tuned')] if r['app_label']!='' and r['eligible']=='1']
        values=sorted(set(float(r['score']) for r in rr));best=(-1,-np.inf,-np.inf);pick=np.inf
        for t in [np.nextafter(values[0],-np.inf)]+values:
            tp=sum(r['app_label']=='1' and float(r['score'])>t for r in rr);fp=sum(r['app_label']=='0' and float(r['score'])>t for r in rr)
            if tp+fp<20 or tp/(tp+fp)<float(cfg['calibration_precision']):continue
            key=(tp,-fp,t)
            if key>best:best=key;pick=t
        assert m['threshold']==pick
        candidates=[r for r in read(out/'candidate_metrics.csv') if r['target']==target and r['qualified']=='1']
        choice=max(candidates,key=lambda r:(int(r['TP']),-int(r['FP'])))
        assert choice['candidate']==m['candidate'] and choice['score_mode']==m['score_mode']
    check('model, temporal rule and threshold selection reproduce from calibration only',True,2)
    events=read(out/'oracle_episode_results.csv')
    for m in read(out/'oracle_episode_metrics.csv'):
        key=(m['role'],int(m['seed']),m['target'],m['system']);rr=groups[key]
        es=[e for e in events if (e['role'],int(e['seed']),e['target'],e['system'])==key]
        flags=[r['alarm']=='1' for r in rr];alert_groups=[]
        for i,flag in enumerate(flags):
            if flag:
                if i==0 or not flags[i-1]:alert_groups.append([])
                alert_groups[-1].append(i)
        matched=set();detected=0;delay=[];duplicates=0;during_any=set()
        for e in es:
            a,b=float(e['start_hour']),float(e['end_hour'])
            during={i for i,r in enumerate(rr) if int(r['end_hour'])>np.floor(a) and a<int(r['end_hour'])+.5<b};during_any|=during
            hits=[j for j,g in enumerate(alert_groups) if during.intersection(g)];matched.update(hits);detected+=bool(hits);duplicates+=max(0,len(hits)-1)
            assert int(e['detected'])==bool(hits) and int(e['observable'])==any(rr[i]['eligible']=='1' for i in during)
            if hits:
                d=min(int(rr[i]['end_hour'])+.5-a for i in during if flags[i]);delay.append(d);assert abs(d-float(e['delay_hours']))<1e-10
        assert int(m['detected_episodes'])==detected and int(m['alert_episodes'])==len(alert_groups)
        assert int(m['false_alerts'])==len(alert_groups)-len(matched) and int(m['duplicate_alerts'])==duplicates
        assert abs(float(m['false_alerts_per_30_days'])-(len(alert_groups)-len(matched))*30/73)<1e-10
        assert int(m['false_flagged_decisions'])==sum(flag and i not in during_any for i,flag in enumerate(flags))
        if delay:assert float(m['median_delay_hours'])==np.median(delay) and float(m['p90_delay_hours'])==np.percentile(delay,90)
    check('independent event matches, hourly/three-hour cadence, delays, duplicates and false-alert budgets',True,24)
    check('CSV datasets/results remain free of JSON and NPZ files',not any(p.suffix in ['.json','.jsonl','.npz'] for root in [data,out] for p in root.rglob('*')))
    g.write_csv(out.with_name(out.name+'-verification.csv'),checks)
    print('\n'.join(r['check']+': PASS' for r in checks))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path('ml/household/tuning_data_v8'))
    p.add_argument('--forecasters',type=Path,default=Path('ml/household/runs/forecast-v7'))
    p.add_argument('--base',type=Path,default=Path('ml/household/runs/two-stage-v5'))
    p.add_argument('--prior',type=Path,default=Path('ml/household/runs/precision-v6'))
    p.add_argument('--run',type=Path,default=Path('ml/household/runs/tuned-v8'))
    a=p.parse_args();run(a.data,a.forecasters,a.base,a.prior,a.run)
