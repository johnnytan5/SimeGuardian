"""One-family electricity study: predictable physical routines and app-reviewed labels.

Family confirmations are labels only. The simulator oracle is audit-only.
The test partition is generated and frozen, but the benchmark scores validation only.
"""
import argparse
import hashlib
import platform
import shutil
from pathlib import Path

import joblib
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.metrics import average_precision_score, roc_auc_score

if __package__:
    from . import generate as g
    from .validate import read
    from .evaluation_v2 import manifest, verify, fresh_output
    from .train import hour_number
else:
    import generate as g
    from validate import read
    from evaluation_v2 import manifest, verify, fresh_output
    from train import hour_number

SEED = 20261026
KINDS = ['appliance_left_on', 'unusual_night_load', 'missed_usual_meal',
         'excess_cooling', 'partial_circuit_loss', 'unplanned_power_cut']
INPUTS = ['electricity_kwh', 'electricity_partial_kwh', 'electricity_observed_fraction',
          'hour_of_day', 'day_of_week']
STATUSES = {'normal_or_expected': 0, 'confirmed_unusual_usage': 1}


def routines(seed):
    states, visitor, _ = g.routine(seed)
    states[states == 'unable'] = 'leisure'
    states[np.isin(states, ['eating', 'cooking'])] = 'leisure'
    rng = np.random.default_rng(seed+10)
    for day in range(365):
        a = day*96
        # Small daily schedule variation; no identical copied weeks.
        jitter = int(rng.choice([-1, 0, 1], p=[.2, .6, .2]))
        for meal in [28, 52, 76]:
            for person in range(5):
                t = a+meal+jitter+(6 if person == 0 and meal == 28 else 0)
                ids = np.arange(t, t+3)
                available = ~np.isin(states[person, ids], ['away', 'asleep'])
                states[person, ids[available]] = 'eating'
            t = a+meal+jitter-2
            for person in [1, 0, 2]:
                if not np.isin(states[person, t:t+3], ['away', 'asleep']).any():
                    states[person, t:t+3] = 'cooking'
                    break
    return states, visitor


def scenario_plan(seed):
    """Choose real-world mechanisms and periods before generating measurements."""
    rng = np.random.default_rng(seed+11)
    rows = []
    for part, first, last, count in [('train', 20, 215, 24), ('validation', 224, 288, 6), ('test', 298, 361, 6)]:
        edges = np.linspace(first, last, count+1, dtype=int)
        for i in range(count):
            day = int(rng.integers(edges[i], max(edges[i]+1, edges[i+1]-1)))
            kind = KINDS[i % len(KINDS)]
            hour = {'appliance_left_on': 10, 'unusual_night_load': 0, 'missed_usual_meal': 18,
                    'excess_cooling': 12, 'partial_circuit_loss': 17, 'unplanned_power_cut': 14}[kind]
            duration = {'appliance_left_on': (16, 33), 'unusual_night_load': (16, 25),
                        'missed_usual_meal': (12, 17), 'excess_cooling': (20, 33),
                        'partial_circuit_loss': (16, 25), 'unplanned_power_cut': (8, 17)}[kind]
            start = day*96+hour*4+int(rng.integers(0, 3))
            end = min((day+1)*96, start+int(rng.integers(*duration)))
            rows.append(dict(scenario_id=f'electric-{len(rows)+1:03}', kind=kind, partition=part,
                start_slot=start, end_slot=end, unexpected_usage=1, strength=float(rng.uniform(.8, 1.2)),
                label_basis='planned appliance/routine event, independent of model residual'))
    # Expected demand changes overlap anomalous load patterns; they are hard negatives.
    for day, kind in [(d, k) for d in [35, 71, 115, 149, 187, 208, 239, 263, 309, 341]
                      for k in ['expected_guests']]:
        if any(r['start_slot']//96 == day for r in rows): day += 2
        rows.append(dict(scenario_id=f'expected-{day}', kind=kind, partition=g.partition(day*96),
            start_slot=day*96+18*4, end_slot=day*96+23*4, unexpected_usage=0, strength=1.,
            label_basis='family planned activity; not an unexpected usage anomaly'))
    for day in [55, 135, 201, 251, 326]:
        if any(r['start_slot']//96 == day for r in rows): day += 2
        rows.append(dict(scenario_id=f'expected-{day}', kind='planned_meal_out', partition=g.partition(day*96),
            start_slot=day*96+18*4, end_slot=day*96+22*4, unexpected_usage=0, strength=1.,
            label_basis='family planned absence; not an unexpected usage anomaly'))
    return sorted(rows, key=lambda r: r['start_slot'])


def physical_use(states, visitor, plans, seed):
    rng = np.random.default_rng(seed+12)
    hour = np.arange(g.SLOTS) % 96/4
    home = (states != 'away').sum(axis=0)
    active = (~np.isin(states, ['away', 'asleep', 'nap', 'quiet'])).sum(axis=0)
    weather = np.zeros(365)
    for day in range(1, 365): weather[day] = .88*weather[day-1]+rng.normal(0, .035)
    daily = np.repeat(np.clip(1+weather, .8, 1.2), 96)
    # Persistent duty cycles replace independent high-power coin flips every quarter.
    components = dict(
        standby=np.full(g.SLOTS, .018),
        refrigerator=.018+.003*np.sin(np.arange(g.SLOTS)*np.pi/4),
        fans_lights=.007*home+.004*active*(hour >= 18),
        cooling=(.18*((hour >= 22) | (hour < 6))+.04*((hour >= 14) & (hour < 17)))*daily*(home > 0),
        cooking=np.any(states == 'cooking', axis=0)*.22,
        hot_water=(states == 'personal_care').sum(axis=0)*.08,
        entertainment=np.any(np.isin(states, ['leisure', 'eating']), axis=0)*.025,
        laundry=np.zeros(g.SLOTS), visitors=visitor*.035)
    for day in range(365):
        if (day+g.ORIGIN.weekday()) % 7 in [1, 3, 5]:
            a = day*96+40+int(rng.integers(-1, 2))
            if home[a] > 0: components['laundry'][a:a+6] = [.1, .06, .04, .04, .06, .1]
    electricity = sum(components.values())
    oracle = np.zeros(g.SLOTS, int)
    identifiers = np.full(g.SLOTS, '', dtype='<U24')
    for p in plans:
        a, b = p['start_slot'], p['end_slot']; ids = slice(a, b)
        kind, strength = p['kind'], p['strength']
        if kind == 'appliance_left_on': electricity[ids] += .38*strength
        elif kind == 'unusual_night_load': electricity[ids] += .18*strength
        elif kind == 'excess_cooling': electricity[ids] += .13*strength
        elif kind in ['missed_usual_meal', 'planned_meal_out']:
            electricity[ids] -= components['cooking'][ids]+components['entertainment'][ids]*.7
        elif kind == 'partial_circuit_loss':
            electricity[ids] = components['standby'][ids]+.2*(electricity[ids]-components['standby'][ids])
        elif kind == 'unplanned_power_cut': electricity[ids] = 0
        elif kind == 'expected_guests': electricity[ids] += .12
        oracle[ids] = p['unexpected_usage']; identifiers[ids] = p['scenario_id']
    components['scenario_change'] = electricity-sum(components.values())
    return electricity, components, oracle, identifiers


def delivery(seed):
    rng = np.random.default_rng(seed+13)
    arrivals, incidents = {}, []
    for source in g.SOURCES:
        a = np.arange(1, g.SLOTS+1, dtype=float)
        delayed = rng.random(g.SLOTS) < (.004 if source == 'electricity' else .01)
        a[delayed] += rng.choice([1, 2, 8], delayed.sum(), p=[.6, .3, .1])
        a[rng.random(g.SLOTS) < .0003] = np.inf
        for _ in range(3 if source == 'electricity' else 6):
            start = int(rng.integers(96, g.SLOTS-96)); end = start+int(rng.integers(4, 25))
            a[start:end] = np.inf
            incidents.append(dict(source=source, start_slot=start, end_slot=end, kind='feed_unavailable'))
        arrivals[source] = a
    arrivals['elder_app'] = np.maximum(arrivals['elder_app'], arrivals['app'])
    return arrivals, incidents


def family_reviews(data, oracle, plans, seed):
    """Simulated delayed family annotations; never use model output as the label."""
    rng = np.random.default_rng(seed+14)
    reviews = []
    # Audits are sampled independently of usage; deviations request extra reviews.
    for end in range(339, 8761, 3):
        start = end-3; issued = end+.5
        recent = [g.hour_row(data, h, issued*4)['electricity_kwh'] for h in range(start, end)]
        past = [g.hour_row(data, h-168, issued*4)['electricity_kwh'] for h in range(start, end)]
        complete = all(v != '' for v in recent+past)
        deviation = complete and abs(sum(recent)-sum(past)) > 1.
        audit = rng.random() < .22
        if not (deviation or audit): continue
        a, b = start*4, end*4
        current = oracle[a:b]
        responding = rng.random() < .9
        confidence = 'high' if rng.random() < .94 else 'low'
        status, cstart, cend, note = 'unable_to_verify', start, end, 'No direct observation available'
        if responding and (not current.any() or current.all()):
            positive = bool(current.all())
            # Reporting errors remain in the app labels; oracle permits a separate audit.
            if rng.random() < .015: positive = not positive
            status = 'confirmed_unusual_usage' if positive else 'normal_or_expected'
            note = 'Family checked appliance use / household plans for the requested period'
        elif responding:
            status = 'uncertain_mixed_period'
            note = 'Family cannot reliably assign one label to the whole interval'
        if not responding: confidence = ''; status = 'no_response'
        delay = float(rng.choice([.5, 2, 8, 24, 48], p=[.3, .3, .2, .15, .05]))
        submitted = issued+delay if responding else np.inf
        # A live application would preserve edits as new revisions, not overwrite reports.
        reviews.append(dict(review_id=f'review-{len(reviews)+1:04}', household_id='HH001',
            target='household_electricity_usage', subject_resident_id='',
            reviewer_resident_id=str(rng.choice(['E1', 'A1', 'A2'])),
            request_reason='random_audit' if audit else 'usage_deviation_review',
            period_start=g.timestamp(a), period_end_exclusive=g.timestamp(b),
            requested_at=g.timestamp(issued*4), submitted_at=g.timestamp(submitted*4),
            confirmed_start=g.timestamp(cstart*4) if status in STATUSES else '',
            confirmed_end_exclusive=g.timestamp(cend*4) if status in STATUSES else '',
            status=status, confidence=confidence,
            evidence='direct_observation_or_known_household_plan' if status in STATUSES else 'insufficient',
            label=STATUSES[status] if status in STATUSES and confidence == 'high' else '',
            label_available_at=g.timestamp(submitted*4) if status in STATUSES and confidence == 'high' else '',
            notes=note, simulated=1))
    return reviews


def labels_as_of(reviews, cutoff):
    """Unknown, unreviewed, low-confidence or not-yet-received reports stay unlabelled."""
    labels = np.full(8760, np.nan)
    ids = np.full(8760, '', dtype='<U32')
    for r in reviews:
        if r['label'] == '' or hour_number(r['label_available_at']) > cutoff: continue
        a = int(np.ceil(hour_number(r['confirmed_start'])))
        b = int(np.floor(hour_number(r['confirmed_end_exclusive'])))
        if np.isfinite(labels[a:b]).any(): raise ValueError('Conflicting or overlapping app reviews require adjudication')
        labels[a:b] = int(r['label']); ids[a:b] = r['review_id']
    return labels, ids


def build(out, seed=SEED):
    fresh_output(out)
    config = dict(version='electricity-app-labels-v3', seed=seed, household='one older adult, two adults, two children',
        days=365, sample_minutes=15, target='next-hour household electricity kWh',
        anomaly_target='confirmed unexpected household electricity usage; not elder health or inactivity',
        primary_inputs='electricity history and calendar only; no app reports, water, gate or simulator truth',
        context='water and gate exported separately for future explicitly labelled comparisons',
        app='simulated family confirmation labels only; delayed, missing, uncertain and imperfect',
        label_policy='high-confidence direct family report; unknown is unlabelled; available by training cutoff',
        review_sampling='22% of nonoverlapping3h periods randomly audited; extra review if weekly3h energy difference>1kWh',
        review_response_probability=.9, high_confidence_probability=.94, simulated_report_error_probability=.015,
        reviews='completed3h period; request after30min; submitted0.5/2/8/24/48h later',
        normal_design='persistent cooling/weather, stable appliance power, small meal-time jitter, weekday/weekend routines',
        anomalies='36 planned mechanism events:24train,6validation,6test; simulation prevalence, not emergency rate',
        forecast_metric='MAE, RMSE, WAPE and seasonal-naive comparison on matched observed targets',
        detection_metric='ROC-AUC and average precision against available app confirmations; oracle audit separate',
        benchmark='seasonal-naive and fixed Ridge; validation only; test not scored; no search or seed selection',
        split='history days1-14; train15-219; validation220-292; test293-365',
        performance='learnable design assumptions, no promised score or real-world calibration',
        python=platform.python_version(), numpy=np.__version__)
    g.write_csv(out/'config.csv', [dict(parameter=k, value=v) for k, v in config.items()])
    (out/'config.csv').chmod(0o444)
    plans = scenario_plan(seed)
    g.write_csv(out/'truth/scenarios.csv', plans)
    (out/'truth/scenarios.csv').chmod(0o444)
    states, visitor = routines(seed)
    electricity, components, oracle, identifiers = physical_use(states, visitor, plans, seed)
    arrivals, incidents = delivery(seed)
    data = g.observe(states, visitor, arrivals, seed)
    rng = np.random.default_rng(seed+15)
    data['values']['electricity'] = (electricity*(1+rng.normal(0, .01, g.SLOTS))).round(6)
    data['values']['electricity'][~np.isfinite(arrivals['electricity'])] = np.nan
    data['events'] = [e for e in data['events'] if e['source'] == 'gate']
    tables = g.rows_for(data, states, visitor, 0, g.SLOTS)
    for name in ['observations_15min', 'targets_hourly', 'events']:
        g.write_csv(out/(name+'.csv'), tables[name])
    identity = ['case_id', 'household_id', 'hour', 'start_time', 'end_time', 'issued_time', 'partition']
    g.write_csv(out/'hourly.csv', [{k:r[k] for k in identity+INPUTS} for r in tables['hourly']])
    context = ['water_litres', 'water_partial_litres', 'water_observed_fraction', 'gate_observed_fraction',
               'gate_elder_verified_count', 'gate_other_verified_count', 'gate_unverified_count']
    g.write_csv(out/'context_hourly.csv', [{k:r[k] for k in identity+context} for r in tables['hourly']])
    g.write_csv(out/'truth/resident_activity_15min.csv', tables['resident_activity_15min'])
    g.write_csv(out/'truth/sensor_incidents.csv', incidents)
    g.write_csv(out/'truth/appliance_energy_15min.csv', [dict(slot=s, start_time=g.timestamp(s),
        **{k+'_kwh':g.number(v[s]) for k,v in components.items()}, total_kwh=g.number(electricity[s]),
        unexpected_usage=int(oracle[s]), scenario_id=identifiers[s]) for s in range(g.SLOTS)])
    g.write_csv(out/'truth/simulator_labels_hourly.csv', [dict(hour=h,
        unexpected_usage_minutes=int(oracle[h*4:h*4+4].sum()*15),
        unexpected_usage=int(oracle[h*4:h*4+4].any()),
        scenario_ids=';'.join(sorted(set(identifiers[h*4:h*4+4])- {''}))) for h in range(8760)])
    reviews = family_reviews(data, oracle, plans, seed)
    g.write_csv(out/'app_reviews.csv', reviews)
    final_labels, review_ids = labels_as_of(reviews, np.inf)
    by_id = {r['review_id']: r for r in reviews}
    g.write_csv(out/'app_labels_hourly.csv', [dict(hour=h, start_time=g.timestamp(h*4),
        label=int(final_labels[h]) if np.isfinite(final_labels[h]) else '', review_id=review_ids[h],
        label_available_at=by_id[review_ids[h]]['label_available_at'] if review_ids[h] else '') for h in range(8760)])
    usable = [r for r in reviews if r['label'] != '']
    g.write_csv(out/'summary.csv', [dict(households=1, hourly_rows=8760, quarter_hour_rows=g.SLOTS,
        unexpected_episodes=sum(r['unexpected_usage'] for r in plans),
        unexpected_hours=float(oracle.sum()/4), unexpected_hour_fraction=float(oracle.mean()),
        expected_change_episodes=sum(not r['unexpected_usage'] for r in plans),
        app_requests=len(reviews), usable_app_reports=len(usable), positive_app_reports=sum(r['label'] == 1 for r in usable),
        uncertain_or_unanswered_reports=len(reviews)-len(usable),
        models_trained_at_generation=0, test_scored=0)])
    g.write_csv(out/'feature_allowlist.csv', [dict(column=k, role='forecast input; completed history only') for k in INPUTS])
    g.write_csv(out/'splits.csv', [dict(partition=name, start_time=g.timestamp(a*96),
        end_time_exclusive=g.timestamp(b*96)) for name, a, b in g.PARTITIONS])
    g.write_csv(out/'residents.csv', [dict(resident_id=r, role=role, age=age) for r,role,age in g.RESIDENTS])
    (out/'source').mkdir()
    for name in ['electricity_dataset.py', 'generate.py', 'evaluation_v2.py', 'train.py', 'validate.py',
                 'paper_alarms.py', 'evaluation.py']:
        shutil.copy(Path(__file__).with_name(name), out/'source'/name)
    (out/'README.md').write_text(DATA_README)
    manifest(out)
    validate(out)
    print(f'Frozen electricity dataset: {out}', flush=True)


def validate(root):
    verify(root)
    hourly, raw = read(root/'hourly.csv'), read(root/'observations_15min.csv')
    target = read(root/'targets_hourly.csv')
    assert len(hourly) == len(target) == 8760 and len(raw) == 35040
    assert [r['column'] for r in read(root/'feature_allowlist.csv')] == INPUTS
    assert not set(INPUTS) & {'label', 'status', 'scenario_id', 'unexpected_usage', 'review_id'}
    for h, row in enumerate(hourly):
        assert int(row['hour']) == h and hour_number(row['issued_time']) == h+1
        quarter = raw[4*h:4*h+4]
        known = [r for r in quarter if r['electricity_kwh'] != '' and hour_number(r['electricity_received_at']) <= h+1]
        assert float(row['electricity_observed_fraction']) == len(known)/4
        assert (row['electricity_kwh'] != '') == (len(known) == 4)
        if len(known) == 4: assert abs(float(row['electricity_kwh'])-sum(float(r['electricity_kwh']) for r in known)) < 1e-6
        valid = all(r['electricity_kwh'] != '' for r in quarter)
        assert (target[h]['electricity_kwh'] != '') == valid
        if valid:
            assert abs(float(target[h]['electricity_kwh'])-sum(float(r['electricity_kwh']) for r in quarter)) < 1e-6
            assert hour_number(target[h]['target_available_at']) == max(hour_number(r['electricity_received_at']) for r in quarter)
    plans = read(root/'truth/scenarios.csv')
    for p in plans:
        a,b=int(p['start_slot']),int(p['end_slot'])
        assert 0 <= a < b <= g.SLOTS and g.partition(a) == g.partition(b-1) == p['partition']
    for a,b in zip(plans, plans[1:]): assert int(a['end_slot']) <= int(b['start_slot'])
    reviews = read(root/'app_reviews.csv')
    for r in reviews:
        assert hour_number(r['period_end_exclusive']) < hour_number(r['requested_at'])
        assert hour_number(r['requested_at']) < hour_number(r['submitted_at'])
        if r['label'] != '':
            assert r['confidence'] == 'high' and STATUSES[r['status']] == int(r['label'])
            assert r['submitted_at'] == r['label_available_at']
        else: assert r['label_available_at'] == ''
    labels_as_of(reviews, np.inf)
    print('PASS: manifest, chronological splits, all hourly aggregates, source separation and app-label timing', flush=True)


def model_features(raw, times):
    times = np.asarray(times, int)
    lags = np.r_[np.arange(1, 49), np.arange(3, 15)*24]
    past = raw[times[:,None]-lags]
    hour = times % 24; weekday = (times//24+g.ORIGIN.weekday()) % 7
    return np.column_stack((past, np.sin(hour*np.pi/12), np.cos(hour*np.pi/12),
                            np.sin(weekday*2*np.pi/7), np.cos(weekday*2*np.pi/7)))


def benchmark(data, out):
    """An inspectable validation-only learnability check, not a final model comparison."""
    validate(data); fresh_output(out, data)
    cfg = dict(dataset_manifest=hashlib.sha256((data/'manifest.csv').read_bytes()).hexdigest(),
        models='seasonal_naive; ridge alpha10 lsqr tolerance1e-6',
        features='electricity lags1..48 and72..336 by24h; known cyclical calendar; missing flags',
        training='target explicitly labelled0 by high-confidence app report received before5256h',
        evaluation='validation only; forecasts all observed targets; anomaly scores on confirmed reviewed3h periods',
        detection='absolute3h mean signed forecast residual; high and low usage; no selected alarm threshold',
        reports='app confirmations are references; simulator labels never fit model or preprocessing',
        test='not scored', parameter_search=False)
    g.write_csv(out/'config.csv', [dict(parameter=k,value=v) for k,v in cfg.items()])
    shutil.copy(data/'manifest.csv', out/'dataset_manifest.csv')
    shutil.copy(Path(__file__), out/'benchmark_source.py')
    rows = read(data/'hourly.csv'); targets = read(data/'targets_hourly.csv')
    raw = np.array([float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan for r in rows])
    y = np.array([float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan for r in targets])
    arrival = np.array([hour_number(r['target_available_at']) for r in targets])
    reviews = read(data/'app_reviews.csv')
    labels, review_ids = labels_as_of(reviews, 5256)
    train = np.arange(336, 5256)
    train = train[(labels[train] == 0) & np.isfinite(y[train]) & (arrival[train] <= 5256)]
    if len(train) < 100: raise ValueError('Insufficient reviewed normal training targets')
    times = np.arange(5256, 7008)
    x, vx = model_features(raw, train), model_features(raw, times)
    median = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in x.T])
    scale = np.std(np.where(np.isfinite(x), x, median), axis=0); scale[scale < 1e-6] = 1
    def transform(a): return np.column_stack(((np.where(np.isfinite(a),a,median)-median)/scale, ~np.isfinite(a)))
    model = Ridge(alpha=10., solver='lsqr', tol=1e-6, max_iter=1000)
    model.fit(transform(x), y[train])
    # einsum avoids a known local NumPy BLAS warning on otherwise finite Ridge dot products.
    fitted = np.maximum(0, np.einsum('ij,j->i', transform(vx), model.coef_)+model.intercept_)
    seasonal = raw[times-168]
    seasonal = np.where(np.isfinite(seasonal), seasonal, np.median(y[train]))
    joblib.dump(dict(model=model, median=median, scale=scale), out/'ridge.joblib', compress=3)
    g.write_csv(out/'training_targets.csv', [dict(hour=int(h), review_id=review_ids[h]) for h in train])
    metrics, predictions, review_scores = [], [], []
    for name, pred in [('seasonal_naive',seasonal), ('ridge',fitted)]:
        valid = np.isfinite(y[times]); error=pred[valid]-y[times][valid]
        metric=dict(model=name, partition='validation', observed_targets=int(valid.sum()),
            mae_wh=float(np.abs(error).mean()*1000), rmse_wh=float(np.sqrt(np.mean(error**2))*1000),
            wape=float(np.abs(error).sum()/np.abs(y[times][valid]).sum()),
            app_reviewed_intervals=0, app_positive_intervals=0, app_roc_auc='', app_average_precision='')
        for h, value in zip(times, pred):
            predictions.append(dict(model=name, target_hour=int(h), issued_time=g.timestamp(h*4),
                prediction_kwh=float(value), observed_kwh=g.number(y[h])))
        own=[]
        for r in reviews:
            if r['label'] == '' or hour_number(r['label_available_at']) > 7008: continue
            a,b=int(hour_number(r['confirmed_start'])),int(hour_number(r['confirmed_end_exclusive']))
            if a < 5256 or b > 7008: continue
            # At a completed3h decision, earlier late readings may now be available.
            if not (np.isfinite(y[a:b]).all() and (arrival[a:b] <= b+.5).all()): continue
            score=abs(float((pred[a-5256:b-5256]-y[a:b]).mean()))
            own.append(dict(model=name, review_id=r['review_id'], start_hour=a, end_hour=b,
                decision_time=g.timestamp((b+.5)*4), app_label=int(r['label']), score_kwh=score,
                request_reason=r['request_reason']))
        review_scores.extend(own)
        metric.update(app_reviewed_intervals=len(own), app_positive_intervals=sum(r['app_label'] for r in own))
        if len({r['app_label'] for r in own}) == 2:
            metric.update(app_roc_auc=float(roc_auc_score([r['app_label'] for r in own],[r['score_kwh'] for r in own])),
                app_average_precision=float(average_precision_score([r['app_label'] for r in own],[r['score_kwh'] for r in own])))
        metrics.append(metric)
    g.write_csv(out/'metrics.csv', metrics)
    g.write_csv(out/'predictions.csv', predictions)
    g.write_csv(out/'app_review_scores.csv', review_scores)
    lines=['# Electricity dataset v3 — validation check', '',
        'The forecast uses electricity history and calendar only. Simulated family app confirmations supply training labels and the anomaly reference; neither app responses nor simulator truth are prediction inputs. Test data has not been scored.', '',
        '| Model | MAE (Wh) | WAPE | App-reference ROC-AUC | App-reference average precision |',
        '|---|---:|---:|---:|---:|']
    for m in metrics:
        lines.append(f"| {m['model']} | {m['mae_wh']:.2f} | {m['wape']:.1%} | {m['app_roc_auc']} | {m['app_average_precision']} |")
    lines += ['', f'{len(train)} confirmed-normal targets trained Ridge; both models use the same observed validation targets.', '',
        'Anomaly scores rank the absolute mean signed residual over each three-hour review period. AUC and average precision describe separation on the reviewed subset; they do not establish a deployed alert threshold, episode recall, or monthly false-alert rate. Reviews are partly triggered by deviations, so this subset is not representative of all hours. Random audits are also included; request_reason permits separate sampling-bias analysis.', '',
        'App labels are delayed and imperfect; unknown, mixed or unanswered reports are not normal labels. Positive examples may be few. The simulator oracle remains separate for later audits. All results are synthetic; no family reports were collected from real users. No parameter search, seed selection or test-based dataset adjustment was performed.', '']
    (out/'report.md').write_text('\n'.join(lines))
    g.write_csv(out/'completed.csv', [dict(trained_models=1, training_targets=len(train), test_scored=0)])
    manifest(out)
    print(f'Completed validation-only benchmark: {out}', flush=True)


DATA_README = '''# One family: electricity forecasting and app-confirmed usage anomalies

This is a new synthetic year. Existing datasets and results are preserved. The family
contains an older adult, two adults and two children; the target is HOUSEHOLD ELECTRICITY
USAGE, not the older adult's health. No real family reports have been collected.

Normal demand has stable appliance power, persistent weather/cooling, repeated weekday
and weekend routines, small timing variation, visitors, trips and independent meter noise.
Unexpected appliance/routine events are planned before measurement generation. Their
label is not obtained by thresholding the generated electricity or a model residual.
Expected visitors and meals out deliberately overlap unusual patterns.

Files to review:
- hourly.csv: completed-hour electricity snapshots and known calendar inputs.
- targets_hourly.csv: eventual next-hour targets and their actual availability time.
- observations_15min.csv: raw electricity/water, arrival times and feed availability.
- context_hourly.csv and events.csv: optional water and gate context, excluded from the primary model.
- app_reviews.csv: simulated family confirmations, reporter, requested period, submission time,
  confidence, evidence, status and label. No response, low confidence and uncertainty are UNLABELLED.
- app_labels_hourly.csv: convenient hourly view of usable app labels, including their availability
  time and review ID. Filter label_available_at by the training cutoff before using these labels.
- truth/scenarios.csv, simulator_labels_hourly.csv, appliance_energy_15min.csv and resident_activity_15min.csv:
  simulator-only audit records. They must not be features or substitute for app training labels.
- feature_allowlist.csv, config.csv, splits.csv, summary.csv and manifest.csv: frozen contract and provenance.

App-confirmed ground truth means a family-verified reference, not infallible truth. Statuses
are normal_or_expected, confirmed_unusual_usage, uncertain_mixed_period, unable_to_verify,
and no_response. Only high-confidence direct confirmations become labels. Confirmation is
never auto-filled from the alert. Production collection should preserve revisions, adjudicate
disagreements and let reviewers answer uncertain. Sample normal/unflagged periods as well
as alert periods. Do not train on reports submitted after the training cutoff.

For forecasting, use previous observations to predict next-hour kWh; missing is never zero.
For anomaly detection, compare completed observations with past-only forecasts and evaluate
against later app confirmations. Do not supply those confirmations to the same prediction.
Algorithms may use hourly sequences (up to14days), lag tables or other explicitly documented
representations. Train on days15–219, calibrate/compare on220–292, and reserve293–365 for a
single final evaluation. History days1–14 initialise windows. Imputation/scaling fit training only.

This design makes the underlying process learnable but cannot guarantee high scores. Some
anomalies are ambiguous, some feeds fail and some family labels are wrong. WAPE/MAE measure
forecasting; detection requires separate precision/recall, delay, availability and false-alert
metrics. Good forecasting or app-reference AUC alone does not prove useful anomaly alarms.
The 36 unexpected-usage episodes are a simulation setting, not an emergency-rate estimate.
'''


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['generate','validate','benchmark'])
    parser.add_argument('--data', type=Path, default=Path('ml/household/electricity_data_v3'))
    parser.add_argument('--out', type=Path, default=Path('ml/household/runs/electricity-v3-validation'))
    args=parser.parse_args()
    if args.action=='generate': build(args.data)
    elif args.action=='validate': validate(args.data)
    else: benchmark(args.data,args.out)
