"""Independent checks of CSV grain, joins, timestamps, aggregation and truth separation."""
import argparse
import csv
import hashlib
from datetime import datetime
from pathlib import Path

import numpy as np


def read(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def validate_dataset(root, write_result=True):
    findings=[]
    def check(name, condition, detail):
        if not condition:
            raise AssertionError(f'{name}: {detail}')
        findings.append(dict(check=name,status='PASS',detail=detail))
    for folder, expected_raw, expected_hours in [(root,35040,8760),(root/'challenge',9216,2304)]:
        raw=read(folder/'observations_15min.csv')
        hours=read(folder/'hourly.csv')
        targets=read(folder/'targets_hourly.csv')
        labels=read(folder/'truth'/'labels_hourly.csv')
        truth=read(folder/'truth'/'resident_activity_15min.csv')
        events=read(folder/'events.csv')
        prefix='main' if folder==root else 'challenge'
        check(prefix+'_grain',len(raw)==expected_raw and len(hours)==len(targets)==len(labels)==expected_hours,
              f'{len(raw)} quarter-hours and {len(hours)} hourly rows')
        raw_index={(r['case_id'],int(r['slot'])):r for r in raw}
        hour_index={(r['case_id'],int(r['hour'])):r for r in hours}
        target_index={(r['case_id'],int(r['hour'])):r for r in targets}
        truth_index={(r['case_id'],int(r['slot'])):r for r in truth}
        check(prefix+'_unique',len(raw_index)==len(raw) and len(hour_index)==len(hours), 'unique case/time keys')
        check(prefix+'_one_household',{r['household_id'] for r in raw}=={'HH001'},'HH001 only')
        check(prefix+'_truth_join',set(raw_index)==set(truth_index),'one truth record per observation interval')
        check(prefix+'_target_join',set(target_index)==set(hour_index),'all hourly targets retained, including missing')
        event_index={}
        for r in events:
            moment=datetime.fromisoformat(r['event_time'])
            received=datetime.fromisoformat(r['received_at'])
            assert received>=moment
            origin=datetime(2026,1,1,tzinfo=moment.tzinfo)
            hour=int((moment-origin).total_seconds()//3600)
            event_index.setdefault((r['case_id'],hour),[]).append(r)
            assert r['meaningful']==str(int(r['event_type']!='background_sync'))
        for key,row in hour_index.items():
            case,hour=key
            own=[raw_index[(case,hour*4+i)] for i in range(4)]
            issue=datetime.fromisoformat(row['issued_time'])
            assert issue==datetime.fromisoformat(own[-1]['end_time'])
            for source,unit in [('electricity','kwh'),('water','litres')]:
                field=f'{source}_{unit}'
                known=[]
                for r in own:
                    val,received=r[field],r[f'{source}_received_at']
                    assert bool(val)==bool(received)
                    if val:
                        assert np.isfinite(float(val)) and float(val)>=0
                        assert datetime.fromisoformat(received)>=datetime.fromisoformat(r['end_time'])
                        if datetime.fromisoformat(received)<=issue:
                            known.append(float(val))
                assert float(row[f'{source}_observed_fraction'])==len(known)/4
                assert bool(row[field])==(len(known)==4)
                assert bool(row[f'{source}_partial_{unit}'])==bool(known)
                if known:
                    assert abs(float(row[f'{source}_partial_{unit}'])-sum(known))<2e-6
                if len(known)==4:
                    assert abs(float(row[field])-sum(known))<2e-6
            target=target_index[key]
            assert bool(target['electricity_kwh'])==all(r['electricity_kwh'] for r in own)
            assert target['observed']==str(int(bool(target['electricity_kwh'])))
            if target['electricity_kwh']:
                assert abs(float(target['electricity_kwh'])-sum(float(r['electricity_kwh']) for r in own))<2e-6
                assert datetime.fromisoformat(target['target_available_at'])==max(datetime.fromisoformat(r['electricity_received_at']) for r in own)
            for source in ['gate','app','elder_app']:
                fraction=sum(bool(r[f'{source}_received_at']) and datetime.fromisoformat(r[f'{source}_received_at'])<=issue for r in own)/4
                assert fraction==float(row[f'{source}_observed_fraction'])
            own_events=[r for r in event_index.get(key,[]) if datetime.fromisoformat(r['received_at'])<=issue]
            for source in ['app','gate']:
                for category in ['elder_verified','other_verified','unverified']:
                    coverage='elder_app' if source=='app' and category=='elder_verified' else source
                    field=f'{source}_{category}_count'
                    assert bool(row[field])==(float(row[f'{coverage}_observed_fraction'])==1)
                    selected=[r for r in own_events if r['source']==source and r['meaningful']=='1']
                    if category=='unverified': selected=[r for r in selected if r['attribution']!='verified']
                    else: selected=[r for r in selected if r['attribution']=='verified' and (r['claimed_resident_id']=='E1')==(category=='elder_verified')]
                    if row[field]: assert int(row[field])==len(selected)
            if row['app_background_count']:
                assert int(row['app_background_count'])==sum(r['source']=='app' and r['meaningful']=='0' for r in own_events)
        for row in labels:
            case,hour=row['case_id'],int(row['hour'])
            assert int(row['elder_concern_minutes'])==15*sum(truth_index[(case,hour*4+i)]['E1_state']=='unable' for i in range(4))
        check(prefix+'_time_and_aggregation',True,'every measurement and event re-aggregated independently at issue time')
        check(prefix+'_labels',True,'all concern durations reconcile to hidden older-adult states')
    episodes=[r for r in read(root/'truth'/'episodes.csv') if r['concern_label']=='1']
    check('concern_coverage',len(episodes)==6 and all(sum(r['partition']==p for r in episodes)==2 for p in ['train','validation','test']), 'two primary concern episodes per partition')
    cases=read(root/'challenge'/'truth'/'cases.csv')
    pairs={r['pair_id'] for r in cases}
    check('paired_cases',len(cases)==48 and len(pairs)==24 and all({r['concern'] for r in cases if r['pair_id']==p}=={'0','1'} for p in pairs),'24 pairs; 48 alternative replays')
    for r in cases:
        a,b=int(r['replay_start_slot']),int(r['replay_end_slot'])
        boundary=(219*96,292*96) if r['partition']=='validation' else (292*96,365*96)
        assert boundary[0]<=a<int(r['start_slot'])<int(r['end_slot'])<=b<=boundary[1]
    check('challenge_boundaries',True,'validation/test history and case windows stay in their assigned periods')
    allow={r['column'] for r in read(root/'feature_allowlist.csv')}
    columns=set(read(root/'hourly.csv')[0])
    forbidden={'partition','case_id','household_id','hour','scenario','concern','concern_label','E1_state','elder_concern_minutes'}
    check('feature_separation',allow<=columns and not allow.intersection(forbidden),'truth, targets and identifiers excluded from input allowlist')
    main=read(root/'observations_15min.csv')
    check('zero_not_missing',any(r['electricity_kwh']=='0.0' for r in main) and any(not r['electricity_kwh'] for r in main)
          and any(r['water_litres']=='0.0' for r in main),'observed zero electricity/water and missing records coexist')
    check('csv_only_datasets',not list(root.rglob('*.json')) and not list(root.rglob('*.npz')),'no JSON datasets or binary training caches')
    if (root/'manifest.csv').exists():
        manifest=read(root/'manifest.csv')
        actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()
                and p.name!='manifest.csv' and '__pycache__' not in p.parts}
        assert actual=={r['file'] for r in manifest}, 'Manifest file inventory differs'
        for r in manifest:
            assert hashlib.sha256((root/r['file']).read_bytes()).hexdigest()==r['sha256'],r['file']
        check('manifest_hashes',True,f'{len(manifest)} files match frozen hashes')
    if write_result and not (root/'manifest.csv').exists():
        with (root/'validation_results.csv').open('w',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=['check','status','detail'])
            writer.writeheader();writer.writerows(findings)
    print(f'PASS: {len(findings)} dataset checks, including independent aggregation of every hourly row.')
    return findings


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    validate_dataset(parser.parse_args().directory,write_result=False)
