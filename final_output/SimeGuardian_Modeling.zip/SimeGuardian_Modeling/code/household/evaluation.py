"""Shared forecasting metrics and an exploratory electricity-shortfall alarm rule."""
import numpy as np


def forecast_metrics(prediction, target, concern):
    valid = np.isfinite(target)
    if not np.isfinite(prediction).all():
        raise ValueError('Every algorithm must predict every evaluation timestamp')
    result = dict(targets=int(valid.sum()), mae_wh=None, rmse_wh=None,
                  benign_mae_wh=None, concern_mae_wh=None)
    if valid.any():
        error = prediction[valid] - target[valid]
        result.update(mae_wh=float(np.abs(error).mean()*1000),
                      rmse_wh=float(np.sqrt(np.square(error).mean())*1000))
    for name, mask in [('benign', valid & ~concern), ('concern', valid & concern)]:
        if mask.any():
            result[name+'_mae_wh'] = float(np.abs(prediction[mask]-target[mask]).mean()*1000)
    return result


def shortfall(prediction, timely_observed):
    """Three completed hours; no backfilled readings and no partial intervals."""
    score = np.full(len(prediction), np.nan)
    for i in range(2, len(prediction)):
        predicted, observed = prediction[i-2:i+1], timely_observed[i-2:i+1]
        if np.isfinite(observed).all() and np.isfinite(predicted).all():
            score[i] = np.maximum(predicted-observed, 0).mean()
    return score


def alert_groups(flags):
    indices = np.flatnonzero(flags)
    return np.split(indices, np.flatnonzero(np.diff(indices)>1)+1) if len(indices) else []


def detection(decision_hours, scores, threshold, episodes, *, include_onset=True):
    """A concern is detected only by a flagged decision while it is ongoing."""
    flags = np.isfinite(scores) & (scores > threshold)
    groups = alert_groups(flags)
    matched = set()
    results = []
    for episode in episodes:
        after_start = decision_hours >= episode['start'] if include_onset else decision_hours > episode['start']
        during = after_start & (decision_hours < episode['end'])
        hits = [i for i,g in enumerate(groups) if during[g].any()]
        matched.update(hits)
        hit_times = decision_hours[during & flags]
        results.append(dict(episode_id=episode['id'], start_hour=episode['start'], end_hour=episode['end'],
            detected=int(bool(hits)), observable=int(np.any(during & np.isfinite(scores))),
            delay_hours=float(hit_times[0]-episode['start']) if len(hit_times) else None,
            duplicate_alerts=max(0,len(hits)-1)))
    delays = [r['delay_hours'] for r in results if r['detected']]
    found = sum(r['detected'] for r in results)
    precision = len(matched)/len(groups) if groups else None
    recall = found/len(episodes) if episodes else None
    false_flags = flags.copy()
    for episode in episodes:
        after_start = decision_hours >= episode['start'] if include_onset else decision_hours > episode['start']
        false_flags[after_start & (decision_hours<episode['end'])] = False
    days = len(decision_hours)/24
    summary = dict(episodes=len(episodes), detected_episodes=found, recall=recall,
        alert_episodes=len(groups), false_alerts=len(groups)-len(matched),
        false_alerts_per_30_days=(len(groups)-len(matched))*30/days,
        alert_precision=precision,
        episode_alert_f1=(2*precision*recall/(precision+recall) if precision is not None and recall is not None and precision+recall else 0. if episodes else None),
        median_delay_hours=float(np.median(delays)) if delays else None,
        p90_delay_hours=float(np.percentile(delays,90)) if delays else None,
        duplicate_alerts=sum(r['duplicate_alerts'] for r in results),
        coverage=float(np.isfinite(scores).mean()), flagged_hours=int(flags.sum()),
        false_flagged_hours=int(false_flags.sum()),
        observable_episodes=sum(r['observable'] for r in results),
        observable_recall=found/sum(r['observable'] for r in results) if any(r['observable'] for r in results) else None)
    return summary, results, flags


def select_threshold(decision_hours, scores, episodes, budget=1.):
    """Validation only; tie-break by fewer false alerts, then higher threshold."""
    best, best_key = np.inf, (-1,-np.inf,-np.inf)
    for threshold in np.r_[np.inf, np.unique(scores[np.isfinite(scores)])]:
        summary, _, _ = detection(decision_hours, scores, threshold, episodes)
        if summary['false_alerts_per_30_days'] <= budget+1e-12:
            key = (summary['detected_episodes'], -summary['false_alerts'], threshold)
            if key > best_key:
                best, best_key = float(threshold), key
    return best
