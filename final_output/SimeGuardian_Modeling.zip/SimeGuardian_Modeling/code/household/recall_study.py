"""Recalibrate the frozen emergency detector for recall; do not refit any model."""
import argparse
import hashlib
import shutil
from pathlib import Path

import joblib
import numpy as np

if __package__:
    from . import generate as g, forecast_finetune as fine, precision_study as old, tuned_study as tuned
    from .multisource_dataset import build, LABELS, SOURCES
    from .two_stage import confusion, episode_audit
    from .validate import read
    from .evaluation_v2 import verify, fresh_output, manifest
else:
    import generate as g
    import forecast_finetune as fine
    import precision_study as old
    import tuned_study as tuned
    from multisource_dataset import build, LABELS, SOURCES
    from two_stage import confusion, episode_audit
    from validate import read
    from evaluation_v2 import verify, fresh_output, manifest


def recall_threshold(labels, scores, eligible, minimum_recall=.90):
    """Fewest false positives at the recall floor; abstained positives remain misses."""
    labels=np.asarray(labels);scores=np.asarray(scores);eligible=np.asarray(eligible,dtype=bool)
    if not 0<minimum_recall<=1:raise ValueError('Recall target must be in (0,1]')
    valid=np.isfinite(labels)&np.isfinite(scores)&eligible
    values=np.unique(scores[valid])
    if not len(values) or not np.any(labels==1):raise ValueError('No labelled scores or positive labels')
    candidates=[];chosen=None;best=None
    for threshold in np.r_[np.nextafter(values[0],-np.inf),values]:
        m=confusion(labels,scores,float(threshold),eligible)
        qualified=m['recall_counting_abstentions_as_misses']>=minimum_recall
        candidates.append(dict(threshold=float(threshold),qualified=int(qualified),**m))
        # Strict score > threshold is shared with the saved detector and evaluation.
        key=(-m['FP'],float(threshold))
        if qualified and (best is None or key>best):best=key;chosen=float(threshold)
    if chosen is None:raise ValueError('Recall target is unattainable, including abstained positives')
    return chosen,candidates


def prepare(data,prior):
    verify(prior);fresh_output(data,prior)
    plans=[dict(p) for p in read(prior/'plan.csv') if p['role']=='calibration']
    for seed in [20261044,20261045,20261046]:
        path=data/str(seed);build(path,revised=True,seed=seed)
        plans.append(dict(role='test',seed=seed,path=str(path),manifest_sha256=hashlib.sha256((path/'manifest.csv').read_bytes()).hexdigest(),
            end_hour=8760,simulator='unchanged v5',purpose='fresh recall-first holdout; no model refit'))
    g.write_csv(data/'plan.csv',plans);manifest(data)


def run(data,prior,out,device):
    import torch
    verify(data);verify(prior);fresh_output(out,data,prior)
    plans=read(data/'plan.csv');prior_plans=read(prior/'plan.csv')
    assert {int(p['seed']) for p in plans if p['role']=='test'}=={20261044,20261045,20261046}
    assert {p['seed'] for p in plans if p['role']=='test'}.isdisjoint({p['seed'] for p in prior_plans})
    assert [(p['seed'],p['manifest_sha256']) for p in plans if p['role']=='calibration']==[(p['seed'],p['manifest_sha256']) for p in prior_plans if p['role']=='calibration']
    calibration=[r for r in read(prior/'decisions.csv') if r['role']=='calibration' and r['system']=='tuned' and r['target']=='emergency' and r['reviewed_endpoint']=='1']
    labels=np.array([float(r['app_label']) if r['app_label'] else np.nan for r in calibration])
    scores=np.array([float(r['score']) for r in calibration]);eligible=np.array([r['eligible']=='1' for r in calibration])
    threshold,candidates=recall_threshold(labels,scores,eligible)
    detectors={t:joblib.load(prior/(t+'_detector.joblib')) for t in LABELS}
    previous=detectors['emergency']['threshold']
    assert threshold<previous
    detectors['emergency']['threshold']=threshold
    cfg=dict(study='recall-first-v9',minimum_validation_recall=.90,selection='fewest FP subject to recall >=90%, counting positive abstentions as misses; tie higher threshold',
        emergency_precision_floor='none',model_refits=0,simulator_changes=0,prior=str(prior),prior_manifest_sha256=hashlib.sha256((prior/'manifest.csv').read_bytes()).hexdigest(),
        emergency_old_threshold=previous,emergency_new_threshold=threshold,utility_threshold=detectors['usage_anomaly']['threshold'],
        primary='family-confirmed3h endpoints; unknown excluded; separate hourly episode audit',device=device)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in cfg.items()]);g.write_csv(out/'plan.csv',plans)
    g.write_csv(out/'threshold_candidates.csv',candidates)
    calibration_metrics=[dict(role='calibration',seed='pooled',target='emergency',system=system,threshold=t,**confusion(labels,scores,t,eligible))
        for system,t in [('precision_focused',previous),('recall_first',threshold)]]
    g.write_csv(out/'calibration_selection.csv',calibration_metrics)
    for target,model in detectors.items():joblib.dump(model,out/(target+'_detector.joblib'),compress=3)
    for path in out.iterdir():
        if path.is_file():path.chmod(0o444)
    (out/'source').mkdir()
    for name in ['recall_study.py','tuned_study.py','forecast_finetune.py','precision_study.py','two_stage.py','evaluation_v2.py','evaluation.py','validate.py','train.py','generate.py','multisource_dataset.py','revised_protocol.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    print('Threshold frozen before test:',threshold,'previous:',previous,flush=True)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    forecasters=Path('ml/household/runs/forecast-v7');gate=Path('ml/household/runs/forecast-v7-gate');base=Path('ml/household/runs/two-stage-v5')
    for path in [forecasters,gate,base]:verify(path)
    models,pre,_=fine.load(forecasters,device);override,override_pre,_=fine.load(gate,device);models.update(override);pre.update(override_pre)
    old_models,old_pre,old_scales=old.load_forecasters(base,device)
    mixing_rows=read(prior/'forecast_mixing.csv');mixing={r['source']:float(r['fine_weight']) for r in mixing_rows}
    scales=np.array([float(next(r for r in mixing_rows if r['source']==s)['residual_scale']) for s in SOURCES])
    g.write_csv(out/'model_references.csv',[dict(path=str(p),manifest_sha256=hashlib.sha256((p/'manifest.csv').read_bytes()).hexdigest()) for p in [forecasters,gate,base]])
    shutil.copy(prior/'forecast_mixing.csv',out/'forecast_mixing.csv')
    metrics=[];decisions=[];audits=[];episode_rows=[];pooled={}
    for plan in [p for p in plans if p['role']=='test']:
        r=tuned.replay(plan,models,pre,scales,old_models,old_pre,old_scales,mixing,out,device)
        for target in LABELS:
            model=detectors[target];score=tuned.temporal_score(old.scores(model['classifier'],r['x']),r['eligible'],model['score_mode'])
            systems=[('recall_first',threshold),('precision_focused',previous)] if target=='emergency' else [('unchanged',model['threshold'])]
            reviewed=r['ends']%3==0;label=r['labels'][target];ok=r['eligible']
            name='assistance_episodes' if target=='emergency' else 'usage_scenarios'
            episodes=[dict(id=e.get('scenario_id',e.get('episode_id')),start=int(e['start_slot'])/4,end=int(e['end_slot'])/4,kind=e['kind'])
                for e in read(r['data']/'truth'/(name+'.csv')) if (target=='emergency' or e['unexpected_usage']=='1')
                and int(e['start_slot'])/4>=r['start'] and int(e['end_slot'])/4<=r['end']]
            for system,t in systems:
                m=confusion(label[reviewed],score[reviewed],t,ok[reviewed])
                assert m['reviewed_intervals']+m['unlabelled_intervals']==int(reviewed.sum())
                metrics.append(dict(role='test',seed=r['seed'],target=target,system=system,threshold=t,**m))
                bucket=pooled.setdefault((target,system,t),[[],[],[]])
                for bucket_values,values in zip(bucket,[label[reviewed],score[reviewed],ok[reviewed]]):bucket_values.extend(values)
                decisions.extend(dict(seed=r['seed'],target=target,system=system,end_hour=int(h),score=float(s),eligible=int(e),alarm=int(e and s>t),reviewed_endpoint=int(h%3==0),app_label=int(y) if np.isfinite(y) else '')
                    for h,s,e,y in zip(r['ends'],score,ok,label))
                audit,events=episode_audit(r['ends'],np.where(ok,score,np.nan),t,episodes,r['start'],r['end'])
                audits.append(dict(seed=r['seed'],target=target,system=system,**audit))
                episode_rows.extend(dict(seed=r['seed'],target=target,system=system,kind=e['kind'],**v) for e,v in zip(episodes,events))
    for (target,system,t),(y,s,e) in pooled.items():
        m=confusion(np.array(y),np.array(s),t,np.array(e))
        metrics.append(dict(role='test',seed='pooled',target=target,system=system,threshold=t,**m))
        print('TEST',target,system,m,flush=True)
    for name,rows in [('confusion_matrices',metrics),('decisions',decisions),('oracle_episode_metrics',audits),('oracle_episode_results',episode_rows)]:g.write_csv(out/(name+'.csv'),rows)
    manifest(out);verify(out);print('Frozen',out,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['prepare','run'])
    p.add_argument('--data',type=Path,default=Path('ml/household/recall_data_v9'))
    p.add_argument('--prior',type=Path,default=Path('ml/household/runs/tuned-v8'))
    p.add_argument('--out',type=Path,default=Path('ml/household/runs/recall-v9'))
    p.add_argument('--device',choices=['cpu','mps'],default='cpu')
    a=p.parse_args()
    if a.action=='prepare':prepare(a.data,a.prior)
    else:run(a.data,a.prior,a.out,a.device)
