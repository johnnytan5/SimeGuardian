"""Evaluate fine-tuned source forecasts and a more timely emergency detector."""
import argparse
import hashlib
import shutil
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

if __package__:
    from . import generate as g,forecast_finetune as fine,precision_study as old, revised_protocol as protocol
    from .multisource_dataset import SOURCES,LABELS
    from .two_stage import source_inputs,review_labels,confusion,episode_audit
    from .train import inputs,predict,hour_number
    from .validate import read
    from .evaluation_v2 import verify,fresh_output,manifest
else:
    import generate as g
    import forecast_finetune as fine
    import precision_study as old
    import revised_protocol as protocol
    from multisource_dataset import SOURCES,LABELS
    from two_stage import source_inputs,review_labels,confusion,episode_audit
    from train import inputs,predict,hour_number
    from validate import read
    from evaluation_v2 import verify,fresh_output,manifest

EXTRA=[s+'_'+name for s in SOURCES for name in ['latest_residual','latest_observed','residual6h','residual6h_available']]
EXTRA += [s+'_'+who+'_'+str(hours)+'h' for s in ['gate','app'] for who in ['elder','other','available'] for hours in [1,3,6]]
EXTRA += ['elder_age_hours','gate_last_verified_exit','hours_sin','hours_cos','weekday_sin','weekday_cos']
FEATURES=old.FEATURES+EXTRA
GRID=[dict(name=f'boost-{leaves}-{l2}-{balance}',leaves=leaves,l2=l2,balance=balance)
      for leaves in [7,15,31] for l2 in [2.,10.] for balance in ['balanced','natural']]


def features(ends,forecast,y,arrival,events,scales):
    base,eligible,_=old.features(ends,forecast,y,arrival,events,scales);extra=[]
    for end in ends:
        end=int(end);cut=end+.5;row=[]
        for j,s in enumerate(SOURCES):
            latest=np.isfinite(y[end-1,j]) and arrival[end-1,j]<=cut
            past=slice(max(0,end-6),end)
            known=np.isfinite(y[past,j]).all() and (arrival[past,j]<=cut).all() and np.isfinite(forecast[past,j]).all()
            row.extend([float((forecast[end-1,j]-y[end-1,j])/scales[j]) if latest else 0.,float(y[end-1,j]) if latest else 0.,
                float((forecast[past,j]-y[past,j]).mean()/scales[j]) if known else 0.,float(known)])
        for s in ['gate','app']:
            j=SOURCES.index(s)
            for who in ['elder','other','available']:
                for hours in [1,3,6]:
                    a=max(0,end-hours)
                    known=np.mean(np.isfinite(y[a:end,j])&(arrival[a:end,j]<=cut))>=.9
                    es=[e for h in range(a,end) for e in events.get(h,[]) if e['source']==s and e['verified'] and e['meaningful']
                        and e['arrival']<=cut and e['time']<end and ((e['resident']=='E1') if who=='elder' else (e['resident']!='E1'))]
                    row.append(float(known) if who=='available' else float(len(es)) if known else 0.)
        personal=[e for h in range(max(0,end-48),end) for e in events.get(h,[]) if e['source'] in ['app','gate']
            and e['resident']=='E1' and e['verified'] and e['meaningful'] and e['arrival']<=cut and e['time']<end]
        age=min([end-e['time'] for e in personal],default=48.)
        gates=[e for e in personal if e['source']=='gate'];last=max(gates,key=lambda e:e['time']) if gates else None
        hour=end%24;weekday=(end//24+g.ORIGIN.weekday())%7
        row.extend([age,float(last is not None and last['kind']=='exit'),np.sin(hour*np.pi/12),np.cos(hour*np.pi/12),
                    np.sin(weekday*2*np.pi/7),np.cos(weekday*2*np.pi/7)])
        extra.append(row)
    result=np.column_stack((base,extra))
    if not np.isfinite(result).all():raise ValueError('Non-finite detector input')
    return result,eligible


def smoothed(score,eligible,amount):
    result=np.array(score,copy=True)
    if amount:
        ok=np.asarray(eligible[1:])&np.asarray(eligible[:-1])
        result[1:]=np.where(ok,(1-amount)*score[1:]+amount*score[:-1],score[1:])
    return result


def temporal_score(score,eligible,mode):
    if mode=='raw':return np.array(score,copy=True)
    if mode=='mean2':return smoothed(score,eligible,.5)
    if mode!='confirm2':raise ValueError('Unknown temporal score policy')
    # No prior valid score defers an alarm; the current positive is still a miss in interval recall.
    result=np.zeros_like(score)
    known=np.asarray(eligible[1:])&np.asarray(eligible[:-1])
    result[1:]=np.where(known,np.minimum(score[1:],score[:-1]),0.)
    return result


def replay(plan,models,pre,scales,old_models,old_pre,prior_scales,mixing,out,device):
    data=Path(plan['path']);verify(data)
    if hashlib.sha256((data/'manifest.csv').read_bytes()).hexdigest()!=plan['manifest_sha256']:raise ValueError('Data reference changed')
    seed=int(plan['seed']);role=plan['role'];rows=read(data/'hourly.csv');targets=read(data/'targets_hourly.csv')
    reviews=read(data/'app_reviews.csv');y=np.array([[float(r[s]) if r[s] else np.nan for s in SOURCES] for r in targets])
    arrival=np.array([[hour_number(r[s+'_available_at']) for s in SOURCES] for r in targets]);events=defaultdict(list)
    for r in read(data/'events.csv'):
        t=hour_number(r['event_time'])
        events[int(t)].append(dict(source=r['source'],time=t,arrival=hour_number(r['received_at']),resident=r['claimed_resident_id'],
            verified=r['attribution']=='verified',meaningful=r['meaningful']=='1',kind=r['event_type']))
    a,b=(3600,int(plan.get('end_hour',7008))) if role=='development' else (7008,8760)
    times=np.arange(a-24,b);forecast=np.full_like(y,np.nan);original=np.full_like(y,np.nan);predictions=[];metrics=[]
    for j,s in enumerate(SOURCES):
        raw=source_inputs(rows,s);parts=fine.prepared(raw,times,pre[s]);pp=[]
        for training_seed,m in zip([11,22,33],models[s]):
            p=fine.estimate(m,parts,float(pre[s]['scale'][0]),device);pp.append(p)
            predictions.extend(dict(seed=seed,role=role,source=s,hour=int(h),model='tuned_seed'+str(training_seed),prediction=float(v)) for h,v in zip(times,p))
        forecast[times,j]=np.mean(pp,axis=0)
        prior=inputs(raw,times,old_pre[s])
        original[times,j]=np.mean([predict('lstm',old_models[(s,k)],prior,raw,times,old_pre[s],device) for k in [11,22,33]],axis=0)
        forecast[times,j]=mixing[s]*forecast[times,j]+(1-mixing[s])*original[times,j]
        naive=np.where(np.isfinite(raw[times-168,0]),raw[times-168,0],old_pre[s]['median'][0])
        for model,p in [('tuned',forecast[times,j]),('original',original[times,j]),('weekly',naive),('zero',np.zeros(len(times)))]:
            keep=(times>=a)&np.isfinite(y[times,j]);error=p[keep]-y[times[keep],j]
            metrics.append(dict(role=role,seed=seed,source=s,model=model,targets=int(keep.sum()),
                mae=float(np.abs(error).mean()),rmse=float(np.sqrt(np.mean(error**2))),actual_sum=float(y[times[keep],j].sum())))
            if model in ['tuned','original']:predictions.extend(dict(seed=seed,role=role,source=s,hour=int(h),model=model,prediction=float(v)) for h,v in zip(times,p))
    ends=np.arange(a+3,b+1);x,eligible=features(ends,forecast,y,arrival,events,scales)
    original_x,_,_=old.features(ends,original,y,arrival,events,prior_scales)
    cutoff=b if role=='development' else 8832
    labels={t:review_labels(reviews,ends,t,cutoff) for t in LABELS}
    folder=out/'replays'/str(seed)
    g.write_csv(folder/'forecasts.csv',predictions);g.write_csv(folder/'forecast_metrics.csv',metrics)
    g.write_csv(folder/'features.csv',[dict(role=role,seed=seed,end_hour=int(h),eligible=int(ok),**dict(zip(FEATURES,map(float,v)))) for h,ok,v in zip(ends,eligible,x)])
    print('Replayed',role,seed,flush=True)
    return dict(role=role,seed=seed,x=x,original_x=original_x,eligible=eligible,labels=labels,ends=ends,start=a,end=b,data=data)


def run(data,forecasters,base,old_run,out,device='cpu',validation_only=False,gate_model=None):
    import torch
    verify(data);verify(forecasters);verify(base);verify(old_run);fresh_output(out,data,forecasters,base,old_run)
    torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    plans=read(data/'plan.csv')
    cfg=dict(study='forecast-emergency-v8',simulator='unchanged v5',primary='same reviewed3h labels; precision goal85%; compare recall/F1',
        emergency_replay='hourly rolling3h completed observations, decision+30min; original baseline stays3h cadence',
        calibration_precision=.94,calibration_minimum_alerts=20,calibration_minimum_recall=.30,selection='max confirmed TP then fewer FP; no test tuning',
        forecasters=str(forecasters),forecaster_manifest=hashlib.sha256((forecasters/'manifest.csv').read_bytes()).hexdigest(),
        validation_only=validation_only,device=device)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in cfg.items()]);(out/'config.csv').chmod(0o444)
    g.write_csv(out/'plan.csv',plans);g.write_csv(out/'candidate_grid.csv',GRID)
    (out/'source').mkdir()
    for name in ['tuned_study.py','forecast_finetune.py','precision_study.py','two_stage.py','train.py','generate.py',
                 'multisource_dataset.py','revised_protocol.py','evaluation_v2.py','evaluation.py','validate.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    models,pre,scales=fine.load(forecasters,device);old_models,old_pre,old_scales=old.load_forecasters(base,device)
    if gate_model is not None:
        override,override_pre,_=fine.load(gate_model,device);models.update(override);pre.update(override_pre)
        g.write_csv(out/'gate_override.csv',[dict(path=str(gate_model),manifest_sha256=hashlib.sha256((gate_model/'manifest.csv').read_bytes()).hexdigest())])
    mixing,scales,blend_grid=fine.calibrate_blend(Path('ml/household/precision_data_v6'),forecasters,models,pre,old_models,old_pre,device)
    g.write_csv(out/'forecast_blend_candidates.csv',blend_grid)
    g.write_csv(out/'forecast_mixing.csv',[dict(source=s,fine_weight=mixing[s],residual_scale=scales[j]) for j,s in enumerate(SOURCES)])
    (out/'forecast_mixing.csv').chmod(0o444)
    rr={role:[replay(p,models,pre,scales,old_models,old_pre,old_scales,mixing,out,device) for p in plans if p['role']==role] for role in ['development','calibration']}
    fitx=np.concatenate([r['x'] for r in rr['development']]);fite=np.concatenate([r['eligible'] for r in rr['development']])
    selected={};selections=[];candidates=[];training=[]
    for target in LABELS:
        fy=np.concatenate([r['labels'][target] for r in rr['development']]);use=np.isfinite(fy)&fite
        training.extend(dict(target=target,seed=r['seed'],end_hour=int(h),label=int(v)) for r in rr['development']
            for h,v,ok in zip(r['ends'],r['labels'][target],r['eligible']) if ok and np.isfinite(v))
        vy=np.concatenate([r['labels'][target] for r in rr['calibration']]);ve=np.concatenate([r['eligible'] for r in rr['calibration']])
        best=(-1,-np.inf);chosen=None
        for spec in GRID:
            clf=HistGradientBoostingClassifier(max_iter=180,learning_rate=.05,max_leaf_nodes=spec['leaves'],min_samples_leaf=15,
                l2_regularization=spec['l2'],class_weight='balanced' if spec['balance']=='balanced' else None,early_stopping=False,random_state=44)
            with threadpool_limits(limits=4):clf.fit(fitx[use],fy[use])
            raw=[old.scores(clf,r['x']) for r in rr['calibration']]
            for mode in ['raw','mean2','confirm2']:
                ss=[temporal_score(s,r['eligible'],mode) for s,r in zip(raw,rr['calibration'])];vs=np.concatenate(ss)
                threshold=old.precision_threshold(vy,vs,ve,precision=.94,min_alerts=20)
                m=confusion(vy,vs,threshold,ve);qualified=np.isfinite(threshold) and m['recall_counting_abstentions_as_misses']>=.30
                candidates.append(dict(target=target,candidate=spec['name'],score_mode=mode,threshold=threshold,qualified=int(qualified),**m))
                key=(m['TP'],-m['FP'])
                if qualified and key>best:best=key;chosen=dict(classifier=clf,threshold=threshold,score_mode=mode,candidate=spec['name'],features=FEATURES)
        if chosen is None:
            g.write_csv(out/'candidate_metrics.csv',candidates);raise RuntimeError('No precision-qualified calibration candidate; test unscored')
        selected[target]=chosen;joblib.dump(chosen,out/(target+'_detector.joblib'),compress=3)
        (out/(target+'_detector.joblib')).chmod(0o444)
        r=next(c for c in candidates if c['target']==target and c['candidate']==chosen['candidate'] and c['score_mode']==chosen['score_mode'])
        selections.append(dict(target=target,**{k:r[k] for k in ['candidate','score_mode','threshold','precision','recall','f1','TP','FP']}))
        print('SELECTED',selections[-1],flush=True)
    g.write_csv(out/'selection.csv',selections);(out/'selection.csv').chmod(0o444)
    g.write_csv(out/'candidate_metrics.csv',candidates);g.write_csv(out/'training_labels.csv',training)
    print('Detector models/thresholds frozen; test '+('remains unscored' if validation_only else 'starts now'),flush=True)
    if not validation_only:rr['test']=[replay(p,models,pre,scales,old_models,old_pre,old_scales,mixing,out,device) for p in plans if p['role']=='test']
    prior={t:joblib.load(old_run/(t+'_detector.joblib')) for t in LABELS}
    metrics=[];decisions=[];audits=[];episodes_rows=[]
    for role in ['calibration']+([] if validation_only else ['test']):
        for target in LABELS:
            for system in ['tuned','v6_original']:
                ys=[];scores=[];ok=[];threshold=selected[target]['threshold'] if system=='tuned' else prior[target]['threshold']
                for r in rr[role]:
                    if system=='tuned':
                        score=temporal_score(old.scores(selected[target]['classifier'],r['x']),r['eligible'],selected[target]['score_mode']);take=np.ones(len(score),bool)
                    else:score=old.scores(prior[target]['classifier'],r['original_x']);take=r['ends']%3==0
                    label=r['labels'][target];eligible=r['eligible']
                    # Interval precision/recall always use the original family-reviewed3h endpoints.
                    reviewed=r['ends']%3==0;m=confusion(label[reviewed],score[reviewed],threshold,eligible[reviewed])
                    metrics.append(dict(role=role,seed=r['seed'],target=target,system=system,**m))
                    ys.extend(label[reviewed]);scores.extend(score[reviewed]);ok.extend(eligible[reviewed])
                    decisions.extend(dict(role=role,seed=r['seed'],target=target,system=system,end_hour=int(h),score=float(v),eligible=int(e),
                        alarm=int(e and v>threshold),reviewed_endpoint=int(h%3==0),app_label=int(y) if np.isfinite(y) else '')
                        for h,v,e,y in zip(r['ends'][take],score[take],eligible[take],label[take]))
                    name='usage_scenarios' if target=='usage_anomaly' else 'assistance_episodes'
                    es=[dict(id=e.get('scenario_id',e.get('episode_id')),start=int(e['start_slot'])/4,end=int(e['end_slot'])/4,kind=e['kind'])
                        for e in read(r['data']/'truth'/(name+'.csv')) if (target!='usage_anomaly' or e['unexpected_usage']=='1')
                        and int(e['start_slot'])/4>=r['start'] and int(e['end_slot'])/4<=r['end']]
                    audit,events=episode_audit(r['ends'][take],np.where(eligible[take],score[take],np.nan),threshold,es,r['start'],r['end'])
                    audits.append(dict(role=role,seed=r['seed'],target=target,system=system,**audit))
                    episodes_rows.extend(dict(role=role,seed=r['seed'],target=target,system=system,kind=e['kind'],**v) for e,v in zip(es,events))
                metrics.append(dict(role=role,seed='pooled',target=target,system=system,**confusion(np.array(ys),np.array(scores),threshold,np.array(ok))))
    for name,rows in [('confusion_matrices',metrics),('decisions',decisions),('oracle_episode_metrics',audits),('oracle_episode_results',episodes_rows)]:g.write_csv(out/(name+'.csv'),rows)
    g.write_csv(out/'completed.csv',[dict(test_scored=int(not validation_only))]);manifest(out)
    print('Completed',out,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path('ml/household/tuning_data_v8'))
    p.add_argument('--forecasters',type=Path,default=Path('ml/household/runs/forecast-v7'))
    p.add_argument('--base',type=Path,default=Path('ml/household/runs/two-stage-v5'))
    p.add_argument('--prior',type=Path,default=Path('ml/household/runs/precision-v6'))
    p.add_argument('--out',type=Path,default=Path('ml/household/runs/tuned-v8'))
    p.add_argument('--device',choices=['cpu','mps'],default='cpu');p.add_argument('--validation-only',action='store_true')
    p.add_argument('--gate-model',type=Path)
    a=p.parse_args();run(a.data,a.forecasters,a.base,a.prior,a.out,a.device,a.validation_only,a.gate_model)
