"""Compare selectable forecasting algorithms on the frozen one-family CSV dataset."""
import argparse
import hashlib
import json
import platform
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from threadpoolctl import threadpool_limits

if __package__:
    from .generate import FEATURE_COLUMNS, ORIGIN, write_csv
    from .validate import read, validate_dataset
    from .evaluation import forecast_metrics, shortfall, detection, select_threshold
else:
    from generate import FEATURE_COLUMNS, ORIGIN, write_csv
    from validate import read, validate_dataset
    from evaluation import forecast_metrics, shortfall, detection, select_threshold

HISTORY = 336
MODELS = ['seasonal_naive', 'ridge', 'random_forest', 'gradient_boosting', 'lstm']
ELECTRICITY = FEATURE_COLUMNS.index('electricity_kwh')


def config(smoke=False):
    return dict(history_hours=HISTORY, seeds=[11,22,33], target='next-hour electricity kWh',
        preprocessing='training-history medians and standard deviations; per-channel missing masks',
        snapshot_policy='frozen as-of hourly snapshots, no delayed backfill',
        training_policy='observed targets available by training cutoff; no concern in history or target',
        ridge_alpha=100., forest_trees=10 if smoke else 200, forest_max_depth=16,
        forest_min_leaf=4, forest_max_features='sqrt', boosting_iterations=5 if smoke else 150,
        boosting_rate=.05, boosting_leaves=15, boosting_bins=63, boosting_max_features=.5,
        boosting_l2=1., boosting_min_leaf=20, boosting_early_stopping=False,
        lstm_units=32, dense_units=16, epochs=1 if smoke else 30, patience=5,
        batch_size=128, learning_rate=.001, output_activation='linear; final predictions clipped at zero for all models',
        lstm_target_scaling='training-target mean and standard deviation', gradient_clip=1.,
        false_alert_budget_per_30_days=1., alarm='mean positive electricity shortfall over 3 timely completed hours',
        threshold_selection='main validation episode recall, then fewer false alerts, then higher threshold',
        alarm_match='flagged hourly decision >= onset and < end; first two hours of each replay/partition abstain',
        challenge_policy='separate alternatives with main history before replay start; never used for fitting or threshold selection',
        smoke=smoke, parameter_search=False)


def values(rows):
    return np.array([[float(r[c]) if r[c] else np.nan for c in FEATURE_COLUMNS] for r in rows],dtype=np.float32)


def hour_number(stamp):
    return (datetime.fromisoformat(stamp)-ORIGIN).total_seconds()/3600 if stamp else np.inf


def load_data(root):
    validate_dataset(root,write_result=False)
    listed = [r['column'] for r in read(root/'feature_allowlist.csv')]
    if listed != FEATURE_COLUMNS:
        raise ValueError('Dataset feature allowlist differs from the approved training contract')
    rows = read(root/'hourly.csv')
    if any(int(r['hour'])!=i or hour_number(r['issued_time'])!=i+1 for i,r in enumerate(rows)):
        raise ValueError('Hourly inputs must be contiguous, completed-hour snapshots')
    yrows = read(root/'targets_hourly.csv')
    labels = read(root/'truth'/'labels_hourly.csv')
    y = np.array([float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan for r in yrows])
    arrival = np.array([hour_number(r['target_available_at']) for r in yrows])
    concern = np.array([int(r['elder_concern_minutes'])>0 for r in labels])
    split = {r['partition']:(int(hour_number(r['start_time'])),int(hour_number(r['end_time_exclusive'])))
             for r in read(root/'splits.csv')}
    episodes = [dict(id=r['episode_id'],start=int(r['start_slot'])/4,end=int(r['end_slot'])/4)
                for r in read(root/'truth'/'episodes.csv') if r['concern_label']=='1']
    return dict(x=values(rows),y=y,arrival=arrival,concern=concern,split=split,episodes=episodes)


def training_times(data):
    a,b = data['split']['train']
    times = np.arange(a,b)
    count = np.r_[0,np.cumsum(data['concern'])]
    clean = count[times+1] == count[times-HISTORY]
    return times[clean & np.isfinite(data['y'][times]) & (data['arrival'][times]<=b)]


def fit_preprocessing(raw, times, history=HISTORY):
    times = np.asarray(times,dtype=int)
    used = np.unique((times[:,None]-history+np.arange(history)).ravel())
    train = raw[used]
    median = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in train.T],dtype=np.float32)
    filled = np.where(np.isfinite(train),train,median)
    scale = np.std(filled,axis=0)
    scale[scale<1e-6] = 1
    return dict(median=median,scale=scale,history_hours=history,feature_names=list(FEATURE_COLUMNS))


def inputs(raw, times, preprocessing):
    history = preprocessing['history_hours']
    times = np.asarray(times,dtype=int)
    past = times[:,None]-history+np.arange(history)
    if np.any(past<0) or np.any(times>=len(raw)):
        raise ValueError('Targets require a complete prior history window')
    observed = raw[past]
    missing = ~np.isfinite(observed)
    sequence = (np.where(missing,preprocessing['median'],observed)-preprocessing['median'])/preprocessing['scale']
    sequence = np.concatenate((sequence,missing.astype(np.float32)),axis=2)
    h = times%24
    d = (times//24+ORIGIN.weekday())%7
    calendar = np.column_stack((np.sin(h*2*np.pi/24),np.cos(h*2*np.pi/24),
                                np.sin(d*2*np.pi/7),np.cos(d*2*np.pi/7))).astype(np.float32)
    return sequence,calendar


def tabular(prepared):
    sequence,calendar = prepared
    return np.column_stack((sequence.reshape(len(sequence),-1),calendar))


def small_lstm(channels):
    import torch
    class SmallLSTM(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.recurrent = torch.nn.LSTM(channels,32,batch_first=True)
            self.hidden = torch.nn.Linear(36,16)
            self.output = torch.nn.Linear(16,1)

        def forward(self,sequence,calendar):
            _,(state,_) = self.recurrent(sequence)
            hidden = torch.relu(self.hidden(torch.cat((state[-1],calendar),dim=1)))
            return self.output(hidden).squeeze(-1)
    return SmallLSTM()


def fit_model(name,seed,train,val,y,yval,cfg,folder,device):
    started = time.monotonic()
    if name=='lstm':
        import torch
        torch.manual_seed(seed)
        torch.use_deterministic_algorithms(True)
        torch.set_num_threads(4)
        model = small_lstm(train[0].shape[2]).to(device)
        optimizer = torch.optim.Adam(model.parameters(),lr=cfg['learning_rate'])
        ymean,yscale = float(y.mean()),max(float(y.std()),1e-6)
        x,c = [torch.from_numpy(a).to(device) for a in train]
        vx,vc = [torch.from_numpy(a).to(device) for a in val]
        target = torch.tensor((y-ymean)/yscale,dtype=torch.float32,device=device)
        vtarget = torch.tensor((yval-ymean)/yscale,dtype=torch.float32,device=device)
        rng = np.random.default_rng(seed)
        best,stale,weights,history = np.inf,0,None,[]
        for epoch in range(cfg['epochs']):
            model.train(); order=rng.permutation(len(y)); total=0.
            for start in range(0,len(order),cfg['batch_size']):
                ids=torch.as_tensor(order[start:start+cfg['batch_size']],device=device)
                estimate=model(x[ids],c[ids])
                loss=torch.nn.functional.mse_loss(estimate,target[ids])
                if not torch.isfinite(loss):raise ValueError('Non-finite training loss')
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(),cfg['gradient_clip'])
                optimizer.step();total+=float(loss.item())*len(ids)
            model.eval();validation=0.
            with torch.no_grad():
                for start in range(0,len(yval),cfg['batch_size']):
                    end=start+cfg['batch_size']
                    error=model(vx[start:end],vc[start:end])-vtarget[start:end]
                    validation+=float(torch.square(error).sum().item())
            validation/=len(yval)
            history.append(dict(epoch=epoch+1,train_mse_kwh2=total/len(y)*yscale**2,
                                validation_mse_kwh2=validation*yscale**2))
            print(f'  LSTM {seed}, epoch {epoch+1}: validation MSE={validation*yscale**2:.5f}',flush=True)
            if validation<best:
                best,stale=validation,0
                weights={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            else:
                stale+=1
                if stale>=cfg['patience']:break
        model.load_state_dict(weights)
        write_csv(folder/'epochs.csv',history)
        torch.save(dict(state_dict=weights,channels=train[0].shape[2],target_mean=ymean,target_scale=yscale),folder/'model.pt')
        fitted=dict(model=model,target_mean=ymean,target_scale=yscale)
        summary=dict(epochs=len(history),best_epoch=int(np.argmin([r['validation_mse_kwh2'] for r in history]))+1,
                     parameters=sum(p.numel() for p in model.parameters()))
    else:
        constructors={
            'ridge':lambda:Ridge(alpha=cfg['ridge_alpha'],solver='lsqr',tol=1e-4,max_iter=500),
            'random_forest':lambda:RandomForestRegressor(n_estimators=cfg['forest_trees'],max_depth=cfg['forest_max_depth'],
                min_samples_leaf=cfg['forest_min_leaf'],max_features=cfg['forest_max_features'],n_jobs=4,random_state=seed),
            'gradient_boosting':lambda:HistGradientBoostingRegressor(max_iter=cfg['boosting_iterations'],
                learning_rate=cfg['boosting_rate'],max_leaf_nodes=cfg['boosting_leaves'],max_bins=cfg['boosting_bins'],
                max_features=cfg['boosting_max_features'],l2_regularization=cfg['boosting_l2'],
                min_samples_leaf=cfg['boosting_min_leaf'],early_stopping=False,random_state=seed)}
        model=constructors[name]()
        model.fit(tabular(train),y)
        joblib.dump(model,folder/'model.joblib',compress=3)
        fitted=dict(model=model)
        summary=dict(epochs=None,best_epoch=None,parameters=None)
    return fitted,dict(**summary,training_seconds=time.monotonic()-started)


def predict(name,fitted,prepared,raw,times,preprocessing,device):
    if name=='seasonal_naive':
        previous=raw[np.asarray(times)-168,ELECTRICITY]
        return np.where(np.isfinite(previous),previous,preprocessing['median'][ELECTRICITY]).astype(float)
    if name!='lstm':
        return np.maximum(0,fitted['model'].predict(tabular(prepared)))
    import torch
    model=fitted['model'];model.eval();result=[]
    with torch.no_grad():
        for start in range(0,len(times),128):
            seq,cal=[torch.from_numpy(v[start:start+128]).to(device) for v in prepared]
            result.extend(model(seq,cal).cpu().numpy()*fitted['target_scale']+fitted['target_mean'])
    return np.maximum(0,np.asarray(result,dtype=float))


def in_boundary(episodes,a,b):
    return [r for r in episodes if r['start']>=a and r['end']<=b]


def load_challenges(root,base,preprocessing,smoke):
    grouped={};targets={};labels={}
    for r in read(root/'challenge'/'hourly.csv'):grouped.setdefault(r['case_id'],[]).append(r)
    for r in read(root/'challenge'/'targets_hourly.csv'):targets.setdefault(r['case_id'],[]).append(r)
    for r in read(root/'challenge'/'truth'/'labels_hourly.csv'):labels.setdefault(r['case_id'],[]).append(r)
    result=[]
    for case in read(root/'challenge'/'truth'/'cases.csv'):
        if smoke and case['pair_id']!='validation-01':continue
        key=case['case_id'];times=np.array([int(r['hour']) for r in grouped[key]])
        raw=base.copy();raw[times]=values(grouped[key])
        y=np.array([float(r['electricity_kwh']) if r['electricity_kwh'] else np.nan for r in targets[key]])
        result.append(dict(case=case,times=times,raw=raw,prepared=inputs(raw,times,preprocessing),y=y,
            concern=np.array([int(r['elder_concern_minutes'])>0 for r in labels[key]])))
    return result


def run(root,out,names,seeds,device,smoke=False):
    if out.exists():raise FileExistsError(f'Refusing to overwrite {out}')
    if root.resolve() in [out.resolve(),*out.resolve().parents]:raise ValueError('Training output must be outside the frozen dataset')
    data=load_data(root);cfg=config(smoke)
    cfg.update(models=names,seeds=seeds,device=device,dataset=str(root.resolve()),
        dataset_manifest_sha256=hashlib.sha256((root/'manifest.csv').read_bytes()).hexdigest(),
        python=platform.python_version(),numpy=np.__version__,sklearn=sklearn.__version__,joblib=joblib.__version__)
    if 'lstm' in names:
        import torch
        if device=='mps' and not torch.backends.mps.is_available():raise ValueError('MPS is unavailable; use --device cpu')
        cfg['torch']=torch.__version__
    train_times=training_times(data)
    if smoke:train_times=train_times[:256]
    preprocessing=fit_preprocessing(data['x'],train_times)
    train=inputs(data['x'],train_times,preprocessing)
    va,vb=data['split']['validation'];validation=np.arange(va,vb)
    early=validation[np.isfinite(data['y'][validation]) & (data['arrival'][validation]<=vb)]
    if smoke:early=early[:128]
    valid_input=inputs(data['x'],early,preprocessing)
    main_times=np.arange(va,va+48 if smoke else data['split']['test'][1])
    main_input=inputs(data['x'],main_times,preprocessing)
    challenges=load_challenges(root,data['x'],preprocessing,smoke)
    out.mkdir(parents=True);(out/'source').mkdir();(out/'models').mkdir()
    for name in ['train.py','evaluation.py','generate.py','validate.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    shutil.copy(root/'manifest.csv',out/'dataset_manifest.csv')
    write_csv(out/'config.csv',[dict(parameter=k,value=json.dumps(v) if isinstance(v,(list,dict)) else v) for k,v in cfg.items()])
    joblib.dump(preprocessing,out/'preprocessing.joblib')
    write_csv(out/'training_targets.csv',[dict(target_hour=int(t),
        target_available_at=(ORIGIN+timedelta(hours=float(data['arrival'][t]))).isoformat()) for t in train_times])
    forecasts=[];detectors=[];episodes=[];predictions=[];case_results=[];training=[];thresholds=[]
    started=time.monotonic()
    for name in names:
        for seed in ([seeds[0]] if name in ['ridge','seasonal_naive'] else seeds):
            print(f'Starting {name}, seed {seed}',flush=True)
            folder=out/'models'/f'{name}-{seed}';folder.mkdir()
            if name=='seasonal_naive':
                fitted=None;summary=dict(epochs=None,best_epoch=None,parameters=0,training_seconds=0.)
            else:
                fitted,summary=fit_model(name,seed,train,valid_input,data['y'][train_times],data['y'][early],cfg,folder,device)
            training.append(dict(model=name,seed=seed,training_targets=0 if name=='seasonal_naive' else len(train_times),**summary))
            valmask=main_times<vb
            estimate=np.full(len(main_times),np.nan)
            estimate[valmask]=predict(name,fitted,tuple(v[valmask] for v in main_input),
                                      data['x'],main_times[valmask],preprocessing,device)
            scores=shortfall(estimate[valmask],data['x'][main_times[valmask],ELECTRICITY])
            val_end=int(main_times[valmask][-1])+1
            threshold=select_threshold(main_times[valmask]+1,scores,in_boundary(data['episodes'],va,val_end),cfg['false_alert_budget_per_30_days'])
            thresholds.append(dict(model=name,seed=seed,threshold_kwh=threshold,selected_on='main validation only'))
            write_csv(folder/'threshold.csv',[thresholds[-1]])
            (folder/'threshold.csv').chmod(0o444)
            if (~valmask).any():
                estimate[~valmask]=predict(name,fitted,tuple(v[~valmask] for v in main_input),
                                           data['x'],main_times[~valmask],preprocessing,device)
            for part in ['validation','test']:
                a,b=data['split'][part];mask=(main_times>=a)&(main_times<b)
                if not mask.any():continue
                times=main_times[mask];pred=estimate[mask]
                forecasts.append(dict(model=name,seed=seed,replay='main',partition=part,
                    **forecast_metrics(pred,data['y'][times],data['concern'][times])))
                score=shortfall(pred,data['x'][times,ELECTRICITY])
                summary,events,flags=detection(times+1,score,threshold,in_boundary(data['episodes'],a,min(b,times[-1]+1)))
                detectors.append(dict(model=name,seed=seed,partition=part,threshold_kwh=threshold,**summary))
                episodes.extend(dict(model=name,seed=seed,partition=part,**r) for r in events)
                append_predictions(predictions,name,seed,'main',part,times,pred,data['y'][times],score,flags,data['concern'][times])
            for replay in challenges:
                case,times=replay['case'],replay['times']
                pred=predict(name,fitted,replay['prepared'],replay['raw'],times,preprocessing,device)
                score=shortfall(pred,replay['raw'][times,ELECTRICITY]);flags=np.isfinite(score)&(score>threshold)
                during=(times+1>=int(case['start_slot'])/4)&(times+1<int(case['end_slot'])/4)
                case_results.append(dict(model=name,seed=seed,case_id=case['case_id'],pair_id=case['pair_id'],
                    partition=case['partition'],scenario=case['scenario'],concern=int(case['concern']),
                    alarm_in_labelled_interval=int(flags[during].any()),observable=int(np.isfinite(score[during]).any()),
                    alarm_decisions=int(flags.sum()),**forecast_metrics(pred,replay['y'],replay['concern'])))
                append_predictions(predictions,name,seed,case['case_id'],case['partition'],times,pred,replay['y'],score,flags,replay['concern'])
            write_csv(out/'training.csv',training);write_csv(out/'forecast_metrics.csv',forecasts)
            write_csv(out/'detection_metrics.csv',detectors);write_csv(out/'thresholds.csv',thresholds)
            del fitted
            if name=='lstm' and device=='mps':torch.mps.empty_cache()
    write_csv(out/'predictions.csv',predictions)
    write_csv(out/'episode_results.csv',episodes,fields=['model','seed','partition','episode_id','start_hour','end_hour','detected','observable','delay_hours','duplicate_alerts'])
    write_csv(out/'challenge_results.csv',case_results)
    report(out,forecasts,detectors,case_results,training,smoke)
    write_csv(out/'completed.csv',[dict(fits=sum(r['model']!='seasonal_naive' for r in training),
        systems=len(training),seconds=time.monotonic()-started,smoke=smoke)])
    write_csv(out/'manifest.csv',[dict(file=str(p.relative_to(out)),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
        for p in sorted(out.rglob('*')) if p.is_file()])
    for p in out.rglob('*'):
        if p.is_file():p.chmod(0o444)
    print(f'Completed {out}',flush=True)


def append_predictions(rows,name,seed,case_id,part,times,pred,y,score,flags,concern):
    for i,t in enumerate(times):
        rows.append(dict(model=name,seed=seed,case_id=case_id,partition=part,target_hour=int(t),
            issued_time=(ORIGIN+timedelta(hours=int(t))).isoformat(),prediction_kwh=float(pred[i]),
            observed_kwh=float(y[i]) if np.isfinite(y[i]) else '',concern_label=int(concern[i]),
            shortfall_score_kwh=float(score[i]) if np.isfinite(score[i]) else '',alarm=int(flags[i])))


def report(out,forecasts,detectors,cases,training,smoke):
    part='validation' if smoke else 'test'
    lines=['# One-family algorithm comparison','',
        'SMOKE CHECK ONLY — no test scoring.' if smoke else 'Fixed algorithms and seeds; test results describe this one synthetic family only.',
        '', '## Forecasting','', 'All learned models use the same 336 × 18 hourly input values, explicit missing indicators and four target calendar encodings. Trees/ridge receive a flattened sequence; the LSTM receives the same sequence in time order. No labels or current-target observations enter features.', '',
        '| Model | Runs | MAE (Wh) | RMSE (Wh) | Mean training seconds |', '|---|---:|---:|---:|---:|']
    comparison=[]
    for name in dict.fromkeys(r['model'] for r in training):
        own=[r for r in forecasts if r['model']==name and r['partition']==part]
        fit=[r for r in training if r['model']==name]
        mae=np.mean([r['mae_wh'] for r in own]);rmse=np.mean([r['rmse_wh'] for r in own])
        seconds=np.mean([r['training_seconds'] for r in fit])
        comparison.append(dict(model=name,runs=len(own),partition=part,mae_wh=mae,rmse_wh=rmse,training_seconds=seconds))
        lines.append(f'| {name} | {len(own)} | {mae:.2f} | {rmse:.2f} | {seconds:.2f} |')
    write_csv(out/'comparison.csv',comparison)
    lines+=['','Deterministic ridge and seasonal-naive run once; stochastic algorithms use every requested seed. No best test seed is selected. Seasonal-naive uses the available snapshot one week earlier, with a training-only median fallback, so all systems score the same observed targets.','',
        '## Exploratory inactivity alarms','',
        'A positive electricity shortfall averaged over three completed, timely observed hours triggers an alarm. Thresholds maximise main validation episode recall subject to at most one false alert per 30 days; ties prefer fewer false alerts then the higher threshold. An infinite threshold means no feasible threshold improved recall. Contiguous flags form one alert; a matching decision must occur during the concern, not after it ends. Outage-related misses stay in recall.','',
        '| Model | Main recall | False alerts / 30 days | Coverage | Challenge recall | Challenge F1 |', '|---|---:|---:|---:|---:|---:|']
    for name in dict.fromkeys(r['model'] for r in training):
        own=[r for r in detectors if r['model']==name and r['partition']==part]
        replay=[r for r in cases if r['model']==name and r['partition']==part]
        per_seed=[]
        for seed in dict.fromkeys(r['seed'] for r in replay):
            seed_rows=[r for r in replay if r['seed']==seed]
            tp=sum(r['concern'] and r['alarm_in_labelled_interval'] for r in seed_rows)
            fp=sum(not r['concern'] and r['alarm_in_labelled_interval'] for r in seed_rows)
            fn=sum(r['concern'] and not r['alarm_in_labelled_interval'] for r in seed_rows)
            per_seed.append((tp/(tp+fn) if tp+fn else 0,2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0))
        recall=[r['recall'] for r in own if r['recall'] is not None]
        main=f'{np.mean(recall):.1%}' if recall else 'not estimable'
        lines.append(f'| {name} | {main} | {np.mean([r["false_alerts_per_30_days"] for r in own]):.2f} | {np.mean([r["coverage"] for r in own]):.1%} | {np.mean([r[0] for r in per_seed]):.1%} | {np.mean([r[1] for r in per_seed]):.3f} |')
    lines+=['','Challenge F1 uses one decision per labelled case interval; paired cases are alternatives and are never concatenated. It cannot estimate real-world precision. These are electricity-residual alarms, not a trained medical or person-state classifier. The main test has only two concerns and the challenge test has twelve positive cases. Family activity can completely mask older-adult inactivity. Detection conclusions are preliminary; forecast accuracy does not establish detection reliability.','',
        '## Reuse','',
        '`config.csv`, `training_targets.csv`, `dataset_manifest.csv`, frozen `source/`, per-run model files and `preprocessing.joblib` preserve the fit. `predictions.csv`, `forecast_metrics.csv`, `detection_metrics.csv`, `episode_results.csv` and `challenge_results.csv` are reviewable CSVs. Only load model files you trust. No dashboard integration, model promotion or notification changes are made.','',
        'Fixed model settings are an initial benchmark, not a hyperparameter search. No population confidence intervals are claimed for one household.']
    (out/'report.md').write_text('\n'.join(lines)+'\n')
    if not smoke:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(9,4.5),layout='constrained')
        for i,row in enumerate(comparison):
            ax.bar(i,row['mae_wh'],color='#397f91',width=.6)
            seed_values=[r['mae_wh'] for r in forecasts if r['model']==row['model'] and r['partition']=='test']
            ax.scatter(np.linspace(i-.1,i+.1,len(seed_values)),seed_values,color='#252525',s=22,zorder=3)
        ax.set(title='One synthetic family · next-hour electricity forecast',ylabel='Test MAE (Wh)',
               xticks=np.arange(len(comparison)),xticklabels=[r['model'].replace('_','\n') for r in comparison],
               xlabel='Bars: seed means · dots: individual runs · lower is better')
        ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
        fig.savefig(out/'comparison.png',dpi=170);plt.close(fig)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data',type=Path,default=Path(__file__).with_name('data'))
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--models',nargs='+',choices=MODELS,default=MODELS)
    parser.add_argument('--seeds',nargs='+',type=int,default=[11,22,33])
    parser.add_argument('--device',choices=['cpu','mps'],default='cpu')
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    if len(set(args.models))!=len(args.models) or len(set(args.seeds))!=len(args.seeds):parser.error('Duplicate models or seeds')
    if any(seed<0 or seed>=2**32 for seed in args.seeds):parser.error('Seeds must be unsigned 32-bit integers')
    with threadpool_limits(limits=4):
        run(args.data,args.out,args.models,args.seeds,args.device,args.smoke)
