"""Frozen challenge extension and decision-time replay for the same family.

Run `prepare` before `run`. CSV truth is used only for annotation and scoring.
The original year's observations, model weights and results are never rewritten.
"""
import argparse
import hashlib
import platform
import shutil
from collections import defaultdict
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import IsolationForest

if __package__:
    from . import generate as g
    from .validate import read, validate_dataset
    from .train import values, inputs, predict, small_lstm, hour_number
    from .paper_alarms import schedule, window_alarm, verify_run, stamp
    from .evaluation import detection
else:
    import generate as g
    from validate import read, validate_dataset
    from train import values, inputs, predict, small_lstm, hour_number
    from paper_alarms import schedule, window_alarm, verify_run, stamp
    from evaluation import detection

SEED = 20261024
GRACE = .5
CONTEXTS = ['family_active', 'elder_alone', 'appliances_running', 'visitors',
            'weak_context', 'electricity_outage', 'delayed_upload', 'benign_absence']
DAYPARTS = [('night', 0), ('morning', 8), ('afternoon', 13), ('evening', 18)]
ROUTINES = ['missed_breakfast', 'delayed_breakfast', 'missed_lunch', 'delayed_lunch', 'night_awake']
FEATURES = ['hour_sin', 'hour_cos', 'weekday_sin', 'weekday_cos',
            'electricity_3h', 'water_3h', 'electricity_24h', 'water_24h',
            'elder_event_age_hours', 'elder_app_count_24h', 'elder_gate_count_24h',
            'other_activity_count_3h', 'electricity_coverage_3h', 'water_coverage_3h',
            'gate_coverage_24h', 'elder_app_coverage_24h']


def manifest(root):
    g.write_csv(root/'manifest.csv', [dict(file=str(p.relative_to(root)),
        sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*'))
        if p.is_file() and p.name != 'manifest.csv' and '__pycache__' not in p.parts])
    for p in root.rglob('*'):
        if p.is_file(): p.chmod(0o444)


def verify(root):
    rows = read(root/'manifest.csv')
    actual = {str(p.relative_to(root)) for p in root.rglob('*')
              if p.is_file() and p.name != 'manifest.csv' and '__pycache__' not in p.parts}
    if actual != {r['file'] for r in rows} or len(actual) != len(rows):
        raise ValueError('Manifest inventory mismatch')
    for r in rows:
        p = (root/r['file']).resolve()
        if root.resolve() not in p.parents or hashlib.sha256(p.read_bytes()).hexdigest() != r['sha256']:
            raise ValueError('Manifest checksum mismatch: '+r['file'])


def fresh_output(out, *sources):
    if out.exists(): raise FileExistsError(f'Refusing to overwrite {out}')
    if any(s.resolve() in [out.resolve(), *out.resolve().parents] for s in sources):
        raise ValueError('Output must be outside frozen inputs')
    out.mkdir(parents=True)


def plan_cases(states, smoke=False):
    """Freeze interventions using resident routines, never meter readings or predictions."""
    rng = np.random.default_rng(SEED)
    plans = []
    specifications = [('elder', c, part, hour) for c in CONTEXTS
                      for part, hour in DAYPARTS for _ in range(2)]
    specifications += [('household', c, 'night' if c == 'night_awake' else 'meal', 0)
                       for c in ROUTINES for _ in range(4)]
    if smoke:
        specifications = [specifications[2], specifications[-1]]
    for i, (target, kind, part, hour) in enumerate(specifications):
        # The original test has been reviewed. These are fresh conditional replays,
        # not a new calendar year, household, or population sample.
        candidates = [d for d in range(295, 364)
                      if not np.any(states[0, (d-1)*96:(d+1)*96] == 'unable')]
        day = int(rng.choice(candidates))
        start = day*96 + hour*4 + (int(rng.integers(0, 2)) if target == 'elder' else 0)
        end = start + int(rng.integers(12, 21))
        activity = 'sleep' if kind == 'night_awake' else 'breakfast' if 'breakfast' in kind else 'lunch'
        for positive in [0, 1]:
            plans.append(dict(case_id=f'v2-{i+1:03}-{positive}', pair_id=f'v2-{i+1:03}',
                partition='smoke' if smoke else 'fresh_challenge', label_target=target, scenario=kind,
                daypart=part, seed=SEED+100+i, day=day, replay_start_slot=(day-1)*96,
                replay_end_slot=(day+1)*96, start_slot=start, end_slot=end,
                elder_concern_label=positive if target == 'elder' else 0,
                household_routine_label=positive if target == 'household' else '',
                labelled_activity=activity if target == 'household' else '',
                intervention=positive, label_basis='planned resident activity; independent of observations'))
    return plans


def intervene(plan, states, visitor, arrivals):
    s, v = states.copy(), visitor.copy()
    delivery = {k: a.copy() for k, a in arrivals.items()}
    extra = np.zeros(g.SLOTS)
    a, b, day = plan['start_slot'], plan['end_slot'], plan['day']
    kind, positive = plan['scenario'], plan['intervention']
    if plan['label_target'] == 'elder':
        s[1:, a:b] = 'away' if kind == 'elder_alone' else ('asleep' if plan['daypart'] == 'night' else 'leisure')
        if kind == 'family_active':
            s[1:, a:b] = 'leisure'
            s[1, a+2:a+5] = 'cooking'
            s[2, a+8:a+9] = 'personal_care'
        s[0, a:b] = 'unable' if positive else ('asleep' if plan['daypart'] == 'night' else 'quiet')
        if kind == 'benign_absence' and not positive: s[0, a:b] = 'away'
        if kind == 'appliances_running': extra[a:b] = .18
        if kind == 'visitors': v[a:b] = True
        if kind == 'weak_context':
            for source in ['water', 'elder_app']: delivery[source][a:b] = np.inf
        if kind == 'electricity_outage': delivery['electricity'][a:b] = np.inf
        if kind == 'delayed_upload':
            for source in g.SOURCES:
                delivery[source][a:b] = np.maximum(delivery[source][a:b], np.arange(a+1, b+1)+2)
    elif kind == 'night_awake':
        a, b = day*96+8, day*96+20
        s[:, day*96:day*96+24] = 'asleep'
        if positive:
            s[1:3, a:b] = 'leisure'
            s[1, a+1:a+3] = 'cooking'
    else:
        breakfast = 'breakfast' in kind
        a, b = day*96+(24 if breakfast else 44), day*96+(44 if breakfast else 64)
        # Common meal plan for both alternatives; modifications happen in state truth.
        meal = a+(6 if breakfast else 7)
        block = s[:, a:b]
        block[np.isin(block, ['eating', 'cooking'])] = 'leisure'
        when = b+2 if positive and kind.startswith('delayed') else meal
        if not positive or kind.startswith('delayed'):
            s[0, when:when+3] = 'eating'
            s[1, when-2:when+1] = 'cooking'
    return s, v, delivery, extra


def prepare(base, out, smoke=False):
    validate_dataset(base, write_result=False)
    fresh_output(out, base)
    state_rows = read(base/'truth/resident_activity_15min.csv')
    states = np.array([[r[p+'_state'] for r in state_rows]
                       for p in ['E1', 'A1', 'A2', 'C1', 'C2']])
    visitor = np.array([int(r['visitor_present']) for r in state_rows], bool)
    plans = plan_cases(states, smoke)
    g.write_csv(out/'config.csv', [dict(parameter=k, value=v) for k, v in dict(
        version='family-elder-evaluation-v2', seed=SEED, smoke=smoke, grace_hours=GRACE,
        base=str(base.resolve()), base_manifest_sha256=hashlib.sha256((base/'manifest.csv').read_bytes()).hexdigest(),
        ordinary_year='unchanged; original test is development evidence',
        challenge='paired conditional alternatives of the same family; enriched, not prevalence',
        forecast='reuse LSTM seeds 11,22,33; original issue-time inputs and weights',
        detector='IsolationForest 200 trees max_samples 256 random_state 44; benign training only',
        threshold='main validation recall at <=1 false alert per30days; ties fewer false then higher threshold',
        imputation='training medians and explicit missing flags; incomplete current utilities/context abstain',
        routine_labels='separate preplanned missed/delayed meals and nighttime wakefulness; not elder concern',
        hourly_features='past24h values available at fixed completed-hour+30min; no future activity',
        paper='same3windows with current-window population error sigma; all observations available at end+30min',
        attribution='only meaningful verified elder events suppress; simulated verification is an assumption'
    ).items()])
    g.write_csv(out/'truth/cases.csv', plans)
    for p in [out/'config.csv', out/'truth/cases.csv']: p.chmod(0o444)
    shutil.copy(base/'manifest.csv', out/'base_manifest.csv')
    (out/'source').mkdir()
    for name in ['evaluation_v2.py', 'generate.py']:
        shutil.copy(Path(__file__).with_name(name), out/'source'/name)
    tables = defaultdict(list)
    for i, plan in enumerate(plans):
        arrivals, _ = g.delivery(plan['seed'])
        s, v, arrivals, extra = intervene(plan, states, visitor, arrivals)
        observed = g.observe(s, v, arrivals, plan['seed'], extra)
        rows = g.rows_for(observed, s, v, plan['replay_start_slot'], plan['replay_end_slot'], plan['case_id'])
        for name, result in rows.items(): tables[name].extend(result)
        if (i+1) % 16 == 0: print(f'Prepared {i+1}/{len(plans)} cases', flush=True)
    for name, rows in tables.items():
        target = out/'truth' if name in ['labels_hourly', 'resident_activity_15min'] else out
        g.write_csv(target/(name+'.csv'), rows)
    g.write_csv(out/'feature_allowlist.csv', [dict(column=c) for c in g.FEATURE_COLUMNS])
    g.write_csv(out/'elder_feature_allowlist.csv', [dict(column=c) for c in FEATURES])
    counts = dict(cases=len(plans), elder_positive=sum(p['elder_concern_label'] for p in plans),
                  household_positive=sum(p['household_routine_label'] == 1 for p in plans),
                  ordinary_year_new_concerns=0)
    g.write_csv(out/'summary.csv', [counts])
    manifest(out)
    validate_extension(base, out)
    print(f'Frozen {out}: {counts}', flush=True)


def load_observations(raw, events, base=None, start=None, end=None):
    if base is None:
        data = dict(values={k: np.full(g.SLOTS, np.nan) for k in ['electricity', 'water']},
                    arrivals={k: np.full(g.SLOTS, np.inf) for k in g.SOURCES}, events=[])
    else:
        data = dict(values={k: a.copy() for k, a in base['values'].items()},
                    arrivals={k: a.copy() for k, a in base['arrivals'].items()},
                    events=[e for e in base['events'] if not start <= e['event_slot'] < end])
    for r in raw:
        slot = int(r['slot'])
        for source, unit in [('electricity', 'kwh'), ('water', 'litres')]:
            data['values'][source][slot] = float(r[source+'_'+unit]) if r[source+'_'+unit] else np.nan
        for source in g.SOURCES:
            data['arrivals'][source][slot] = hour_number(r[source+'_received_at'])*4
    data['events'].extend(dict(source=r['source'], event_slot=hour_number(r['event_time'])*4,
        received_slot=hour_number(r['received_at'])*4, event_type=r['event_type'],
        claimed_resident_id=r['claimed_resident_id'], attribution=r['attribution'], meaningful=int(r['meaningful']))
        for r in events)
    data['events'].sort(key=lambda e: e['event_slot'])
    g.index_events(data)
    return data


def validate_extension(base, root):
    verify(root)
    if (base/'manifest.csv').read_bytes() != (root/'base_manifest.csv').read_bytes():
        raise ValueError('Base dataset mismatch')
    cases = read(root/'truth/cases.csv')
    hours, raw, truth = defaultdict(list), defaultdict(list), defaultdict(list)
    for r in read(root/'hourly.csv'): hours[r['case_id']].append(r)
    for r in read(root/'observations_15min.csv'): raw[r['case_id']].append(r)
    for r in read(root/'truth/resident_activity_15min.csv'): truth[r['case_id']].append(r)
    pairs = defaultdict(list)
    for c in cases:
        cid = c['case_id']; pairs[c['pair_id']].append(c)
        a, b = int(c['replay_start_slot']), int(c['replay_end_slot'])
        assert len(hours[cid]) == 48 and len(raw[cid]) == len(truth[cid]) == 192
        assert [int(r['slot']) for r in raw[cid]] == list(range(a, b))
        assert [int(r['hour']) for r in hours[cid]] == list(range(a//4, b//4))
        unable = sum(r['E1_state'] == 'unable' for r in truth[cid])
        assert unable == (int(c['end_slot'])-int(c['start_slot']))*int(c['elder_concern_label'])
        assert not set(['elder_concern_label', 'household_routine_label', 'scenario']) & set(hours[cid][0])
        for r in raw[cid]:
            for source in g.SOURCES:
                if r[source+'_received_at']:
                    assert hour_number(r[source+'_received_at'])*4 >= int(r['slot'])+1
        for h in hours[cid]:
            quarter = raw[cid][(int(h['hour'])*4-a):(int(h['hour'])*4-a+4)]
            for source, unit in [('electricity', 'kwh'), ('water', 'litres')]:
                column = source+'_'+unit
                observed = [r for r in quarter if r[column] and r[source+'_received_at']
                            and hour_number(r[source+'_received_at']) <= int(h['hour'])+1]
                assert float(h[source+'_observed_fraction']) == len(observed)/4
                if len(observed) == 4:
                    assert abs(float(h[column])-sum(float(r[column]) for r in observed)) < 1e-6
                else:
                    assert h[column] == ''
        if c['label_target'] == 'household':
            day = int(c['day']); positive = int(c['intervention'])
            if c['scenario'] == 'night_awake':
                block = [r for r in truth[cid] if day*96 <= int(r['slot']) < day*96+24]
                assert any(r['A1_state'] != 'asleep' for r in block) == bool(positive)
            else:
                a_meal, b_meal = (24, 44) if c['labelled_activity'] == 'breakfast' else (44, 64)
                block = [r for r in truth[cid] if day*96+a_meal <= int(r['slot']) < day*96+b_meal]
                assert any(r[p+'_state'] in ['eating', 'cooking'] for r in block
                           for p in ['E1', 'A1', 'A2', 'C1', 'C2']) == (not positive)
    assert all(len(p) == 2 and {c['intervention'] for c in p} == {'0', '1'} for p in pairs.values())
    return len(cases)


def elder_features(data, end_hour):
    """End is the latest completed hour; grace never admits activity after it."""
    cut = (end_hour+GRACE)*4
    ids = np.arange((end_hour-24)*4, end_hour*4)
    recent = ids[-12:]
    known = {k: (data['arrivals'][k][ids] <= cut) for k in g.SOURCES}
    sums = []
    for slots in [recent, ids]:
        for k in ['electricity', 'water']:
            v = data['values'][k][slots]
            valid = np.isfinite(v) & (data['arrivals'][k][slots] <= cut)
            sums.append(float(v.sum()) if valid.all() else np.nan)
    events = [e for h in range(end_hour-24, end_hour) for e in data['events_by_hour'].get(h, [])
              if e['received_slot'] <= cut and e['attribution'] == 'verified' and e['meaningful']]
    elder = [e for e in events if e['claimed_resident_id'] == 'E1']
    age = min([end_hour-e['event_slot']/4 for e in elder], default=24.)
    complete_context = known['gate'].mean() >= .9 and known['elder_app'].mean() >= .9
    # Lack of events during a missing feed is not evidence of resident inactivity.
    if not complete_context: age = np.nan
    hour, day = end_hour % 24, (end_hour//24+g.ORIGIN.weekday()) % 7
    x = [np.sin(hour*np.pi/12), np.cos(hour*np.pi/12), np.sin(day*2*np.pi/7), np.cos(day*2*np.pi/7),
         *sums, age, sum(e['source'] == 'app' for e in elder) if complete_context else np.nan,
         sum(e['source'] == 'gate' for e in elder) if complete_context else np.nan,
         sum(e['claimed_resident_id'] != 'E1' and e['event_slot'] >= (end_hour-3)*4 for e in events),
         known['electricity'][-12:].mean(), known['water'][-12:].mean(),
         known['gate'].mean(), known['elder_app'].mean()]
    eligible = (np.isfinite(sums[:2]).all() and complete_context
                and known['gate'][-12:].all() and known['elder_app'][-12:].all())
    recent_elder = any(e['event_slot'] >= (end_hour-1)*4 for e in elder)
    return np.array(x), bool(eligible), recent_elder


def feature_matrix(data, ends):
    rows = [elder_features(data, int(h)) for h in ends]
    return np.array([r[0] for r in rows]), np.array([r[1] for r in rows]), np.array([r[2] for r in rows])


def transform(x, median):
    return np.column_stack((np.where(np.isfinite(x), x, median), ~np.isfinite(x)))


def scores_for(model, median, features):
    x, eligible, recent_elder = features
    scores = -model.score_samples(transform(x, median))
    scores[recent_elder] = 0.
    scores[~eligible] = np.nan
    return scores


def select_threshold(ends, scores, episodes, trace=None):
    best, key = np.inf, (-1, -np.inf, -np.inf)
    for t in np.r_[np.inf, np.unique(scores[np.isfinite(scores)])]:
        summary, _, _ = detection(ends+GRACE, scores, t, decision_episodes(episodes, GRACE), include_onset=False)
        if trace is not None:
            trace.append(dict(threshold=float(t), detected_episodes=summary['detected_episodes'],
                recall=summary['recall'], false_alerts=summary['false_alerts'],
                false_alerts_per_30_days=summary['false_alerts_per_30_days']))
        if summary['false_alerts_per_30_days'] <= 1+1e-12:
            candidate = (summary['detected_episodes'], -summary['false_alerts'], t)
            if candidate > key: best, key = float(t), candidate
    return best


def paper_decisions(data, forecasts, start, end, grace=GRACE):
    result = []
    for w in schedule(start, end):
        a, b = w['start_hour'], w['end_hour_exclusive']
        observation = [g.hour_row(data, h, (b+grace)*4)['electricity_kwh'] for h in range(a, b)]
        result.append(dict(**w, decision_hour=b+grace, decision_time=stamp(b+grace),
            **window_alarm([forecasts[h] for h in range(a, b)],
                           [float(v) if v != '' else np.nan for v in observation], w['direction'], w['multiplier'])))
    return result


def paper_scores(windows, start, end):
    result = np.full(end-start, np.nan)
    for w in windows:
        if w['eligible']: result[w['end_hour_exclusive']-start-1] = w['alarm']
    return result


def evaluate(case, system, seed, start, end, scores, threshold, episodes, scheduled, grace=GRACE):
    # Matching also requires post-onset data. With quarter-hour onsets and 30-min
    # grace, remove pre-onset decisions from each episode's eligibility and hits.
    adjusted = decision_episodes(episodes, grace)
    summary, events, flags = detection(np.arange(start+1, end+1)+grace, scores, threshold,
                                       adjusted, include_onset=False)
    for row, original in zip(events, episodes):
        if row['delay_hours'] is not None: row['delay_hours'] += row['start_hour']-original['start']
        row['start_hour'] = original['start']
    delays = [r['delay_hours'] for r in events if r['detected']]
    summary.update(median_delay_hours=float(np.median(delays)) if delays else None,
        p90_delay_hours=float(np.percentile(delays, 90)) if delays else None,
        scheduled_decisions=scheduled, scheduled_coverage=int(np.isfinite(scores).sum())/scheduled,
        case_id=case, system=system, seed=seed)
    return summary, [dict(case_id=case, system=system, seed=seed, **r) for r in events], flags


def decision_episodes(episodes, grace):
    return [dict(e, start=max(e['start'], np.floor(e['start'])+grace)) for e in episodes]


def grouped(root, name):
    result = defaultdict(list)
    for r in read(root/(name+'.csv')): result[r['case_id']].append(r)
    return result


def run(base, extension, forecasts, out, device='cpu'):
    import torch
    validate_dataset(base, write_result=False)
    validate_extension(base, extension)
    verify_run(forecasts, base)
    fresh_output(out, base, extension, forecasts)
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    smoke = dict((r['parameter'], r['value']) for r in read(extension/'config.csv'))['smoke'] == 'True'
    shutil.copy(extension/'config.csv', out/'config.csv')
    for name, root in [('base', base), ('extension', extension), ('forecasts', forecasts)]:
        shutil.copy(root/'manifest.csv', out/(name+'_manifest.csv'))
    (out/'source').mkdir()
    for name in ['evaluation_v2.py', 'evaluation.py', 'paper_alarms.py', 'generate.py', 'train.py', 'validate.py']:
        shutil.copy(Path(__file__).with_name(name), out/'source'/name)
    observation = load_observations(read(base/'observations_15min.csv'), read(base/'events.csv'))
    episodes = [dict(id=r['episode_id'], start=int(r['start_slot'])/4, end=int(r['end_slot'])/4)
                for r in read(base/'truth/episodes.csv') if r['concern_label'] == '1']
    ends = np.arange(337, 8761)
    features = feature_matrix(observation, ends)
    clean = (ends+GRACE <= 5256)
    for e in episodes: clean &= ~((ends > e['start']) & (ends-24 < e['end']))
    fit = features[0][clean]
    median = np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0 for c in fit.T])
    model = IsolationForest(n_estimators=200, max_samples=256, random_state=44, n_jobs=4)
    model.fit(transform(fit, median))
    joblib.dump(dict(model=model, median=median, features=FEATURES), out/'elder_detector.joblib', compress=3)
    g.write_csv(out/'training_hours.csv', [dict(end_hour=int(h), decision_time=stamp(h+GRACE)) for h in ends[clean]])
    scores = scores_for(model, median, features)
    val = (ends > 5256) & (ends <= 7008)
    val_ep = [e for e in episodes if e['start'] >= 5256 and e['end'] <= 7008]
    calibration = []
    threshold = select_threshold(ends[val], scores[val], val_ep, calibration)
    g.write_csv(out/'validation_thresholds.csv', calibration)
    g.write_csv(out/'threshold.csv', [dict(system='hourly_elder_iforest', threshold=threshold,
        calibration='main validation only; original test and fresh challenge excluded', false_alert_budget_per_30_days=1)])
    (out/'threshold.csv').chmod(0o444)
    print(f'Fitted hourly detector on {len(fit)} benign training hours; frozen threshold={threshold}', flush=True)
    pre = joblib.load(forecasts/'preprocessing.joblib')
    models = {}
    for seed in [11, 22, 33]:
        checkpoint = torch.load(forecasts/f'models/lstm-{seed}/model.pt', map_location='cpu', weights_only=True)
        network = small_lstm(checkpoint['channels']).to(device)
        network.load_state_dict(checkpoint['state_dict'])
        models[seed] = dict(model=network, target_mean=checkpoint['target_mean'], target_scale=checkpoint['target_scale'])
    main_predictions = defaultdict(dict)
    for r in read(forecasts/'predictions.csv'):
        if r['case_id'] == 'main' and r['model'] == 'lstm':
            main_predictions[int(r['seed'])][int(r['target_hour'])] = float(r['prediction_kwh'])
    metrics, results, decisions, windows, predictions, challenge = [], [], [], [], [], []
    feature_rows = []
    def record_features(cid, hours, features):
        for h, x, eligible, recent in zip(hours, *features):
            feature_rows.append(dict(case_id=cid, completed_hour=int(h), decision_time=stamp(h+GRACE),
                eligible=int(eligible), recent_verified_elder=int(recent),
                **{k: float(v) if np.isfinite(v) else '' for k, v in zip(FEATURES, x)}))
    record_features('main', ends, features)
    def record(cid, start, end, obs, predicted, own_scores, eps, plan=None):
        systems = [('hourly_elder_iforest', 44, own_scores, threshold, end-start)]
        for seed, pred in predicted.items():
            own = paper_decisions(obs, pred, start, end)
            windows.extend(dict(case_id=cid, system='paper_lstm', seed=seed, **w) for w in own)
            systems.append(('paper_lstm', seed, paper_scores(own, start, end), .5, len(own)))
        for system, seed, s, t, scheduled in systems:
            summary, events, flags = evaluate(cid, system, seed, start, end, s, t, eps, scheduled)
            metrics.append(summary); results.extend(events)
            decisions.extend(dict(case_id=cid, system=system, seed=seed, completed_hour=h,
                decision_time=stamp(h+GRACE), score=float(value) if np.isfinite(value) else '',
                eligible=int(np.isfinite(value)), alarm=int(flag))
                for h, value, flag in zip(range(start+1, end+1), s, flags))
            if plan is not None:
                a, b = int(plan['start_slot'])/4, int(plan['end_slot'])/4
                completed = np.arange(start+1, end+1)
                during = (completed > a) & (completed+GRACE < b)
                challenge.append(dict(case_id=cid, pair_id=plan['pair_id'], system=system, seed=seed,
                    label_target=plan['label_target'], scenario=plan['scenario'], daypart=plan['daypart'],
                    elder_concern_label=plan['elder_concern_label'], household_routine_label=plan['household_routine_label'],
                    observable=int(np.any(during & np.isfinite(s))),
                    alarm_in_labelled_interval=int(np.any(during & flags)),
                    delay_hours=events[0]['delay_hours'] if events else '',
                    routine_window_alarm='', routine_window_observable=''))
                if plan['label_target'] == 'household' and system == 'paper_lstm':
                    w = next(w for w in windows if w['case_id'] == cid and w['seed'] == seed
                        and w['activity'] == plan['labelled_activity'] and w['start_hour']//24 == int(plan['day']))
                    challenge[-1].update(routine_window_alarm=int(w['alarm'] == 1), routine_window_observable=w['eligible'])
    for part, a, b in [('validation', 5256, 7008), ('reviewed_test', 7008, 8760)]:
        if smoke and part == 'reviewed_test': continue
        ids = (ends > a) & (ends <= b)
        record('main_'+part, a, b, observation, main_predictions, scores[ids],
               [e for e in episodes if e['start'] >= a and e['end'] <= b])
        predictions.extend(dict(case_id='main_'+part, seed=seed, target_hour=h, issued_time=stamp(h), prediction_kwh=pred[h])
                           for seed, pred in main_predictions.items() for h in range(a, b))
    raw = grouped(extension, 'observations_15min')
    events = grouped(extension, 'events')
    hourly = grouped(extension, 'hourly')
    base_x = values(read(base/'hourly.csv'))
    plans = read(extension/'truth/cases.csv')
    for i, plan in enumerate(plans):
        cid = plan['case_id']; a, b = int(plan['replay_start_slot'])//4, int(plan['replay_end_slot'])//4
        obs = load_observations(raw[cid], events[cid], observation, a*4, b*4)
        x = base_x.copy(); x[a:b] = values(hourly[cid])
        times = np.arange(a, b); prepared = inputs(x, times, pre)
        predicted = {seed: dict(zip(times, predict('lstm', model, prepared, x, times, pre, device)))
                     for seed, model in models.items()}
        predictions.extend(dict(case_id=cid, seed=seed, target_hour=int(h), issued_time=stamp(h), prediction_kwh=float(v))
                           for seed, pp in predicted.items() for h, v in pp.items())
        own_features = feature_matrix(obs, times+1)
        record_features(cid, times+1, own_features)
        own_scores = scores_for(model, median, own_features)
        eps = [dict(id=cid, start=int(plan['start_slot'])/4, end=int(plan['end_slot'])/4)] if plan['elder_concern_label'] == '1' else []
        record(cid, a, b, obs, predicted, own_scores, eps, plan)
        if (i+1) % 16 == 0: print(f'Scored {i+1}/{len(plans)} cases', flush=True)
    for name, rows in [('metrics', metrics), ('episode_results', results), ('decisions', decisions),
                       ('activity_windows', windows), ('predictions', predictions), ('challenge_results', challenge)]:
        g.write_csv(out/(name+'.csv'), rows)
    g.write_csv(out/'elder_features.csv', feature_rows)
    summarize(out, metrics, challenge, smoke)
    g.write_csv(out/'completed.csv', [dict(smoke=smoke, new_fits=1, reused_forecasters=3, challenge_cases=len(plans),
        device=device, python=platform.python_version(), numpy=np.__version__, torch=torch.__version__,
        sklearn=sklearn.__version__, joblib=joblib.__version__)])
    manifest(out)
    print(f'Completed {out}', flush=True)


def summarize(out, metrics, cases, smoke):
    comparison = []
    for target in ['elder', 'household']:
        systems = ['paper_lstm', 'hourly_elder_iforest'] if target == 'elder' else ['paper_lstm']
        for system in systems:
            for seed in sorted({r['seed'] for r in cases if r['system'] == system}):
                own = [r for r in cases if r['system'] == system and r['seed'] == seed and r['label_target'] == target]
                for stratum in ['all'] + sorted({r['scenario'] for r in own}) + (['daypart:'+p for p, _ in DAYPARTS] if target == 'elder' else []):
                    rows = [r for r in own if stratum == 'all' or r['scenario'] == stratum or 'daypart:'+r['daypart'] == stratum]
                    label = 'elder_concern_label' if target == 'elder' else 'household_routine_label'
                    alarm = 'alarm_in_labelled_interval' if target == 'elder' else 'routine_window_alarm'
                    coverage = 'observable' if target == 'elder' else 'routine_window_observable'
                    tp = sum(int(r[label]) and r[alarm] == 1 for r in rows)
                    fp = sum(not int(r[label]) and r[alarm] == 1 for r in rows)
                    positives = sum(int(r[label]) for r in rows)
                    negatives = len(rows)-positives
                    delays = [float(r['delay_hours']) for r in rows if int(r[label]) and r[alarm] == 1 and r['delay_hours'] not in ('', None)]
                    comparison.append(dict(target=target, system=system, seed=seed, stratum=stratum,
                        cases=len(rows), positives=positives, negatives=negatives, true_positives=tp, false_positives=fp,
                        recall=tp/positives if positives else '', precision=tp/(tp+fp) if tp+fp else '',
                        f1=2*tp/(positives+tp+fp) if positives else '',
                        benign_case_false_positive_rate=fp/negatives if negatives else '',
                        observable_positives=sum(int(r[label]) and r[coverage] == 1 for r in rows),
                        case_coverage=np.mean([r[coverage] for r in rows]) if rows else '',
                        median_delay_hours=np.median(delays) if delays else '',
                        p90_delay_hours=np.percentile(delays, 90) if delays else ''))
    g.write_csv(out/'comparison.csv', comparison)
    main = [r for r in metrics if r['case_id'] == ('main_validation' if smoke else 'main_reviewed_test')]
    lines = ['# Family evaluation v2', '', 'Smoke run; not final evidence.' if smoke else
        'The ordinary year and prior runs are unchanged. The original test is now reviewed development evidence. The fresh challenge was frozen before evaluation.', '',
        '## Ordinary-year elder concerns', '', '| System | Seed | Detected | False alerts / 30 days | Scheduled coverage |',
        '|---|---:|---:|---:|---:|']
    for r in main:
        lines.append(f"| {r['system']} | {r['seed']} | {r['detected_episodes']}/{r['episodes']} | {r['false_alerts_per_30_days']:.2f} | {r['scheduled_coverage']:.1%} |")
    lines += ['', '## Fresh paired challenge', '', '| Target | System | Seed | Detected | Benign false alarms | Coverage |', '|---|---|---:|---:|---:|---:|']
    for r in comparison:
        if r['stratum'] == 'all':
            lines.append(f"| {r['target']} | {r['system']} | {r['seed']} | {r['true_positives']}/{r['positives']} | {r['false_positives']}/{r['negatives']} | {r['case_coverage']:.1%} |")
    lines += ['', '## Interpretation and limits', '',
        'Paper alarms target household routines; the hourly Isolation Forest targets unusual patterns in elder-linked activity and utilities. Its anomaly score is not an emergency probability. Read each target separately; household routine changes are not elder emergencies.', '',
        'A fixed 30-minute delay permits only readings received by that decision. No activity from the next hour is used. Forecasts retain their original issue-time inputs. Paper thresholds remain 3σ for meals and 1σ for sleep using population error spread within that window; this is an explicit interpretation of the paper, not an exact architecture reproduction.', '',
        'The detector is fitted to benign training hours with training-only median imputation and missing flags. Recent meaningful verified elder activity suppresses a candidate. Missing current utilities or poor context coverage causes abstention. Its threshold maximises validation episode recall within one false alert per 30 days. Infinity is an honest no-alert result, not a successful detector.', '',
        'Challenge recall includes outages and all positive cases; comparison.csv also gives observable counts, scenario/daypart results and delays. Challenge benign false-positive rate is per labelled case, not an operational monthly alert rate. metrics.csv contains full 48-hour replay alerts and repeat counts. No population confidence interval is claimed for alternative replays of one family.', '',
        'The challenge contains matched quiet/sleep/absence alternatives, active family, appliances, visitors and missing/late feeds. Aggregate utility patterns intentionally overlap. Verification of resident identity remains a simulation assumption. Six ordinary-year concerns are unchanged; challenge frequency is deliberately enriched, not a real emergency estimate.', '',
        'Use truth/cases.csv and truth/resident_activity_15min.csv in the extension to review labels; use decisions.csv, activity_windows.csv and episode_results.csv to inspect misses. No labels enter model features. Neither synthetic results nor the paper establish safety for an older adult living with a family.', '',
        'Next evidence needed: an independently observed resident-linked signal and real, consented routine annotations. Further tuning on this challenge would turn it into development data and require a new final evaluation.', '']
    (out/'report.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'run', 'validate'])
    parser.add_argument('--base', type=Path, default=Path('ml/household/data'))
    parser.add_argument('--data', type=Path, default=Path('ml/household/data_v2'))
    parser.add_argument('--forecasts', type=Path, default=Path('ml/household/runs/compare-20261022'))
    parser.add_argument('--out', type=Path, default=Path('ml/household/runs/evaluation-v2-20261022'))
    parser.add_argument('--device', choices=['cpu', 'mps'], default='cpu')
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    if args.action == 'prepare': prepare(args.base, args.data, args.smoke)
    elif args.action == 'validate': print(f'Validated {validate_extension(args.base, args.data)} cases')
    else: run(args.base, args.data, args.forecasts, args.out, args.device)
