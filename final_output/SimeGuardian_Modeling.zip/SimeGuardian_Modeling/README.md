# SimeGuardian · final modeling package

**Final study: usage forecasting, anomaly detection and emergency validation.**

| Evaluation | Precision | Recall including unavailable positives as misses | F1 including those misses |
|---|---:|---:|---:|
| All three fresh test replays |93.75%|88.24%|90.91%|
| Selected worked example:20261108 |96.15%|92.59%|94.34%|

The same fitted emergency model is used across all test seeds. The worked example was selected after evaluation for detailed charts; aggregate results include all three test replays. Across all test replays,29/30 daytime emergency episodes are detected. Grouped-alert precision is74.36%, with1.37 false alert groups per30 household-days.

**Simulation scope:** one family household with an older adult, daytime6–9h emergencies, hourly08:00–21:00 elder check-ins,99.5% healthy response adherence and no forgotten-phone days. Brief and nighttime emergencies are outside the evaluated scope. Real-world reliability remains untested.

## Open the two notebooks

1. **01_usage_forecasting.ipynb** — four independent seasonal residual LSTMs, data preparation, own-source inputs/masks, model architecture, real training curves, checkpoint loading, measured-versus-predicted plots, MAE/RMSE and normalized errors.
2. **02_anomaly_emergency_detection.ipynb** — separate learned usage-anomaly and emergency classifiers, family-label definitions, actual deterministic refitting, calibration, training progression, precision–recall curves, TP/FP/TN/FN, episode validation and selected example timeline.

Both notebooks are already executed and contain their tables/plots. Default execution refits the two selected small classifiers and verifies saved predictions; full LSTM retraining is optional and explicitly disabled by default. The recorded LSTM epoch curves are the actual completed training logs.

No Jupyter installed? Open the self-contained static previews under **html/**. Editable plotting code remains in the notebooks and code/study_tools.py. Eleven figures are also supplied as PNG and PDF under **figures/**. No internet access or cloud account is required to run the analysis after installing dependencies; the research-paper links require internet.

## Folder map

- `datasets/study/` — all nine final simulation datasets, grouped by seed, with raw15min measurements, hourly snapshots/targets, event/arrival times, independent family reviews and separate simulator truth.
- `datasets/training/` — source-initialization seed20261028 plus twelve source/utility-detector development/calibration simulations; required to trace fitted weights and refit the utility classifier.
- `datasets/catalog.csv` — all22 datasets and their roles; they are stochastic replays of one family archetype, not22 households.
- `datasets/data_dictionary.csv` — table and column guide. All tabular datasets/results are CSV; `.ipynb` is the standard notebook container, not a JSON dataset.
- `models/forecast_seasonal/` — separate own-source fine-tuned LSTMs, preprocessing, training configuration and epoch logs.
- `models/forecast_gate_mse/` — the gate MSE model, all three seeds.
- `models/forecast_base/` — source-initialization checkpoints and the base LSTM component used in gate blending. The two active classifiers are the top-level model files below.
- `models/emergency_detector.joblib` — final emergency model, threshold and99 feature names.
- `models/usage_anomaly_detector.joblib` — utility anomaly model, threshold and93 feature names.
- `models/forecast_mixing.csv` — final source blending weights and residual scales.
- `models/model_catalog.csv` — selected checkpoints, role and parameter counts.
- `results/study/` — completed final run, predictions, feature snapshots, training-label provenance, thresholds, confusion matrices and episode audits.
- `results/usage_detector/` — utility-detector training/selection evidence and input features.
- `results/notebook_metrics/` — metrics recomputed by the executed notebooks, including supplementary usage-anomaly results on the study test replays.
- `reports/` — detailed study review and concise model cards.
- `references/` — the paper citation, primary URLs and an explanation of inspiration versus implementation.
- `code/` — portable notebook computations and preserved study source. Archived CLI configurations retain their source paths for traceability; **use the notebooks for portable replay/refitting**.
- `requirements.txt`, `environment.csv` — exact dependency versions used for execution. Tested with Python3.10.11; CPU execution works, MPS was used for source-model fitting.
- `manifest.csv`, `verify_package.py`, `validation.csv` — delivered-file checksums and validation evidence.

## Run locally

Extract the ZIP to a normal writable folder. In that folder:

```sh
python3 verify_package.py
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m pip install jupyterlab
python3 -m jupyter lab
```

Open notebook01, then02, and run cells from top to bottom. Alternatively:

```sh
python3 -m jupyter nbconvert --execute --to notebook --inplace 01_usage_forecasting.ipynb
python3 -m jupyter nbconvert --execute --to notebook --inplace 02_anomaly_emergency_detection.ipynb
```

Use only the trusted model files shipped here: joblib/pickle models are executable Python artifacts. No application API, notification workflow or deployment is included. Full optional source retraining writes new `retraining/` folders and refuses to overwrite completed runs. Checksum verification authenticates the delivered files; rerunning notebooks changes their saved outputs and therefore their file checksums, while unchanged data/model checksums remain valid.

## Research basis and limits

Hernández et al. (2024), *Detection of Anomalies in Daily Activities Using Data from Smart Meters*, Sensors24(2),515, https://doi.org/10.3390/s24020515. The forecast-then-deviation idea inspired the study. Our separate LSTMs, gradient boosting, multiple sources, family labels and stated check-in protocol are our own implementation choices, not an exact reproduction or comparable replication of the paper's experiment.

The utility detector is a separate target: on the same test replays its model achieves89.02% precision and79.35% recall including positive abstentions. The emergency headline does not describe every model or every alert unit. Sparse gate forecasts have high errors relative to mean event frequency. Only30 final test emergency episodes and one family archetype were studied. Real-world performance and prospective99.5% check-in adherence remain untested.
