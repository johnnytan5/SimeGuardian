# Selected model details

## Phase1: independent usage forecasting

Four own-source seasonal residual LSTMs, each32 recurrent units,16 dense ReLU units and one output. Inputs: previous336h of one source's value/availability with missing masks, calendar sin/cos and10 own-source seasonal/lag features. Seasonal model parameter count5633; base LSTM component5473. Retain seeds11/22/33 and average; no best test training seed is selected. Gate blends0.8 seasonal +0.2 base LSTM, electricity/water/app use1.0 fine. Units: electricity kWh, water litres, gate/app verified meaningful event count per hour.

Source initialization dataset:20261028. Source fine-tuning:20261029–31, target hours336–2880, early-stop2880–3600. Training-only medians/scales, timely confirmed-normal targets, histories can include earlier anomalies. Losses: Huber β0.25 electricity/app, MAE+0.5MSE water, MSE gate training. Adam0.0005, weight_decay0.0001, batch256, max25epochs, patience4, clip gradient1; select validation MAE+0.1RMSE. Warm start: Adam0.001, MSE, batch128,30epochs, patience5. All preprocessing, weights, actual epoch logs and source data are included.

The fitted source weights are evaluated on the held-out study snapshots. Error denominators retain all observed source targets. Gate activity is sparse and has high relative forecast error. Normalised errors are percentages of mean actual demand, not bounded accuracy percentages.

## Phase2A: confirmed unusual usage

HistGradientBoostingClassifier, max_iter180, learning_rate0.05, max_leaf_nodes31, min_samples_leaf15, l2_regularization2, natural weights, early_stopping=False, random_state44.93 features. Trained on nine simulation development replays; calibrated on32–34. Frozen raw-score threshold0.43051023522936244. Selected through validation precision constraints. The notebook refits this selected setting and verifies it against supplied weights; it uses the stated fixed training configuration.

## Phase2B: family-confirmed need for assistance

HistGradientBoostingClassifier, max_iter180, learning_rate0.05, max_leaf_nodes7, min_samples_leaf15, l2_regularization5, balanced classes, early_stopping=False, random_state44.99 features:93 source residual/activity/calendar/mask features plus6 hourly check-in opportunity/count/coverage features. Development20261101–03, calibration04–06, test07–09. Train only eligible known family labels available by development cutoff7008. Calibration/test confirmations available retrospectively through8832 are evaluation labels, never inputs.

Threshold0.9876543443370072 maximises specificity among choices meeting at least90% calibration recall including unavailable positives as misses, with ties to higher threshold. No test tuning. Outputs are classifier scores, not clinically calibrated probabilities.

Final all-test counts: TP75,FP5,TN1225,FN9 on covered labels, plus1 positive abstention counted as a miss.430 unknown intervals remain excluded;7 additional negative abstentions do not become TN. Primary recall75/85=88.24%, precision75/80=93.75%, F1 including unavailable-positive miss150/165=90.91%. Standard covered-label recall89.29% and F1=91.46% are separately retained.29/30 episodes detected,10 unmatched groups among39 alerts, grouped-alert precision74.36%, false groups1.37/30 household-days.

## Applicability

Synthetic one-family archetype with reliable hourly daytime check-ins. Brief and nighttime emergencies are outside the evaluated scope. No automatic emergency dispatch, real-world validation, model promotion or notification deployment is part of this package. The40/30/15/15 source weights are heuristic context, not learned importance percentages.
