"""V5: explicit check-in agreement, adjudicated family diaries, enriched training cases."""
import numpy as np

if __package__:
    from . import generate as g, electricity_dataset as electric
else:
    import generate as g
    import electricity_dataset as electric

SEED = 20261028
CHECKIN_HOURS = [9, 14, 20]
# These are protocol settings, not fitted to test observations or labels.
SETTINGS = dict(version='multisource-two-stage-v5', seed=SEED,
    detector='histogram gradient boosting; no raw calendar shortcuts; explicit overdue check-in context',
    feedback='85% independent daily retrospective diaries plus85% family case reports;90% response;96% confident adjudication; ambiguous unknown',
    prevalence='68 unexpected utility interventions and44 assistance episodes; enriched training/evaluation, not real incidence',
    checkin_agreement='E1 at09/14/20;1h response grace;6% independent misses;2% forgotten-phone days; asleep may miss; missing feed is unknown',
    labels='positive if at least1h of confirmed event in3h interval; negative if none; smaller boundary overlap unknown; no random high-confidence flips',
    limitations='brief/night emergencies and benign missed check-ins intentionally overlap; household utility cannot identify an individual',
    seed_policy='new seed fixed before fitting; development uses validation only; test scored after frozen thresholds')


def make_data(seed=SEED):
    states, visitor = electric.routines(seed)
    rng = np.random.default_rng(seed+200)
    plans, emergencies = [], []
    kinds = ['appliance_left_on','excess_cooling','partial_circuit_loss',
             'unplanned_power_cut','running_tap','water_interruption','missed_usual_meal']
    occupied=set()
    blocks=[('forecast_fit',16,119,12,6),('forecast_early_stop',121,149,4,2),
            ('detector_fit',151,218,24,16),('validation',221,291,14,10),('test',294,364,14,10)]
    for part,first,last,nusage,nemergency in blocks:
        days=list(range(first,last-1));rng.shuffle(days)
        for i in range(nemergency):
            kind='brief_night' if i%5==0 else 'brief_day' if i%5==1 else 'prolonged_inactivity'
            hour=0 if kind=='brief_night' else 11 if kind=='brief_day' else int(rng.choice([7,12,17]))
            duration=int(rng.integers(4,7)) if kind=='brief_night' else int(rng.integers(3,6)) if kind=='brief_day' else int(rng.integers(14,21))
            candidates=[d for d in days if d not in occupied and d+1 not in occupied and states[0,d*96+hour*4]!='away']
            if not candidates:raise ValueError('Cannot place assistance episode')
            day=candidates[0];a=day*96+hour*4;b=a+duration*4
            occupied.update(range(a//96,(b-1)//96+1))
            states[0,a:b]='unable'
            emergencies.append(dict(episode_id=f'assistance-{part}-{i+1}',start_slot=a,end_slot=b,
                partition=part,target_resident_id='E1',kind=kind,
                label_basis='family timeline of assistance need; not generated from a detector score'))
        usable=[d for d in days if d not in occupied]
        if len(usable)<nusage+2:raise ValueError('Cannot place utility events and hard negatives')
        for i,day in enumerate(usable[:nusage]):
            kind=kinds[i%len(kinds)]
            hour=int(rng.choice([6,7,18,19])) if kind in ['water_interruption','missed_usual_meal'] else int(rng.integers(0,19))
            duration=int(rng.integers(5,10))
            if kind=='missed_usual_meal':duration=4
            a=day*96+hour*4;b=min((day+1)*96,a+duration*4)
            plans.append(dict(scenario_id=f'utility-{part}-{i+1}',kind=kind,partition=part,
                start_slot=a,end_slot=b,unexpected_usage=1,strength=float(rng.uniform(.8,1.2)),
                label_basis='physical appliance/tap/supply change; independent of residual threshold'))
        for day,kind in zip(usable[nusage:nusage+2],['expected_guests','planned_meal_out']):
            plans.append(dict(scenario_id=f'expected-{part}-{day}',kind=kind,partition=part,
                start_slot=day*96+72,end_slot=day*96+92,unexpected_usage=0,strength=1.,
                label_basis='planned family activity; observably overlaps some anomalies'))
    electricity,components,usage,_=electric.physical_use(states,visitor,plans,seed)
    arrivals,incidents=electric.delivery(seed)
    data=g.observe(states,visitor,arrivals,seed)
    data['values']['electricity']=(electricity*(1+rng.normal(0,.01,g.SLOTS))).round(6)
    data['values']['electricity'][~np.isfinite(arrivals['electricity'])]=np.nan
    for p in plans:
        a,b=p['start_slot'],p['end_slot']
        if p['kind']=='running_tap':data['values']['water'][a:b]+=18*p['strength']
        elif p['kind']=='water_interruption':data['values']['water'][a:b]*=.1
    emergency=np.zeros(g.SLOTS,int)
    for p in emergencies:emergency[p['start_slot']:p['end_slot']]=1
    # A reminder can wake a napping resident; asleep, offline and forgotten phones remain ambiguous.
    for day in range(365):
        forgotten=rng.random()<.02
        for hour in CHECKIN_HOURS:
            slot=day*96+hour*4+int(rng.integers(0,4))
            if forgotten or rng.random()<.06 or states[0,slot] in ['unable','asleep']:continue
            received=arrivals['elder_app'][slot]
            if np.isfinite(received):
                data['events'].append(dict(source='app',event_slot=slot+.2,received_slot=received,
                    event_type='agreed_self_checkin',claimed_resident_id='E1',attribution='verified',meaningful=1))
    data['events'].sort(key=lambda e:e['event_slot']);g.index_events(data)
    return data,states,visitor,usage,emergency,plans,emergencies,incidents,components


def app_reviews(data,usage,emergency,seed=SEED):
    rng=np.random.default_rng(seed+201);diary=rng.random(365)<.85;rows=[]
    for end in range(339,8761,3):
        start=end-3;a,b=start*4,end*4;day=start//24
        case_report=(usage[a:b].any() or emergency[a:b].any()) and rng.random()<.85
        if not (diary[day] or case_report):continue
        respond=rng.random()<.90;high=respond and rng.random()<.96
        submitted=max(end+.5,(day+1)*24)+float(rng.choice([1,8,24,48])) if respond else np.inf
        row=dict(review_id=f'diary-{len(rows)+1:04}',reviewer_resident_id=str(rng.choice(['A1','A2'])),
            start_hour=start,end_hour_exclusive=end,requested_at=g.timestamp((end+.5)*4),
            submitted_at=g.timestamp(submitted*4),confidence='high' if high else 'low' if respond else '',
            request_reason='independent_daily_diary' if diary[day] else 'family_case_report',
            evidence='simulated_adjudicated_family_timeline' if high else 'insufficient_confirmation',simulated=1)
        for name,oracle in [('usage_anomaly',usage),('emergency',emergency)]:
            count=int(oracle[a:b].sum());label=''
            if high and (count==0 or count>=4):label=int(count>=4)
            row[name+'_label']=label
            row[name+'_available_at']=g.timestamp(submitted*4) if label!='' else ''
        rows.append(row)
    return rows


FEATURES = [s+'_'+k for s in ['electricity','water','gate','app'] for k in ['shortfall','excess','available']]
FEATURES += ['gate_elder_age','gate_age_missing','app_elder_age','app_age_missing','weighted_error',
             'missed_checkins','consecutive_missed_checkins','checkin_context_available','elder_activity_since_due']


def checkin_context(end,observed,arrivals,events):
    """Known agreement + arrived ordinary events, never family confirmation or oracle states."""
    cut=end+.5
    due=[d*24+h for d in range(max(0,(end-24)//24),end//24+1) for h in CHECKIN_HOURS
         if end-24<=d*24+h and d*24+h+1<=end]
    records=[];activity=[]
    for start in due:
        # A missing heartbeat during the response window cannot prove a missed response.
        known=np.isfinite(observed[start,3]) and arrivals[start,3]<=cut
        found=[e for h in range(start,end) for e in events.get(h,[]) if e['source']=='app'
               and e['resident']=='E1' and e['verified'] and e['meaningful'] and e['arrival']<=cut
               and start<=e['time']<min(start+1,end) and e.get('kind')=='agreed_self_checkin']
        records.append(None if not known else int(not found))
    recent=[e for h in range(due[-1] if due else end,end) for e in events.get(h,[])
            if e['source'] in ['app','gate'] and e['resident']=='E1' and e['verified'] and e['meaningful']
            and e['arrival']<=cut and e['time']<end]
    consecutive=0
    for r in reversed(records):
        if r!=1:break
        consecutive+=1
    return [sum(r==1 for r in records),consecutive,float(bool(records) and all(r is not None for r in records)),float(bool(recent))]


def detector_features(ends,forecast,observed,arrivals,events,scales):
    if __package__:from .two_stage import detector_features as original
    else:from two_stage import detector_features as original
    x,eligible,weighted=original(ends,forecast,observed,arrivals,events,scales)
    context=np.array([checkin_context(int(end),observed,arrivals,events) for end in ends])
    # Raw hour/weekday are removed: a few case dates otherwise become calendar shortcuts.
    return np.column_stack((x[:,:17],context)),eligible,weighted
