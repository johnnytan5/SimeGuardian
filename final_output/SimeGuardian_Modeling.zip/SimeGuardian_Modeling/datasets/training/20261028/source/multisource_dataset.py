"""Four activity sources, with family confirmation labels kept outside the features."""
import argparse
import shutil
from pathlib import Path

import numpy as np

if __package__:
    from . import generate as g
    from . import electricity_dataset as electric
    from .validate import read
    from .train import hour_number
    from .evaluation_v2 import fresh_output, manifest, verify
else:
    import generate as g
    import electricity_dataset as electric
    from validate import read
    from train import hour_number
    from evaluation_v2 import fresh_output, manifest, verify

SEED = 20261027
SOURCES = ['electricity', 'water', 'gate', 'app']
WEIGHTS = dict(electricity=.4, water=.3, gate=.15, app=.15)
LABELS = ['usage_anomaly', 'emergency']
SPLITS = [('history', 0, 336), ('forecast_fit', 336, 2880), ('forecast_early_stop', 2880, 3600),
          ('detector_fit', 3600, 5256), ('validation', 5256, 7008), ('test', 7008, 8760)]


def source_value(row, source):
    if source in ['electricity', 'water']:
        return row[source+('_kwh' if source == 'electricity' else '_litres')]
    counts = [row[source+'_elder_verified_count'], row[source+'_other_verified_count']]
    return sum(float(v) for v in counts) if all(v != '' for v in counts) else ''


def make_data(seed=SEED):
    states, visitor = electric.routines(seed)
    plans = electric.scenario_plan(seed)
    rng = np.random.default_rng(seed+100)
    occupied = {p['start_slot']//96 for p in plans}
    water_plans, emergencies = [], []
    for part, first, last, water_count, emergency_count in [('train', 20, 215, 8, 12),
            ('validation', 223, 288, 2, 6), ('test', 297, 360, 2, 6)]:
        days = [d for d in range(first, last) if d not in occupied and d+1 not in occupied]
        rng.shuffle(days)
        for i in range(water_count):
            day = days.pop(); occupied.add(day)
            a = day*96+40; b = a+int(rng.integers(16, 33))
            water_plans.append(dict(scenario_id=f'water-{part}-{i+1}', kind='running_tap' if i % 2 == 0 else 'water_interruption',
                partition=part, start_slot=a, end_slot=b, unexpected_usage=1, strength=float(rng.uniform(.8, 1.2)),
                label_basis='planned water event, independent of observed residuals'))
        for i in range(emergency_count):
            hour = [0, 8, 13, 18][i % 4]
            candidates = [d for d in days if d not in occupied and d+1 not in occupied
                          and states[0, d*96+hour*4] != 'away']
            if not candidates: raise ValueError('Cannot place independent emergency scenario')
            day = candidates[0]; days.remove(day); occupied.update([day, day+1])
            a = day*96+hour*4; b = a+int(rng.integers(24, 49))
            states[0, a:b] = 'unable'
            emergencies.append(dict(episode_id=f'assistance-{part}-{i+1}', start_slot=a, end_slot=b,
                partition=part, target_resident_id='E1', kind='simulated_inability_requiring_assistance',
                label_basis='resident-state intervention; family-confirmed assistance, not a clinical diagnosis'))
    electricity, components, usage, _ = electric.physical_use(states, visitor, plans, seed)
    arrivals, incidents = electric.delivery(seed)
    data = g.observe(states, visitor, arrivals, seed)
    data['values']['electricity'] = (electricity*(1+rng.normal(0, .01, g.SLOTS))).round(6)
    data['values']['electricity'][~np.isfinite(arrivals['electricity'])] = np.nan
    for p in water_plans:
        a,b=p['start_slot'],p['end_slot']
        if p['kind'] == 'running_tap': data['values']['water'][a:b] += 18*p['strength']
        else: data['values']['water'][a:b] *= .1
        usage[a:b] = 1
    emergency = np.zeros(g.SLOTS, int)
    for p in emergencies: emergency[p['start_slot']:p['end_slot']] = 1
    # Agreed check-ins are ordinary self activity. Family review submissions below
    # are a separate table and never create forecast input events.
    for day in range(365):
        for hour in [9, 14, 20]:
            slot = day*96+hour*4+int(rng.integers(0, 3))
            if states[0, slot] in ['unable', 'asleep', 'nap'] or rng.random() < .08: continue
            received = arrivals['elder_app'][slot]
            if not np.isfinite(received): continue
            data['events'].append(dict(source='app', event_slot=slot+.2, received_slot=received,
                event_type='agreed_self_checkin', claimed_resident_id='E1', attribution='verified', meaningful=1))
    data['events'].sort(key=lambda e:e['event_slot']); g.index_events(data)
    return data, states, visitor, usage, emergency, plans+water_plans, emergencies, incidents, components


def app_reviews(data, usage, emergency, seed=SEED):
    rng = np.random.default_rng(seed+101)
    rows=[]
    for end in range(339, 8761, 3):
        start=end-3; a,b=start*4,end*4
        audit = rng.random() < .25
        family_report = (emergency[a:b].any() and rng.random() < .75) or rng.random() < .01
        current=[g.hour_row(data,h,(end+.5)*4) for h in range(start,end)]
        past=[g.hour_row(data,h-168,(end+.5)*4) for h in range(start,end)]
        deviation=False
        for source, minimum in [('electricity',1.),('water',60.)]:
            now=[source_value(r,source) for r in current]; old=[source_value(r,source) for r in past]
            if all(v!='' for v in now+old): deviation |= abs(sum(now)-sum(old)) > minimum
        if not (audit or family_report or deviation): continue
        respond=rng.random()<.9; high=respond and rng.random()<.94
        submitted=end+.5+float(rng.choice([.5,2,8,24,48])) if respond else np.inf
        row=dict(review_id=f'family-{len(rows)+1:04}', reviewer_resident_id=str(rng.choice(['A1','A2'])),
            start_hour=start, end_hour_exclusive=end, requested_at=g.timestamp((end+.5)*4),
            submitted_at=g.timestamp(submitted*4), confidence='high' if high else 'low' if respond else '',
            request_reason='random_audit' if audit else 'family_initiated_report' if family_report else 'usage_deviation_review',
            evidence='simulated_direct_family_confirmation' if high else 'insufficient_confirmation', simulated=1)
        for name, oracle in [('usage_anomaly',usage),('emergency',emergency)]:
            block=oracle[a:b]; label=''
            if high and (block.all() or not block.any()):
                label=int(block.all())
                if name=='usage_anomaly' and emergency[a:b].any() and not block.any(): label=''
                if name=='usage_anomaly' and label!='' and rng.random()<.015:label=1-label
            row[name+'_label']=label
            row[name+'_available_at']=g.timestamp(submitted*4) if label!='' else ''
        rows.append(row)
    return rows


def confirmed_hours(reviews, cutoff):
    result={name:np.full(8760,np.nan) for name in LABELS}
    for r in reviews:
        a,b=int(r['start_hour']),int(r['end_hour_exclusive'])
        for name in LABELS:
            if r[name+'_label']!='' and hour_number(r[name+'_available_at'])<=cutoff:
                if np.isfinite(result[name][a:b]).any():raise ValueError('Overlapping confirmations require adjudication')
                result[name][a:b]=int(r[name+'_label'])
    return result


def build(out, revised=False):
    fresh_output(out)
    cfg=dict(version='multisource-two-stage-v4', seed=SEED, sources=','.join(SOURCES),
        objective='independent source forecasts; usage-anomaly and emergency confirmation evaluated separately',
        forecasting='four independent LSTMs; own source value/coverage plus calendar;336h history; seeds11,22,33',
        detector='two logistic classifiers on out-of-sample source residuals, availability, elder event recency and calendar',
        expected_weights='electricity0.40 water0.30 gate0.15 app0.15; heuristic fixed-fusion baseline, not validated importance',
        app_features='ordinary meaningful verified activity including agreed self check-ins; feedback and background sync excluded',
        app_labels='separate family reviews; two independent labels; unknown is unlabelled; delayed availability respected',
        assistance_definition='family-confirmed need for assistance during simulated inability; no specific clinical diagnosis',
        prevalence='48 usage-event interventions plus24 assistance episodes; deliberately enriched simulation',
        split='forecast_fit15-120; early_stop121-150; detector_fit151-219; validation220-292; test293-365',
        unit='hourly forecasts; nonoverlapping3h detection decisions at completed interval+30min',
        threshold='validation F1, ties fewer FP then higher threshold; frozen before test; no claimed monthly alert budget',
        unavailable='source observation requires complete3h data received by decision; abstain if available prior weight<0.7',
        feedback='random25%3h audits plus deviations and family-initiated reports; simulation only')
    if revised:
        if __package__:from . import revised_protocol as protocol
        else:import revised_protocol as protocol
        cfg.update(protocol.SETTINGS)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in cfg.items()]);(out/'config.csv').chmod(0o444)
    data,states,visitor,usage,emergency,plans,emergencies,incidents,components=protocol.make_data() if revised else make_data()
    tables=g.rows_for(data,states,visitor,0,g.SLOTS)
    for name in ['observations_15min','hourly','events']:
        g.write_csv(out/(name+'.csv'),tables[name])
    targets=[]
    for h in range(8760):
        row=dict(hour=h,start_time=g.timestamp(h*4))
        for source in SOURCES:
            feeds=[source,'elder_app'] if source=='app' else [source]
            arrivals=np.array([data['arrivals'][f][h*4:h*4+4] for f in feeds])
            valid=np.isfinite(arrivals).all()
            cutoff=float(arrivals.max()) if valid else (h+1)*4
            value=source_value(g.hour_row(data,h,max((h+1)*4,cutoff)),source) if valid else ''
            row[source]=value;row[source+'_available_at']=g.timestamp(cutoff) if value!='' else ''
        targets.append(row)
    g.write_csv(out/'targets_hourly.csv',targets)
    g.write_csv(out/'app_reviews.csv',protocol.app_reviews(data,usage,emergency) if revised else app_reviews(data,usage,emergency))
    g.write_csv(out/'truth/usage_scenarios.csv',plans)
    g.write_csv(out/'truth/assistance_episodes.csv',emergencies)
    g.write_csv(out/'truth/resident_activity_15min.csv',tables['resident_activity_15min'])
    g.write_csv(out/'truth/sensor_incidents.csv',incidents)
    g.write_csv(out/'truth/labels_15min.csv',[dict(slot=s,usage_anomaly=int(usage[s]),emergency=int(emergency[s])) for s in range(g.SLOTS)])
    g.write_csv(out/'splits.csv',[dict(partition=n,start_hour=a,end_hour_exclusive=b) for n,a,b in SPLITS])
    g.write_csv(out/'source_contract.csv',[dict(source=s,expected_weight=WEIGHTS[s],
        units='kWh' if s=='electricity' else 'litres' if s=='water' else 'verified_meaningful_event_count',
        forecast_inputs='own completed source value and availability; calendar',labels_are_features=0) for s in SOURCES])
    g.write_csv(out/'summary.csv',[dict(households=1,hourly_rows=8760,usage_interventions=len(plans),
        unexpected_usage_interventions=sum(p['unexpected_usage'] for p in plans),assistance_episodes=len(emergencies),
        usage_hours=float(usage.sum()/4),assistance_hours=float(emergency.sum()/4),test_scored=0)])
    (out/'source').mkdir()
    for name in ['revised_protocol.py','multisource_dataset.py','electricity_dataset.py','generate.py','evaluation_v2.py','train.py','validate.py','paper_alarms.py','evaluation.py']:
        shutil.copy(Path(__file__).with_name(name),out/'source'/name)
    manifest(out);validate(out)
    print(f'Frozen {out}',flush=True)


def validate(root):
    verify(root)
    hours,targets=read(root/'hourly.csv'),read(root/'targets_hourly.csv')
    assert len(hours)==len(targets)==8760
    for h,r in enumerate(hours):
        assert int(r['hour'])==h and hour_number(r['issued_time'])==h+1
        for s in SOURCES:
            value=source_value(r,s);t=targets[h]
            if value!='':assert abs(float(value)-float(t[s]))<1e-6 and hour_number(t[s+'_available_at'])<=h+1
            if t[s]!='':assert hour_number(t[s+'_available_at'])>=h+1
    for r in read(root/'app_reviews.csv'):
        assert int(r['end_hour_exclusive'])-int(r['start_hour'])==3
        assert hour_number(r['requested_at'])==int(r['end_hour_exclusive'])+.5
        assert hour_number(r['submitted_at'])>hour_number(r['requested_at'])
        for label in LABELS:
            if r[label+'_label']!='':assert r['confidence']=='high' and r[label+'_available_at']==r['submitted_at']
    confirmed_hours(read(root/'app_reviews.csv'),np.inf)
    assert all(r['event_type'] not in ['family_review','feedback'] for r in read(root/'events.csv'))
    print('PASS: source contract, snapshots, target availability and independent feedback labels',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['generate','validate'])
    parser.add_argument('--data',type=Path,default=Path('ml/household/multisource_data_v4'))
    parser.add_argument('--revised',action='store_true',help='Generate v5 protocol; choose a new --data path')
    args=parser.parse_args()
    if args.action=='generate':build(args.data,args.revised)
    else:validate(args.data)
