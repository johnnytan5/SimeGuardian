# Independent forecasts and two detection targets

Final test replay. Thresholds were selected on validation and frozen before test prediction.

Part 1 uses four independent LSTMs. Each sees only its own source values/availability and calendar; each predicts its own next-hour value. All three seeds are averaged for the second stage, with each seed also reported separately.

| Source | Ensemble MAE | Weekly-baseline MAE | Unit |
|---|---:|---:|---|
| electricity | 0.1431 | 0.1631 | kWh |
| water | 16.0971 | 14.6722 | litres |
| gate | 0.1641 | 0.1170 | event_count |
| app | 0.4374 | 0.3811 | event_count |

Part 2 combines normalized forecast deviations with source availability, resident-linked gate/app recency and check-in deadlines. Separate gradient boosting classifiers learn unusual-usage and emergency labels from delayed family confirmations. Detector training predictions occur after all forecaster fitting/early stopping; no in-sample residuals train the detector.

| Target | System | TP | FP | TN | FN | Unlabelled | Labelled abstentions |
|---|---|---:|---:|---:|---:|---:|---:|
| usage_anomaly | learned_detector | 17 | 13 | 408 | 13 | 132 | 1 |
| usage_anomaly | weighted_baseline | 13 | 4 | 417 | 17 | 132 | 1 |
| usage_anomaly | without_checkin_context | 16 | 8 | 413 | 14 | 132 | 1 |
| emergency | learned_detector | 29 | 26 | 388 | 8 | 132 | 1 |
| emergency | weighted_baseline | 37 | 413 | 1 | 0 | 132 | 1 |
| emergency | without_checkin_context | 20 | 38 | 376 | 17 | 132 | 1 |

TP/FP/TN/FN use one nonoverlapping three-hour reviewed interval, not individual samples or alert episodes. Unknown/unconfirmed intervals are excluded, not counted as TN. Abstentions are outside the four cells and separately reported; confusion_matrices.csv also reports recall counting abstained positives as misses.

The initial weights are electricity40%, water30%, gate15%, app15%. They are heuristic priors for the fixed weighted baseline, applied after source-specific residual scaling. The learned detectors can change the effective influence; feature_coefficients.csv exposes logistic coefficients where applicable. Neither the prior percentages nor balanced-class classifier outputs are calibrated emergency probabilities.

Ordinary verified app activity and agreed self-check-ins are features. Family feedback responses, their timing, review-selection reasons and labels are never features. A usage anomaly is not automatically an emergency; the two family questions and classifiers are independent. Missing sources never create a zero reading or a confirmation.

Thresholds maximise validation F1, with fewer FP then higher threshold breaking ties. This does not impose a one-alert-per-month operating budget. Reviews are selectively collected after deviations or family reports as well as random audits, so these confusion matrices do not estimate population-wide accuracy. Few confirmed positive episodes and correlated intervals limit the evidence.

oracle_episode_metrics.csv separately audits all in-boundary simulated episodes, including unreviewed and outage-related misses, false alerts per30days, delays and duplicates. Oracle labels are excluded from fitting, scaling and threshold selection. All data, family reports and emergencies are synthetic; the assistance label is not a clinical diagnosis or proof of deployable safety.

All original datasets/runs are preserved. See expected_weights.csv, source_contract.csv in the dataset, per-seed forecast_metrics.csv, threshold records and per-decision CSVs for review.

V5 changes: more confirmed training cases; adjudicated family timelines instead of arbitrary high-confidence flips; known09/14/20 check-in deadlines with1h grace; no raw detector calendar inputs. The no-check-in ablation uses the identical data, labels, forecasters and boosting settings. Independent missing checks, forgotten-phone days, night/brief emergencies, family masking and outages remain.

V4 and V5 use different simulated years and collection assumptions: their metrics are descriptive, not a controlled estimate of algorithm improvement. V5 events are deliberately enriched (68 usage events and44 assistance episodes/year); precision must not be extrapolated to real emergency prevalence. Tree splits are invariant to positive feature scaling, so40/30/15/15 applies to the fixed baseline and is not enforced learned importance. oracle_scenario_metrics.csv shows brief/night versus prolonged assistance and each utility mechanism.
