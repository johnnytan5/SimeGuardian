"""Fine-tune separate source LSTMs with past-only seasonal skip connections."""
import argparse
import shutil
import time
from pathlib import Path

import joblib
import numpy as np

if __package__:
    from . import generate as g
    from .multisource_dataset import SOURCES,confirmed_hours
    from .two_stage import source_inputs
    from .precision_study import load_forecasters
    from .train import fit_preprocessing,inputs,predict,hour_number
    from .validate import read
    from .evaluation_v2 import fresh_output,manifest,verify
else:
    import generate as g
    from multisource_dataset import SOURCES,confirmed_hours
    from two_stage import source_inputs
    from precision_study import load_forecasters
    from train import fit_preprocessing,inputs,predict,hour_number
    from validate import read
    from evaluation_v2 import fresh_output,manifest,verify

DEV_SEEDS=[20261029,20261030,20261031]
CONTEXT=['lag1','lag2','lag3','lag24','lag168','same_hour_mean14d','same_hour_median14d',
         'same_daytype_mean14d','same_hour_std14d','same_hour_coverage14d']


def seasonal(raw,times,pre):
    """Every constituent is an as-issued own-source snapshot strictly before target."""
    times=np.asarray(times,int)
    if np.any(times<336) or np.any(times>=len(raw)):raise ValueError('Insufficient past source history')
    fallback=float(pre['median'][0]);scale=float(pre['scale'][0]);context=[];baseline=[]
    for t in times:
        past=raw[t-24*np.arange(1,15),0];known=np.isfinite(past)
        finite=past[known];mean=float(finite.mean()) if len(finite) else fallback
        median=float(np.median(finite)) if len(finite) else fallback
        days=((t//24-np.arange(1,15)+g.ORIGIN.weekday())%7)<5
        current=(t//24+g.ORIGIN.weekday())%7<5
        same=past[known&(days==current)];typical=float(same.mean()) if len(same) else mean
        lags=[float(raw[t-lag,0]) if np.isfinite(raw[t-lag,0]) else mean for lag in [1,2,3,24,168]]
        context.append([(v-fallback)/scale for v in lags+[mean,median,typical]]+
                       [float(finite.std())/scale if len(finite) else 0.,float(known.mean())])
        baseline.append(typical)
    return np.array(context,np.float32),np.array(baseline,np.float32)


def network(channels=4):
    import torch
    class SeasonalLSTM(torch.nn.Module):
        def __init__(self):
            super().__init__();self.recurrent=torch.nn.LSTM(channels,32,batch_first=True)
            self.hidden=torch.nn.Linear(36+len(CONTEXT),16);self.output=torch.nn.Linear(16,1)
        def forward(self,sequence,calendar,context):
            _,(state,_)=self.recurrent(sequence)
            return self.output(torch.relu(self.hidden(torch.cat((state[-1],calendar,context),dim=1)))).squeeze(-1)
    return SeasonalLSTM()


def prepared(raw,times,pre):
    seq,cal=inputs(raw,times,pre);context,base=seasonal(raw,times,pre)
    return seq,cal,context,base


def estimate(model,parts,scale,device):
    import torch
    model.eval();result=[]
    with torch.no_grad():
        for a in range(0,len(parts[3]),256):
            tensors=[torch.from_numpy(v[a:a+256]).to(device) for v in parts[:3]]
            p=model(*tensors).cpu().numpy()*scale+parts[3][a:a+256]
            result.extend(np.maximum(0,p))
    result=np.array(result,float)
    if not np.isfinite(result).all():raise ValueError('Non-finite source prediction')
    return result


def fit(seed,loss_name,train,valid,y,vy,pre,checkpoint,folder,device,smoke=False):
    import torch
    torch.manual_seed(seed);model=network().to(device)
    old=torch.load(checkpoint,map_location='cpu',weights_only=True)['state_dict']
    model.recurrent.load_state_dict({k.removeprefix('recurrent.'):v for k,v in old.items() if k.startswith('recurrent.')})
    with torch.no_grad():
        model.hidden.weight[:,:36].copy_(old['hidden.weight']);model.hidden.weight[:,36:].zero_()
        model.hidden.bias.copy_(old['hidden.bias']);model.output.weight.zero_();model.output.bias.zero_()
    scale=float(pre['scale'][0]);optimizer=torch.optim.Adam(model.parameters(),lr=.0005,weight_decay=.0001)
    x=[torch.from_numpy(a).to(device) for a in train[:3]]
    base=torch.from_numpy(train[3]).to(device);target=torch.tensor(y,dtype=torch.float32,device=device)
    rng=np.random.default_rng(seed);best=np.inf;stale=0;history=[];best_weights=None;started=time.monotonic()
    for epoch in range(1 if smoke else 25):
        model.train();order=rng.permutation(len(y));total=0.
        for a in range(0,len(order),256):
            ids=torch.tensor(order[a:a+256],device=device)
            prediction=(base[ids]+model(*(v[ids] for v in x))*scale).clamp(min=0)
            error=(prediction-target[ids])/scale
            loss=torch.nn.functional.smooth_l1_loss(error,torch.zeros_like(error),beta=.25) if loss_name=='huber' else (error.abs()+.5*error.square()).mean()
            if not torch.isfinite(loss):raise ValueError('Non-finite fine-tuning loss')
            optimizer.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step()
            total+=float(loss.item())*len(ids)
        p=estimate(model,valid,scale,device);error=p-vy;mae=float(np.abs(error).mean());rmse=float(np.sqrt(np.square(error).mean()))
        score=mae+.1*rmse
        history.append(dict(epoch=epoch+1,training_loss=total/len(y),validation_mae=mae,validation_rmse=rmse,selection_score=score))
        if score<best:
            best=score;stale=0;best_weights={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
        else:
            stale+=1
            if stale>=4:break
    model.load_state_dict(best_weights);folder.mkdir(parents=True)
    torch.save(dict(state_dict=best_weights,scale=scale,context=CONTEXT,loss=loss_name),folder/'model.pt')
    g.write_csv(folder/'epochs.csv',history)
    summary=dict(training_seed=seed,loss=loss_name,epochs=len(history),parameters=sum(p.numel() for p in model.parameters()),
                 best_epoch=int(np.argmin([r['selection_score'] for r in history]))+1,training_seconds=time.monotonic()-started)
    print(f"{loss_name} seed{seed}: epochs={len(history)} validation score={best:.5f}",flush=True)
    return model,summary


def train(data,base,out,device='cpu',smoke=False):
    import torch
    fresh_output(out,data,base);torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
    g.write_csv(out/'config.csv',[dict(parameter=k,value=v) for k,v in dict(
        model='four separate seasonal residual LSTMs; own-source336h sequence and own-source seasonal context',
        context=','.join(CONTEXT),warm_start='v5 LSTM recurrent and hidden weights; correction head initialised zero',
        losses='Huber beta0.25 and MAE+0.5MSE in training-scaled units',learning_rate=.0005,batch=256,max_epochs=25,patience=4,
        selection='pilot seed11 chooses loss on confirmed-normal forecast early-stop; all seeds11/22/33 then retained',
        validation_score='MAE+0.1RMSE; no detector calibration or final test used for source model selection',
        training_seeds=','.join(map(str,DEV_SEEDS)),training_hours='336..2880',early_stop_hours='2880..3600',
        availability='target and both normal family labels must arrive before respective fit cutoff',
        device=device,smoke=smoke).items()]);(out/'config.csv').chmod(0o444)
    source=out/'source';source.mkdir()
    for name in ['forecast_finetune.py','train.py','precision_study.py','two_stage.py','generate.py','multisource_dataset.py','revised_protocol.py','evaluation_v2.py','evaluation.py','validate.py']:
        shutil.copy(Path(__file__).with_name(name),source/name)
    datasets={}
    for seed in DEV_SEEDS:
        root=data/str(seed);verify(root)
        datasets[seed]=dict(rows=read(root/'hourly.csv'),targets=read(root/'targets_hourly.csv'),reviews=read(root/'app_reviews.csv'))
    old,old_pre,_=load_forecasters(base,device);training=[];selection=[];training_rows=[];scores=[];residual_scales=[]
    for source in SOURCES:
        records=[]
        for seed,d in datasets.items():
            raw=source_inputs(d['rows'],source);y=np.array([float(r[source]) if r[source] else np.nan for r in d['targets']])
            arrival=np.array([hour_number(r[source+'_available_at']) for r in d['targets']]);roles={}
            for role,a,b in [('fit',336,2880),('early_stop',2880,3600)]:
                labels=confirmed_hours(d['reviews'],b);normal=(labels['usage_anomaly']==0)&(labels['emergency']==0)
                times=np.arange(a,b);times=times[normal[times]&np.isfinite(y[times])&(arrival[times]<=b)]
                if smoke:times=times[:128 if role=='fit' else 64]
                roles[role]=times
                training_rows.extend(dict(source=source,data_seed=seed,role=role,hour=int(h)) for h in times)
            records.append(dict(seed=seed,raw=raw,y=y,roles=roles))
        # Equal-length source-only histories can be pooled without treating boundaries as adjacent hours.
        used=np.concatenate([r['raw'][np.unique((r['roles']['fit'][:,None]-336+np.arange(336)).ravel())] for r in records])
        median=np.array([np.median(c[np.isfinite(c)]) if np.isfinite(c).any() else 0. for c in used.T],np.float32)
        scale=np.std(np.where(np.isfinite(used),used,median),axis=0);scale[scale<1e-6]=1.
        pre=dict(median=median,scale=scale.astype(np.float32),history_hours=336,feature_names=[source,'source_availability'])
        joblib.dump(pre,out/(source+'_preprocessing.joblib'))
        sets={}
        for role in ['fit','early_stop']:
            pp=[prepared(r['raw'],r['roles'][role],pre) for r in records]
            parts=tuple(np.concatenate([p[j] for p in pp]) for j in range(4));y=np.concatenate([r['y'][r['roles'][role]] for r in records])
            sets[role]=(parts,y)
        tr,y=sets['fit'];va,vy=sets['early_stop'];pilot={}
        for loss in ['huber','balanced']:
            model,summary=fit(11,loss,tr,va,y,vy,pre,base/'forecasters'/source/'11/model.pt',out/source/loss/'11',device,smoke)
            training.append(dict(source=source,**summary));p=estimate(model,va,float(pre['scale'][0]),device)
            error=p-vy;mae=float(np.abs(error).mean());rmse=float(np.sqrt(np.mean(error**2)))
            scores.append(dict(source=source,candidate=loss,validation_mae=mae,validation_rmse=rmse,selection_score=mae+.1*rmse))
            pilot[loss]=(model,mae+.1*rmse)
        chosen=min(pilot,key=lambda loss:pilot[loss][1]);models=[pilot[chosen][0]]
        for seed in ([] if smoke else [22,33]):
            model,summary=fit(seed,chosen,tr,va,y,vy,pre,base/'forecasters'/source/str(seed)/'model.pt',out/source/chosen/str(seed),device)
            models.append(model);training.append(dict(source=source,**summary))
        p=np.mean([estimate(m,va,float(pre['scale'][0]),device) for m in models],axis=0)
        old_predictions=[]
        for r in records:
            times=r['roles']['early_stop'];parts=inputs(r['raw'],times,old_pre[source])
            old_predictions.extend(np.mean([predict('lstm',old[(source,s)],parts,r['raw'],times,old_pre[source],device) for s in [11,22,33]],axis=0))
        old_error=np.array(old_predictions)-vy;error=p-vy
        selection.append(dict(source=source,loss=chosen,training_seeds='11' if smoke else '11,22,33',validation_targets=len(vy),
            tuned_mae=float(np.abs(error).mean()),old_mae=float(np.abs(old_error).mean()),
            tuned_rmse=float(np.sqrt(np.mean(error**2))),old_rmse=float(np.sqrt(np.mean(old_error**2)))))
        residual_scales.append(dict(source=source,scale=max(float(error.std()),dict(electricity=.02,water=1.,gate=.1,app=.1)[source])))
        print('SELECTED',selection[-1],flush=True)
    for name,rows in [('training',training),('selection',selection),('pilot_candidates',scores),('training_targets',training_rows),('residual_scales',residual_scales)]:g.write_csv(out/(name+'.csv'),rows)
    manifest(out)


def load(root,device):
    import torch
    verify(root);models={};pre={}
    for r in read(root/'selection.csv'):
        source=r['source'];pre[source]=joblib.load(root/(source+'_preprocessing.joblib'))
        models[source]=[]
        for seed in map(int,r['training_seeds'].split(',')):
            saved=torch.load(root/source/r['loss']/str(seed)/'model.pt',map_location='cpu',weights_only=True)
            model=network().to(device);model.load_state_dict(saved['state_dict']);models[source].append(model)
    scales=np.array([float(next(r for r in read(root/'residual_scales.csv') if r['source']==source)['scale']) for source in SOURCES])
    return models,pre,scales


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--data',type=Path,default=Path('ml/household/precision_data_v6'))
    p.add_argument('--base',type=Path,default=Path('ml/household/runs/two-stage-v5'))
    p.add_argument('--out',type=Path,default=Path('ml/household/runs/forecast-v7'))
    p.add_argument('--device',choices=['cpu','mps'],default='cpu');p.add_argument('--smoke',action='store_true')
    a=p.parse_args();train(a.data,a.base,a.out,a.device,a.smoke)
