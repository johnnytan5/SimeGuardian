# Research inspiration

Hernández, Á.; Nieto, R.; de Diego-Otón, L.; Pérez-Rubio, M.C.; Villadangos-Carrizo, J.M.; Pizarro, D.; Ureña, J. (2024). **Detection of Anomalies in Daily Activities Using Data from Smart Meters.** Sensors24(2),515.

- DOI / publisher: https://doi.org/10.3390/s24020515
- Author university repository, open-access PDF: https://burjcdigital.urjc.es/server/api/core/bitstreams/225831e1-f724-4e61-9762-c7d3b6077b9a/content
- Publisher article: https://www.mdpi.com/1424-8220/24/2/515

The primary paper was read through its university-hosted full text. A local PDF copy is not bundled because direct download was unavailable; the primary links and full citation are supplied. The article states CC BY4.0 licensing. No article text or figures are reproduced in these notebooks.

The paper's broad idea—forecast consumption and inspect deviations—motivated this work. The package deliberately distinguishes that inspiration from its own model architecture, feature sources, simulated family ground truth and stated case-selection/check-in assumptions. Paper results and our synthetic emergency metrics use different targets and are not directly comparable.
